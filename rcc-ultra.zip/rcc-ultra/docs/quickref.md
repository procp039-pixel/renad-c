# Renad C Quick Reference

## Basics

```rc
let x = 10
const PI: float = 3.14

fn add(a: int, b: int):
    return a + b
```

## Conditions & Loops

```rc
if x > 0:
    println("positive")
else:
    println("zero")

while x < 10:
    x = x + 1

for item in [1, 2, 3]:
    println(item)
```

## Enums & Macros

```rc
macro log!(msg):
    print(msg)

enum Mode:
    Dev
    Prod
```

## Packages & Imports

```rc
package my.app
import rcstd.web as web
```

## Built-ins

`print`, `println`, `len`, `str`

## Web (Static)

```rc
import rcstd.web as web

fn main():
    let app = web.App()
    app.static("examples/public")
    app.listen(3000)
```

## Web (API)

```rc
fn user(req: RCRequest, res: RCResponse) -> void:
    let id = req.param("id")
    res.json("{\"id\":\"${id}\"}")

fn main():
    let app = web.App()
    app.get("/users/:id", user)
    app.listen(3000)
```
