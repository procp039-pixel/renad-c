# Examples

See the `examples/` folder:

- `cli_tool.rc` — simple CLI-style output
- `web_app.rc` — built-in HTTP server
- `data_pipeline.rc` — arrays + loops
- `mohamed_portfolio.rc` — personal RC website (HTML/CSS served via rcstd.web)
- `static_site.rc` — serve static files (HTML/CSS) from `examples/public`
- `api_server.rc` — Express-like API with params/query/headers
