# Renad C Brand

## Logo

Primary mark: `site/assets/logo.svg` (RC geometric monogram)

Recommended usage:
- Dark background
- Keep padding around logo (at least 10% of logo size)
- Do not stretch or skew

## Colors

- Primary: #3B82F6
- Accent:  #22D3EE
- Dark:    #0B1220
