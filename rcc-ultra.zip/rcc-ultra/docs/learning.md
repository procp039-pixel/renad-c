# Learn Renad C (Path)

1. Start with `docs/getting-started.md`
2. Read `docs/quickref.md`
3. Run examples in `examples/`
4. Modify `examples/class_demo.rc`
5. Build a tiny web service with `rcstd.web`
