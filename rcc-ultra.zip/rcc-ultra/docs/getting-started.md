# Getting Started — Renad C

## Build the compiler

```bash
gcc src/*.c -o rcc
```

## Run a program

```bash
./rcc tests/hello.rc
# or
./rcc run tests/hello.rc
```

## Run the HTTP server

```bash
./rcc tests/http_server.rc
curl http://127.0.0.1:3000
```

## Diagnostics (LSP)

```bash
./rcc --check tests/hello.rc
./rcc --diagnostics-json tests/hello.rc
```

## VSCode Extension

```bash
cd vscode-extension
npm install
code --install-extension .
```

After installation, `.rc` files show the Renad C icon and get LSP features.

## Websites

- **Showcase site (static):** open `site/index.html`.
- **Personal RC site:** `./rcc examples/mohamed_portfolio.rc` then open `http://localhost:3000`.
