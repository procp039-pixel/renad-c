# Roadmap (Future / Non‑v1)

- Full static type system and advanced inference
- Optimizing IR and native codegen
- Package manager (rcpm)
- Full standard library modules
- OS kernel-level experiments (future research)
