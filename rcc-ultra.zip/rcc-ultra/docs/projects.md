# Projects with Renad C

## أدوات (Tools)

- CLI tools: استخدم `println` و loops لمعالجة البيانات.
- Scripts: نظم المهام المتكررة بسرعة.

## مواقع/خدمات (Web)

- استخدم `rcstd.web` لتشغيل سيرفر بسيط:

```rc
import rcstd.web as web

fn main():
    let app = web.App()
    app.listen(3000)
```

## نواة (Kernel)

مشروع النواة خارج نطاق v1.1 — موجود في `docs/roadmap.md` كمستقبل بحثي.
