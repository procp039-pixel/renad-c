/*
 * Renad C Test Suite v1.0.0
 * Author: Mohamed Ahmed Mohamed · renad-c.dev
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/lexer.h"
#include "../src/ast.h"
#include "../src/parser.h"

#define RST "\033[0m"
#define GRN "\033[1;32m"
#define RED "\033[1;31m"
#define CYN "\033[1;36m"
#define BLD "\033[1m"
#define DIM "\033[2m"

static int g_run=0,g_ok=0,g_fail=0;

#define SUITE(n) printf("\n"CYN"  ▸ %s"RST"\n",n)
#define CHECK(desc,cond) do{ g_run++; \
  if(cond){g_ok++;printf(GRN"    ✓ "RST DIM"%s"RST"\n",desc);} \
  else{g_fail++;printf(RED"    ✗ %s"RST DIM" (L%d)"RST"\n",desc,__LINE__);} \
}while(0)
#define CHECK_EQ(d,a,b)  CHECK(d,(a)==(b))
#define CHECK_STR(d,a,b) CHECK(d,strcmp((a),(b))==0)
#define CHECK_NN(d,p)    CHECK(d,(p)!=NULL)

/* ── helpers ── */
static Token *lex_all(const char *src, int *n){
    Lexer *l=lexer_new(src); Token *t=malloc(sizeof(Token)*512); *n=0;
    while(1){ t[*n]=lexer_next(l); if(t[(*n)].type==TOK_EOF){(*n)++;break;} (*n)++; if(*n>=511)break; }
    lexer_free(l); return t;
}
static AstNode *parse_src(const char *src){
    Lexer *l=lexer_new(src); Parser *p=parser_new(l);
    AstNode *n=parser_parse(p); parser_free(p); lexer_free(l); return n;
}
static int has_node(AstNode *n, NodeType want){
    if(!n) return 0; if(n->type==want) return 1;
    for(int i=0;i<n->child_count;i++) if(has_node(n->children[i],want)) return 1;
    return 0;
}
static char *run_rc(const char *code){
    FILE *f=fopen("/tmp/rc_ts.rc","w"); fprintf(f,"%s",code); fclose(f);
    FILE *p=popen("./rcc /tmp/rc_ts.rc 2>/dev/null","r");
    static char buf[1024]; memset(buf,0,sizeof(buf));
    if(p){ size_t rn=fread(buf,1,sizeof(buf)-1,p); (void)rn; pclose(p); }
    int len=strlen(buf); while(len>0&&(buf[len-1]=='\n'||buf[len-1]=='\r'))buf[--len]=0;
    return buf;
}

/* ════ LEXER ════ */
static void t_lex_literals(void){ SUITE("Lexer — literals");
    int n; Token *t;
    t=lex_all("42",&n);     CHECK_EQ("int type",    t[0].type,TOK_INT_LIT);  free(t);
    t=lex_all("3.14",&n);   CHECK_EQ("float type",  t[0].type,TOK_FLOAT_LIT);free(t);
    t=lex_all("\"hi\"",&n); CHECK_EQ("str type",    t[0].type,TOK_STRING_LIT);
                            CHECK_STR("str value",  t[0].value,"hi");         free(t);
    t=lex_all("\"\"",&n);   CHECK_EQ("empty str",   t[0].type,TOK_STRING_LIT);
                            CHECK_STR("empty val",  t[0].value,"");           free(t);
    t=lex_all("true",&n);   CHECK_EQ("true",         t[0].type,TOK_TRUE);     free(t);
    t=lex_all("false",&n);  CHECK_EQ("false",        t[0].type,TOK_FALSE);    free(t);
}
static void t_lex_keywords(void){ SUITE("Lexer — keywords");
    int n; Token *t;
    t=lex_all("fn let mut const return if else for in while match import as struct",&n);
    CHECK_EQ("fn",    t[0].type,TOK_FN);   CHECK_EQ("let",  t[1].type,TOK_LET);
    CHECK_EQ("mut",   t[2].type,TOK_MUT);  CHECK_EQ("const",t[3].type,TOK_CONST);
    CHECK_EQ("return",t[4].type,TOK_RETURN);CHECK_EQ("if",  t[5].type,TOK_IF);
    CHECK_EQ("else",  t[6].type,TOK_ELSE); CHECK_EQ("for",  t[7].type,TOK_FOR);
    CHECK_EQ("in",    t[8].type,TOK_IN);   CHECK_EQ("while",t[9].type,TOK_WHILE);
    CHECK_EQ("match", t[10].type,TOK_MATCH);CHECK_EQ("import",t[11].type,TOK_IMPORT);
    CHECK_EQ("as",    t[12].type,TOK_AS);  CHECK_EQ("struct",t[13].type,TOK_STRUCT);
    free(t);
}
static void t_lex_operators(void){ SUITE("Lexer — operators");
    int n; Token *t;
    t=lex_all("+ - * / % == != < > <= >= -> ..",&n);
    CHECK_EQ("+", t[0].type,TOK_PLUS); CHECK_EQ("-",t[1].type,TOK_MINUS);
    CHECK_EQ("*", t[2].type,TOK_STAR); CHECK_EQ("/",t[3].type,TOK_SLASH);
    CHECK_EQ("%", t[4].type,TOK_PERCENT);
    CHECK_EQ("==",t[5].type,TOK_EQ);   CHECK_EQ("!=",t[6].type,TOK_NEQ);
    CHECK_EQ("<", t[7].type,TOK_LT);   CHECK_EQ(">", t[8].type,TOK_GT);
    CHECK_EQ("<=",t[9].type,TOK_LEQ);  CHECK_EQ(">=",t[10].type,TOK_GEQ);
    CHECK_EQ("->",t[11].type,TOK_ARROW);CHECK_EQ("..",t[12].type,TOK_DOTDOT);
    free(t);
}
static void t_lex_idents(void){ SUITE("Lexer — identifiers");
    int n; Token *t;
    t=lex_all("foo bar _baz x123",&n);
    for(int i=0;i<4;i++) CHECK_EQ("is IDENT",t[i].type,TOK_IDENT);
    CHECK_STR("foo",t[0].value,"foo"); CHECK_STR("_baz",t[2].value,"_baz");
    free(t);
}
static void t_lex_comments(void){ SUITE("Lexer — comments stripped");
    int n; Token *t;
    t=lex_all("42 // ignored\n99",&n);
    CHECK_EQ("tok0 int",t[0].type,TOK_INT_LIT); CHECK_STR("val=42",t[0].value,"42");
    /* after comment+newline a NEWLINE token may appear - find next INT_LIT */
    { int ii=1; while(ii<n && t[ii].type!=TOK_INT_LIT) ii++;
      CHECK_EQ("tok1 int",t[ii].type,TOK_INT_LIT); CHECK_STR("val=99",t[ii].value,"99"); }
    free(t);
}
static void t_lex_indent(void){ SUITE("Lexer — indent/dedent");
    int n; Token *t;
    t=lex_all("fn f():\n    let x = 1\n    let y = 2\n\n",&n);
    int ind=0,ded=0;
    for(int i=0;i<n;i++){if(t[i].type==TOK_INDENT)ind=1;if(t[i].type==TOK_DEDENT)ded=1;}
    CHECK_EQ("INDENT produced",ind,1); (void)ded; /* DEDENT: impl-defined timing */ free(t);
}
static void t_lex_eof(void){ SUITE("Lexer — EOF");
    int n; Token *t;
    t=lex_all("",&n); CHECK_EQ("empty→EOF",t[0].type,TOK_EOF); free(t);
}

/* ════ PARSER ════ */
static void t_parse_fn(void){ SUITE("Parser — fn declaration");
    AstNode *p=parse_src("fn main():\n    pass\n");
    CHECK_NN("program",p);
    if(p){ CHECK_EQ("NODE_PROGRAM",p->type,NODE_PROGRAM);
           if(p->child_count>0) CHECK_EQ("FN_DECL child",p->children[0]->type,NODE_FN_DECL);
           CHECK_STR("fn name","main",p->children[0]->sval);
           ast_free(p); }
}
static void t_parse_let(void){ SUITE("Parser — let stmt");
    AstNode *p=parse_src("fn f():\n    let x = 42\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has LET_STMT",has_node(p,NODE_LET_STMT),1); ast_free(p); }
}
static void t_parse_if(void){ SUITE("Parser — if/else");
    AstNode *p=parse_src("fn f():\n    if x>0:\n        return 1\n    else:\n        return 0\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has IF_STMT",has_node(p,NODE_IF_STMT),1); ast_free(p); }
}
static void t_parse_for(void){ SUITE("Parser — for range");
    AstNode *p=parse_src("fn f():\n    for i in 0..10:\n        print(i)\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has FOR_STMT",has_node(p,NODE_FOR_STMT),1); ast_free(p); }
}
static void t_parse_while(void){ SUITE("Parser — while");
    AstNode *p=parse_src("fn f():\n    while x>0:\n        x=x-1\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has WHILE_STMT",has_node(p,NODE_WHILE_STMT),1); ast_free(p); }
}
static void t_parse_return(void){ SUITE("Parser — return");
    AstNode *p=parse_src("fn id(x: int) -> int:\n    return x\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has RETURN_STMT",has_node(p,NODE_RETURN_STMT),1); ast_free(p); }
}
static void t_parse_struct(void){ SUITE("Parser — struct");
    AstNode *p=parse_src("struct Point:\n    x: int\n    y: int\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has STRUCT_DECL",has_node(p,NODE_STRUCT_DECL),1); ast_free(p); }
}
static void t_parse_const(void){ SUITE("Parser — const");
    AstNode *p=parse_src("const MAX = 100\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has CONST_DECL",has_node(p,NODE_CONST_STMT),1); ast_free(p); }
}
static void t_parse_multi_fn(void){ SUITE("Parser — multiple functions");
    AstNode *p=parse_src("fn foo():\n    return 1\nfn bar():\n    return 2\nfn main():\n    print(1)\n");
    CHECK_NN("prog",p);
    if(p){ int cnt=0; for(int i=0;i<p->child_count;i++) if(p->children[i]->type==NODE_FN_DECL)cnt++;
           CHECK_EQ("3 fns",cnt,3); ast_free(p); }
}
static void t_parse_nested(void){ SUITE("Parser — nested for+if");
    AstNode *p=parse_src("fn f():\n    for i in 0..5:\n        if i>2:\n            print(i)\n");
    CHECK_NN("prog",p);
    if(p){ CHECK_EQ("has FOR",has_node(p,NODE_FOR_STMT),1);
           CHECK_EQ("has IF", has_node(p,NODE_IF_STMT), 1); ast_free(p); }
}

/* ════ INTEGRATION ════ */
static void t_run_hello(void){ SUITE("Integration — hello world");
    CHECK_STR("output",run_rc("fn main():\n    print(\"HELLO_OK\")\n"),"HELLO_OK");
}
static void t_run_factorial(void){ SUITE("Integration — factorial");
    const char *c="fn fact(n:int)->int:\n    if n<=1:\n        return 1\n    return n*fact(n-1)\nfn main():\n    print(fact(5))\n    print(fact(10))\n";
    FILE *f=fopen("/tmp/rc_ts.rc","w");fprintf(f,"%s",c);fclose(f);
    FILE *p=popen("./rcc /tmp/rc_ts.rc 2>/dev/null","r");
    char a[32]={0},b[32]={0};
    if(p){fgets(a,sizeof(a),p);fgets(b,sizeof(b),p);pclose(p);}
    a[strcspn(a,"\n")]=0;b[strcspn(b,"\n")]=0;
    CHECK_STR("fact(5)=120",a,"120"); CHECK_STR("fact(10)=3628800",b,"3628800");
}
static void t_run_fibonacci(void){ SUITE("Integration — fibonacci");
    const char *c="fn fib(n:int)->int:\n    if n<=1:\n        return n\n    return fib(n-1)+fib(n-2)\nfn main():\n    print(fib(0))\n    print(fib(10))\n    print(fib(15))\n";
    FILE *f=fopen("/tmp/rc_ts.rc","w");fprintf(f,"%s",c);fclose(f);
    FILE *p=popen("./rcc /tmp/rc_ts.rc 2>/dev/null","r");
    char a[32]={0},b[32]={0},d[32]={0};
    if(p){fgets(a,sizeof(a),p);fgets(b,sizeof(b),p);fgets(d,sizeof(d),p);pclose(p);}
    a[strcspn(a,"\n")]=0;b[strcspn(b,"\n")]=0;d[strcspn(d,"\n")]=0;
    CHECK_STR("fib(0)=0",a,"0"); CHECK_STR("fib(10)=55",b,"55"); CHECK_STR("fib(15)=610",d,"610");
}
static void t_run_loop_sum(void){ SUITE("Integration — range sum");
    const char *c="fn sum(n:int)->int:\n    let mut s=0\n    for i in 0..n:\n        s=s+i\n    return s\nfn main():\n    print(sum(5))\n    print(sum(11))\n    print(sum(101))\n";
    FILE *f=fopen("/tmp/rc_ts.rc","w");fprintf(f,"%s",c);fclose(f);
    FILE *p=popen("./rcc /tmp/rc_ts.rc 2>/dev/null","r");
    char a[32]={0},b[32]={0},cc[32]={0};
    if(p){fgets(a,sizeof(a),p);fgets(b,sizeof(b),p);fgets(cc,sizeof(cc),p);pclose(p);}
    a[strcspn(a,"\n")]=0;b[strcspn(b,"\n")]=0;cc[strcspn(cc,"\n")]=0;
    CHECK_STR("sum(5)=10",a,"10"); CHECK_STR("sum(11)=55",b,"55"); CHECK_STR("sum(101)=5050",cc,"5050");
}
static void t_run_while(void){ SUITE("Integration — while loop");
    CHECK_STR("while→10",run_rc("fn main():\n    let mut i = 0\n    while i < 10:\n        i = i + 1\n    print(i)\n"),"10");
}
static void t_run_const(void){ SUITE("Integration — const");
    CHECK_STR("ANSWER=42",run_rc("const ANSWER = 42\nfn main():\n    print(ANSWER)\n"),"42");
}
static void t_run_multi_fn(void){ SUITE("Integration — multi-fn call chain");
    CHECK_STR("quad(3)=12",run_rc("fn twice(x: int) -> int:\n    return x * 2\nfn quad(x: int) -> int:\n    return twice(twice(x))\nfn main():\n    print(quad(3))\n"),"12");
}
static void t_run_binary(void){ SUITE("Integration — compile to binary (-o)");
    FILE *f=fopen("/tmp/rc_bin_t.rc","w");fprintf(f,"fn main():\n    print(\"BIN_OK\")\n");fclose(f);
    system("./rcc /tmp/rc_bin_t.rc -o /tmp/rc_bin_t 2>/dev/null");
    FILE *p=popen("/tmp/rc_bin_t 2>/dev/null","r");
    char buf[64]={0}; if(p){fgets(buf,sizeof(buf),p);pclose(p);}
    buf[strcspn(buf,"\n")]=0; CHECK_STR("binary output",buf,"BIN_OK");
}
static void t_run_conditionals(void){ SUITE("Integration — if/else chain");
    const char *c="fn sign(n:int)->int:\n    if n<0:\n        return -1\n    else:\n        if n==0:\n            return 0\n        else:\n            return 1\nfn main():\n    print(sign(-5))\n    print(sign(0))\n    print(sign(7))\n";
    FILE *f=fopen("/tmp/rc_ts.rc","w");fprintf(f,"%s",c);fclose(f);
    FILE *p=popen("./rcc /tmp/rc_ts.rc 2>/dev/null","r");
    char a[8]={0},b[8]={0},d[8]={0};
    if(p){fgets(a,sizeof(a),p);fgets(b,sizeof(b),p);fgets(d,sizeof(d),p);pclose(p);}
    a[strcspn(a,"\n")]=0;b[strcspn(b,"\n")]=0;d[strcspn(d,"\n")]=0;
    CHECK_STR("sign(-5)=-1",a,"-1"); CHECK_STR("sign(0)=0",b,"0"); CHECK_STR("sign(7)=1",d,"1");
}

int main(void){
    printf("\n");
    printf(BLD"  Renad C — Test Suite v1.0.0\n"RST);
    printf(DIM"  Author: Mohamed Ahmed Mohamed · renad-c.dev\n"RST);
    printf("  ──────────────────────────────────────────────\n");

    t_lex_literals(); t_lex_keywords(); t_lex_operators();
    t_lex_idents();   t_lex_comments(); t_lex_indent(); t_lex_eof();

    t_parse_fn(); t_parse_let();   t_parse_if();  t_parse_for();
    t_parse_while(); t_parse_return(); t_parse_struct();
    t_parse_const(); t_parse_multi_fn(); t_parse_nested();

    t_run_hello(); t_run_factorial(); t_run_fibonacci();
    t_run_loop_sum(); t_run_while(); t_run_const();
    t_run_multi_fn(); t_run_binary(); t_run_conditionals();

    printf("\n  ──────────────────────────────────────────────\n");
    printf("  "BLD"Results: "RST GRN"%d passed"RST"  ",g_ok);
    if(g_fail) printf(RED"%d failed"RST"  ",g_fail);
    printf(DIM"%d total"RST"\n\n",g_run);

    if(!g_fail){ printf(GRN BLD"  ✅ All %d tests passed!\n"RST"\n",g_run); return 0; }
    printf(RED BLD"  ❌ %d test(s) failed\n"RST"\n",g_fail); return 1;
}
