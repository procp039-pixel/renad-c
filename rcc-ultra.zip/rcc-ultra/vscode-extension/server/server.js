const {
  createConnection,
  ProposedFeatures,
  TextDocuments,
  DiagnosticSeverity,
  CompletionItemKind,
  MarkupKind,
  Location
} = require('vscode-languageserver/node');
const { TextDocument } = require('vscode-languageserver-textdocument');
const cp = require('child_process');
const fs = require('fs');
const path = require('path');
const { fileURLToPath } = require('url');

const connection = createConnection(ProposedFeatures.all);
const documents = new TextDocuments(TextDocument);

let workspaceRoot = null;
let rccPath = 'rcc';
let quickrefText = '';

const KEYWORDS = [
  'fn', 'let', 'const', 'mut', 'if', 'else', 'while', 'for', 'in', 'return',
  'import', 'as', 'class', 'interface', 'package', 'new', 'this',
  'public', 'private', 'protected', 'static',
  'true', 'false', 'nil'
];

const BUILTINS = ['print', 'println', 'len', 'str'];

function loadQuickref() {
  try {
    const root = workspaceRoot || process.cwd();
    const p = path.join(root, 'docs', 'quickref.md');
    return fs.readFileSync(p, 'utf8');
  } catch {
    return '';
  }
}

function uriToPath(uri) {
  try {
    if (uri.startsWith('file://')) return fileURLToPath(uri);
  } catch {}
  return null;
}

function getWordAt(text, offset) {
  if (offset < 0 || offset > text.length) return '';
  const isWord = (ch) => /[A-Za-z0-9_]/.test(ch);
  let start = offset;
  let end = offset;
  while (start > 0 && isWord(text[start - 1])) start--;
  while (end < text.length && isWord(text[end])) end++;
  return text.slice(start, end);
}

function scanSymbols(text) {
  const symbols = [];
  const lines = text.split(/\r?\n/);
  const re = /^\s*(fn|class|interface|let|const)\s+([A-Za-z_][A-Za-z0-9_]*)/;
  for (let line = 0; line < lines.length; line++) {
    const m = lines[line].match(re);
    if (!m) continue;
    const kind = m[1];
    const name = m[2];
    const col = lines[line].indexOf(name);
    symbols.push({ name, kind, line, col: col < 0 ? 0 : col });
  }
  return symbols;
}

function hoverFromQuickref(word) {
  if (!quickrefText) return null;
  const needle = '`' + word + '`';
  const lines = quickrefText.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes(needle)) {
      return lines[i].trim();
    }
  }
  return null;
}

function buildHover(word) {
  const fromDoc = hoverFromQuickref(word);
  if (fromDoc) return fromDoc;
  if (KEYWORDS.includes(word)) return `\`${word}\` keyword`;
  if (BUILTINS.includes(word)) return `built-in: \`${word}\``;
  return null;
}

function validateTextDocument(doc) {
  const filePath = uriToPath(doc.uri);
  if (!filePath) return;

  const cwd = workspaceRoot || process.cwd();
  const resolvedRcc = path.isAbsolute(rccPath) ? rccPath : path.join(cwd, rccPath);
  const args = ['--diagnostics-json', filePath];
  const proc = cp.spawn(resolvedRcc, args, { cwd });
  let out = '';
  proc.stdout.on('data', (d) => { out += d.toString(); });
  proc.on('error', (err) => {
    connection.console.error(`Failed to run rcc: ${err.message}`);
  });
  proc.on('close', () => {
    let diags = [];
    try {
      const json = JSON.parse(out);
      if (json && Array.isArray(json.diagnostics)) {
        diags = json.diagnostics.map((d) => {
          const line = Math.max(0, (d.line || 1) - 1);
          const col = Math.max(0, (d.col || 1) - 1);
          const severity = d.severity === 'warning'
            ? DiagnosticSeverity.Warning
            : DiagnosticSeverity.Error;
          return {
            range: {
              start: { line, character: col },
              end: { line, character: col + 1 }
            },
            message: d.message || 'diagnostic',
            severity
          };
        });
      }
    } catch (e) {
      connection.console.error(`Failed to parse diagnostics JSON: ${e.message}`);
    }
    connection.sendDiagnostics({ uri: doc.uri, diagnostics: diags });
  });
}

const pending = new Map();
function scheduleValidate(doc) {
  const key = doc.uri;
  if (pending.has(key)) clearTimeout(pending.get(key));
  const handle = setTimeout(() => {
    pending.delete(key);
    validateTextDocument(doc);
  }, 200);
  pending.set(key, handle);
}

connection.onInitialize((params) => {
  workspaceRoot = params.rootUri ? fileURLToPath(params.rootUri) : null;
  if (params.initializationOptions && params.initializationOptions.rccPath) {
    rccPath = params.initializationOptions.rccPath;
  }
  quickrefText = loadQuickref();

  return {
    capabilities: {
      textDocumentSync: documents.syncKind,
      hoverProvider: true,
      completionProvider: { resolveProvider: false },
      definitionProvider: true
    }
  };
});

documents.onDidOpen((e) => scheduleValidate(e.document));
documents.onDidChangeContent((e) => scheduleValidate(e.document));

connection.onHover((params) => {
  const doc = documents.get(params.textDocument.uri);
  if (!doc) return null;
  const text = doc.getText();
  const offset = doc.offsetAt(params.position);
  const word = getWordAt(text, offset);
  if (!word) return null;
  const content = buildHover(word);
  if (!content) return null;
  return { contents: { kind: MarkupKind.Markdown, value: content } };
});

connection.onCompletion((params) => {
  const doc = documents.get(params.textDocument.uri);
  const text = doc ? doc.getText() : '';
  const symbols = scanSymbols(text);

  const items = [];
  for (const kw of KEYWORDS) {
    items.push({ label: kw, kind: CompletionItemKind.Keyword });
  }
  for (const bi of BUILTINS) {
    items.push({ label: bi, kind: CompletionItemKind.Function });
  }
  for (const s of symbols) {
    let kind = CompletionItemKind.Variable;
    if (s.kind === 'fn') kind = CompletionItemKind.Function;
    if (s.kind === 'class') kind = CompletionItemKind.Class;
    if (s.kind === 'interface') kind = CompletionItemKind.Interface;
    items.push({ label: s.name, kind });
  }
  return items;
});

connection.onDefinition((params) => {
  const doc = documents.get(params.textDocument.uri);
  if (!doc) return null;
  const text = doc.getText();
  const offset = doc.offsetAt(params.position);
  const word = getWordAt(text, offset);
  if (!word) return null;
  const symbols = scanSymbols(text);
  const hit = symbols.find((s) => s.name === word);
  if (!hit) return null;
  return Location.create(doc.uri, {
    start: { line: hit.line, character: hit.col },
    end: { line: hit.line, character: hit.col + word.length }
  });
});

documents.listen(connection);
connection.listen();
