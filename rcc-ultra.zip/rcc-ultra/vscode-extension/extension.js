// extension.js — Renad C VSCode Extension
const vscode = require('vscode');
const { execSync, spawn } = require('child_process');
const path = require('path');
const { LanguageClient, TransportKind } = require('vscode-languageclient/node');

let client;

function startLanguageServer(context) {
    const cfg = vscode.workspace.getConfiguration('renad-c');
    const rccPath = cfg.get('compilerPath', './rcc');
    const serverModule = context.asAbsolutePath(path.join('server', 'server.js'));

    const serverOptions = {
        run: { module: serverModule, transport: TransportKind.ipc },
        debug: { module: serverModule, transport: TransportKind.ipc }
    };

    const clientOptions = {
        documentSelector: [{ scheme: 'file', language: 'renad-c' }],
        initializationOptions: { rccPath },
        synchronize: {
            fileEvents: vscode.workspace.createFileSystemWatcher('**/*.rc')
        }
    };

    client = new LanguageClient(
        'renadCLsp',
        'Renad C Language Server',
        serverOptions,
        clientOptions
    );
    client.start();
}

function activate(context) {
    console.log('Renad C extension activated');
    startLanguageServer(context);

    vscode.workspace.onDidChangeConfiguration(e => {
        if (e.affectsConfiguration('renad-c.compilerPath') && client) {
            client.stop().then(() => startLanguageServer(context));
        }
    });

    // ── Run current file ──────────────────────────────────────
    const runCmd = vscode.commands.registerCommand('renad-c.runFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;
        const file = editor.document.fileName;
        const cfg  = vscode.workspace.getConfiguration('renad-c');
        const rcc  = cfg.get('compilerPath', './rcc');

        let terminal = vscode.window.terminals.find(t => t.name === 'Renad C');
        if (!terminal) terminal = vscode.window.createTerminal('Renad C');
        terminal.show();
        terminal.sendText(`${rcc} run "${file}"`);
    });

    // ── Build current file ────────────────────────────────────
    const buildCmd = vscode.commands.registerCommand('renad-c.buildFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;
        const file    = editor.document.fileName;
        const cfg     = vscode.workspace.getConfiguration('renad-c');
        const rcc     = cfg.get('compilerPath', './rcc');
        const out     = file + '.out';

        let terminal = vscode.window.terminals.find(t => t.name === 'Renad C');
        if (!terminal) terminal = vscode.window.createTerminal('Renad C');
        terminal.show();
        terminal.sendText(`${rcc} "${file}" -o "${out}"`);
    });

    // ── Show AST ──────────────────────────────────────────────
    const astCmd = vscode.commands.registerCommand('renad-c.showAST', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;
        const file = editor.document.fileName;
        const cfg  = vscode.workspace.getConfiguration('renad-c');
        const rcc  = cfg.get('compilerPath', './rcc');
        let terminal = vscode.window.terminals.find(t => t.name === 'Renad C');
        if (!terminal) terminal = vscode.window.createTerminal('Renad C');
        terminal.show();
        terminal.sendText(`${rcc} "${file}" --ast`);
    });

    // ── Show Tokens ───────────────────────────────────────────
    const tokCmd = vscode.commands.registerCommand('renad-c.showTokens', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;
        const file = editor.document.fileName;
        const cfg  = vscode.workspace.getConfiguration('renad-c');
        const rcc  = cfg.get('compilerPath', './rcc');
        let terminal = vscode.window.terminals.find(t => t.name === 'Renad C');
        if (!terminal) terminal = vscode.window.createTerminal('Renad C');
        terminal.show();
        terminal.sendText(`${rcc} "${file}" --tokens`);
    });

    context.subscriptions.push(runCmd, buildCmd, astCmd, tokCmd);

    // ── Status bar item ───────────────────────────────────────
    const statusBar = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Left, 100
    );
    statusBar.command = 'renad-c.runFile';
    statusBar.text    = '$(play) rcc';
    statusBar.tooltip = 'Run current .rc file';
    context.subscriptions.push(statusBar);

    vscode.window.onDidChangeActiveTextEditor(editor => {
        if (editor && editor.document.languageId === 'renad-c') {
            statusBar.show();
        } else {
            statusBar.hide();
        }
    });

    // Show on activation if .rc file is open
    if (vscode.window.activeTextEditor?.document.languageId === 'renad-c') {
        statusBar.show();
    }
}

function deactivate() {
    if (client) {
        return client.stop();
    }
}
module.exports = { activate, deactivate };
