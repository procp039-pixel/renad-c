const body = document.body;
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
const toggle = document.getElementById('nav-toggle');
const progress = document.getElementById('progress');

if (toggle) {
  toggle.addEventListener('click', () => {
    body.classList.toggle('nav-open');
  });
}

if (overlay) {
  overlay.addEventListener('click', () => {
    body.classList.remove('nav-open');
  });
}

// Scroll progress
const updateProgress = () => {
  if (!progress) return;
  const doc = document.documentElement;
  const max = doc.scrollHeight - window.innerHeight;
  const ratio = max > 0 ? window.scrollY / max : 0;
  progress.style.width = `${Math.min(100, Math.max(0, ratio * 100))}%`;
};

let progressTicking = false;
window.addEventListener('scroll', () => {
  if (progressTicking) return;
  progressTicking = true;
  window.requestAnimationFrame(() => {
    updateProgress();
    progressTicking = false;
  });
});
window.addEventListener('resize', updateProgress);
updateProgress();

// Scrollspy
const navLinks = Array.from(document.querySelectorAll('.nav-link'));
const sections = Array.from(document.querySelectorAll('section[id]'));
const linkById = new Map(navLinks.map((link) => [link.getAttribute('href')?.slice(1), link]));

const setActive = (id) => {
  navLinks.forEach((l) => l.classList.remove('active'));
  const link = linkById.get(id);
  if (link) link.classList.add('active');
};

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        setActive(entry.target.id);
      }
    });
  }, { rootMargin: '-35% 0px -55% 0px', threshold: 0.1 });

  sections.forEach((s) => observer.observe(s));
}

navLinks.forEach((link) => {
  link.addEventListener('click', () => {
    body.classList.remove('nav-open');
  });
});

// Stats count-up
const statNodes = Array.from(document.querySelectorAll('.stat-value[data-count]'));
const animateCount = (el) => {
  const target = Number.parseInt(el.dataset.count || '0', 10);
  if (!Number.isFinite(target)) return;
  const duration = 900;
  const start = performance.now();
  const step = (now) => {
    const t = Math.min(1, (now - start) / duration);
    const value = Math.floor(t * target);
    el.textContent = String(value);
    if (t < 1) {
      window.requestAnimationFrame(step);
    } else {
      el.textContent = String(target);
    }
  };
  window.requestAnimationFrame(step);
};

if ('IntersectionObserver' in window) {
  const statObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      if (el.dataset.counted) return;
      el.dataset.counted = '1';
      animateCount(el);
      statObserver.unobserve(el);
    });
  }, { threshold: 0.5 });

  statNodes.forEach((node) => statObserver.observe(node));
} else {
  statNodes.forEach((node) => {
    node.textContent = node.dataset.count || '0';
  });
}

// Learning path tabs
const trackPanel = document.getElementById('track-panel');
const trackButtons = Array.from(document.querySelectorAll('.tab-btn[data-track]'));
const tracks = {
  'track-foundation': {
    title: 'Foundation',
    steps: [
      'ابدأ بـ hello + variables.',
      'جرّب loops و functions.',
      'نفّذ CLI بسيط.'
    ]
  },
  'track-backend': {
    title: 'Backend',
    steps: [
      'ابنِ API بـ app.get/post.',
      'استخدم params و query.',
      'أضف static files و middleware.'
    ]
  },
  'track-tooling': {
    title: 'Tooling',
    steps: [
      'فعّل LSP عبر diagnostics JSON.',
      'استخدم --watch للتطوير السريع.',
      'ابنِ snippets و tasks في VSCode.'
    ]
  }
};

const renderTrack = (trackId) => {
  const track = tracks[trackId];
  if (!track || !trackPanel) return;
  trackPanel.innerHTML = '';
  const h3 = document.createElement('h3');
  h3.textContent = track.title;
  const ol = document.createElement('ol');
  track.steps.forEach((step) => {
    const li = document.createElement('li');
    li.textContent = step;
    ol.appendChild(li);
  });
  trackPanel.appendChild(h3);
  trackPanel.appendChild(ol);
};

trackButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    trackButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    renderTrack(btn.dataset.track);
  });
});

if (trackButtons.length > 0) {
  renderTrack(trackButtons[0].dataset.track);
}

// Playground
const editor = document.querySelector('[data-playground-editor]');
const output = document.querySelector('[data-playground-output]');
const runBtn = document.querySelector('[data-playground-run]');
const resetBtn = document.querySelector('[data-playground-reset]');
const defaultCode = editor ? editor.value : '';

const splitByPlus = (expr) => {
  const parts = [];
  let buf = '';
  let quote = '';
  let escape = false;
  for (let i = 0; i < expr.length; i += 1) {
    const ch = expr[i];
    if (escape) {
      buf += ch;
      escape = false;
      continue;
    }
    if (ch === '\\') {
      buf += ch;
      escape = true;
      continue;
    }
    if ((ch === '"' || ch === "'") && !quote) {
      quote = ch;
      buf += ch;
      continue;
    }
    if (quote && ch === quote) {
      quote = '';
      buf += ch;
      continue;
    }
    if (!quote && ch === '+') {
      parts.push(buf.trim());
      buf = '';
      continue;
    }
    buf += ch;
  }
  if (buf.trim().length) parts.push(buf.trim());
  return parts;
};

const parseStringLiteral = (raw, env) => {
  const quote = raw[0];
  if (!raw.endsWith(quote)) throw new Error('Unterminated string');
  let value = raw.slice(1, -1);
  value = value
    .replace(/\\n/g, '\n')
    .replace(/\\t/g, '\t')
    .replace(/\\\\/g, '\\')
    .replace(/\\"/g, '"')
    .replace(/\\'/g, "'");
  value = value.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_, name) => {
    const v = env[name];
    return v === undefined ? '' : String(v);
  });
  return value;
};

const evalExpr = (expr, env) => {
  const trimmed = expr.trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('"') || trimmed.startsWith("'")) {
    return parseStringLiteral(trimmed, env);
  }
  if (/^-?\d+(\.\d+)?$/.test(trimmed)) {
    return String(trimmed);
  }
  if (trimmed in env) return String(env[trimmed]);
  if (trimmed.includes('+')) {
    return splitByPlus(trimmed).map((part) => evalExpr(part, env)).join('');
  }
  return trimmed;
};

const runPlayground = (code) => {
  const env = {};
  let out = '';
  const lines = code.split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith('import ') || line.startsWith('fn ') || line.endsWith(':')) {
      continue;
    }
    if (line.startsWith('let ') || line.startsWith('const ')) {
      const match = line.match(/^(let|const)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$/);
      if (match) {
        env[match[2]] = evalExpr(match[3], env);
        continue;
      }
    }
    const call = line.match(/^(print|println)\s*\((.*)\)\s*$/);
    if (call) {
      const value = evalExpr(call[2], env);
      out += value;
      if (call[1] === 'println') out += '\n';
      continue;
    }
  }
  return out || 'No output yet';
};

if (runBtn && editor && output) {
  runBtn.addEventListener('click', () => {
    try {
      output.textContent = runPlayground(editor.value);
    } catch (err) {
      output.textContent = `Error: ${err.message}`;
    }
  });
}

if (resetBtn && editor && output) {
  resetBtn.addEventListener('click', () => {
    editor.value = defaultCode;
    output.textContent = runPlayground(defaultCode);
  });
}

if (editor && output) {
  output.textContent = runPlayground(editor.value);
}

// Examples filter
const chips = Array.from(document.querySelectorAll('.chip[data-filter]'));
const exampleCards = Array.from(document.querySelectorAll('#example-grid .card'));
const applyFilter = (filter) => {
  exampleCards.forEach((card) => {
    const tags = (card.dataset.tags || '').split(/\s+/);
    const show = filter === 'all' || tags.includes(filter);
    card.style.display = show ? '' : 'none';
  });
};

chips.forEach((chip) => {
  chip.addEventListener('click', () => {
    chips.forEach((c) => c.classList.remove('active'));
    chip.classList.add('active');
    applyFilter(chip.dataset.filter || 'all');
  });
});

if (chips.length) {
  const activeChip = chips.find((chip) => chip.classList.contains('active')) || chips[0];
  applyFilter(activeChip.dataset.filter || 'all');
}

// FAQ accordion
document.querySelectorAll('.faq-q').forEach((btn) => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.faq-item');
    if (!item) return;
    item.classList.toggle('open');
  });
});

// Copy buttons
document.querySelectorAll('pre > code').forEach((code) => {
  const pre = code.parentElement;
  if (!pre) return;
  const btn = document.createElement('button');
  btn.className = 'copy-btn';
  btn.textContent = 'Copy';
  btn.addEventListener('click', async () => {
    const text = code.innerText;
    try {
      await navigator.clipboard.writeText(text);
      btn.textContent = 'Copied';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.textContent = 'Copy';
        btn.classList.remove('copied');
      }, 1200);
    } catch {
      btn.textContent = 'Failed';
      setTimeout(() => { btn.textContent = 'Copy'; }, 1200);
    }
  });
  pre.appendChild(btn);
});
