/*
 * rc-fmt — Renad C Code Formatter v1.0.0
 * Author: Mohamed Ahmed Mohamed · renad-c.dev
 *
 * Usage:
 *   rc-fmt file.rc            — format file (stdout)
 *   rc-fmt --write file.rc    — format in-place
 *   rc-fmt --check file.rc    — check if formatted (exit 1 if not)
 *   rc-fmt --diff  file.rc    — show diff
 *
 * Rules:
 *   - 4-space indentation (spaces, not tabs)
 *   - 1 space around binary operators
 *   - No trailing whitespace
 *   - 1 blank line between top-level declarations
 *   - Colon style for blocks (fn f():)
 *   - Consistent string quoting (double quotes)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#define VERSION "1.0.0"
#define MAX_LINE 4096
#define MAX_LINES 65536

#define RST   "\033[0m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define RED   "\033[1;31m"
#define CYAN  "\033[1;36m"
#define DIM   "\033[2m"
#define BOLD  "\033[1m"

typedef struct {
    char  *lines[MAX_LINES];
    int    count;
    int    indent[MAX_LINES];   /* indentation level per line */
} Source;

/* ── Read file ─────────────────────────────────────────────── */
static char *read_file(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, RED "rc-fmt: cannot open '%s'\n" RST, path); return NULL; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    char *buf = malloc(sz + 2);
    if (!buf) { fclose(f); return NULL; }
    sz = fread(buf, 1, sz, f);
    buf[sz] = '\n'; buf[sz+1] = 0;
    fclose(f);
    return buf;
}

/* ── Format a single line ──────────────────────────────────── */
static void fmt_line(const char *in, char *out) {
    /* 1. Strip leading/trailing whitespace (we re-add indent later) */
    while (*in == ' ' || *in == '\t') in++;

    int i = 0, j = 0;
    int in_str   = 0;
    int in_comm  = 0;
    char q = 0;

    while (in[i]) {
        char c = in[i];

        /* Comments — copy rest as-is */
        if (!in_str && c == '/' && in[i+1] == '/') {
            /* add space before // if needed */
            if (j > 0 && out[j-1] != ' ') out[j++] = ' ';
            while (in[i]) out[j++] = in[i++];
            break;
        }

        /* String literals — copy verbatim */
        if (!in_str && (c == '"' || c == '\'')) {
            in_str = 1; q = c; out[j++] = c; i++; continue;
        }
        if (in_str) {
            if (c == '\\') { out[j++] = c; out[j++] = in[i+1]; i+=2; continue; }
            if (c == q) { in_str = 0; }
            out[j++] = c; i++; continue;
        }

        /* Spaces around binary operators */
        if ((c=='+' || c=='-' || c=='*' || c=='/' || c=='%' ||
             c=='<' || c=='>' || c=='!' || c=='=' || c=='&' || c=='|') &&
            in[i+1] != '\0') {

            /* avoid messing with arrows -> and .. */
            if (c == '-' && in[i+1] == '>') {
                if (j>0 && out[j-1]!=' ') out[j++]=' ';
                out[j++]='-'; out[j++]='>'; i+=2;
                if (in[i] && in[i]!=' ') out[j++]=' ';
                continue;
            }
            /* two-char operators */
            char next = in[i+1];
            if ((c=='=' && next=='=') || (c=='!' && next=='=') ||
                (c=='<' && next=='=') || (c=='>' && next=='=') ||
                (c=='&' && next=='&') || (c=='|' && next=='|')) {
                if (j>0 && out[j-1]!=' ') out[j++]=' ';
                out[j++]=c; out[j++]=next; i+=2;
                if (in[i] && in[i]!=' ') out[j++]=' ';
                continue;
            }
            /* single-char, but only add space for assignment / comparison */
            if ((c=='=' || c=='<' || c=='>') && next != '=') {
                if (j>0 && out[j-1]!=' ') out[j++]=' ';
                out[j++]=c; i++;
                if (in[i] && in[i]!=' ') out[j++]=' ';
                continue;
            }
        }

        /* Collapse multiple spaces into one (outside strings) */
        if (c == ' ') {
            if (j > 0 && out[j-1] != ' ') out[j++] = ' ';
            i++; continue;
        }

        out[j++] = c; i++;
    }

    /* Strip trailing whitespace */
    while (j > 0 && (out[j-1] == ' ' || out[j-1] == '\t')) j--;
    out[j] = '\0';
}

/* ── Count leading spaces ──────────────────────────────────── */
static int leading_spaces(const char *line) {
    int n = 0;
    while (line[n] == ' ' || line[n] == '\t') n++;
    return n;
}

/* ── Normalize indentation to 4-space multiples ─────────────── */
static int normalize_indent(int spaces) {
    if (spaces == 0) return 0;
    /* round to nearest 4 */
    return ((spaces + 2) / 4) * 4;
}

/* ── Main formatter ────────────────────────────────────────── */
static char *format_source(const char *src) {
    char *result = malloc(strlen(src) * 2 + 4096);
    char linebuf[MAX_LINE], fmtbuf[MAX_LINE * 2];
    int rpos = 0;

    const char *p = src;
    int prev_was_blank = 0;
    int prev_was_toplevel = 0;

    while (*p) {
        /* Read line */
        int len = 0;
        while (*p && *p != '\n') { linebuf[len++] = *p++; }
        if (*p == '\n') p++;
        linebuf[len] = '\0';

        /* Get original indent */
        int orig_indent = leading_spaces(linebuf);
        const char *content = linebuf + orig_indent;

        /* Blank line */
        if (content[0] == '\0') {
            if (!prev_was_blank) {
                result[rpos++] = '\n';
            }
            prev_was_blank = 1;
            continue;
        }

        /* Add blank line before top-level fn/struct/class/trait/enum */
        int is_toplevel = (orig_indent == 0 &&
            (strncmp(content, "fn ", 3) == 0 ||
             strncmp(content, "async fn", 8) == 0 ||
             strncmp(content, "struct ", 7) == 0 ||
             strncmp(content, "class ",  6) == 0 ||
             strncmp(content, "trait ",  6) == 0 ||
             strncmp(content, "enum ",   5) == 0 ||
             strncmp(content, "impl ",   5) == 0));

        if (is_toplevel && prev_was_toplevel && !prev_was_blank) {
            result[rpos++] = '\n';
        }

        /* Format content */
        fmt_line(content, fmtbuf);

        /* Normalize indent to multiples of 4 */
        int norm_indent = normalize_indent(orig_indent);

        /* Write indentation */
        for (int i = 0; i < norm_indent; i++) result[rpos++] = ' ';

        /* Write formatted content */
        for (int i = 0; fmtbuf[i]; i++) result[rpos++] = fmtbuf[i];
        result[rpos++] = '\n';

        prev_was_blank    = 0;
        prev_was_toplevel = is_toplevel || (orig_indent == 0 && content[0] != '#' && content[0] != '/');
    }

    /* Ensure single trailing newline */
    while (rpos > 0 && result[rpos-1] == '\n') rpos--;
    result[rpos++] = '\n';
    result[rpos]   = '\0';
    return result;
}

/* ── Entry point ───────────────────────────────────────────── */
int main(int argc, char **argv) {
    int flag_write = 0;
    int flag_check = 0;
    int flag_diff  = 0;
    const char *filepath = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--write") == 0 || strcmp(argv[i], "-w") == 0) flag_write = 1;
        else if (strcmp(argv[i], "--check") == 0)  flag_check = 1;
        else if (strcmp(argv[i], "--diff")  == 0)  flag_diff  = 1;
        else if (strcmp(argv[i], "--version") == 0) {
            printf("rc-fmt v" VERSION " — Renad C Code Formatter\n");
            return 0;
        }
        else if (strcmp(argv[i], "--help") == 0) {
            printf(BOLD "rc-fmt" RST " v" VERSION " — Renad C Code Formatter\n\n");
            printf("Usage: rc-fmt [flags] <file.rc>\n\n");
            printf("Flags:\n");
            printf("  " CYAN "--write" RST "   Format in-place\n");
            printf("  " CYAN "--check" RST "   Exit 1 if file is not formatted\n");
            printf("  " CYAN "--diff"  RST "    Show unified diff\n");
            printf("  " CYAN "--version" RST " Show version\n\n");
            return 0;
        }
        else if (argv[i][0] != '-') filepath = argv[i];
    }

    if (!filepath) {
        /* Read from stdin */
        char *stdinbuf = malloc(1 << 20);
        int len = fread(stdinbuf, 1, (1<<20)-1, stdin);
        stdinbuf[len] = '\0';
        char *formatted = format_source(stdinbuf);
        fputs(formatted, stdout);
        free(formatted); free(stdinbuf);
        return 0;
    }

    char *src = read_file(filepath);
    if (!src) return 1;

    char *formatted = format_source(src);

    if (flag_check) {
        if (strcmp(src, formatted) == 0) {
            printf(GREEN "  ✓ " RST DIM "%s" RST " — already formatted\n", filepath);
            free(src); free(formatted);
            return 0;
        } else {
            printf(YELLOW "  ✗ " RST BOLD "%s" RST " — needs formatting\n", filepath);
            printf(DIM "  Run: rc-fmt --write %s\n" RST, filepath);
            free(src); free(formatted);
            return 1;
        }
    }

    if (flag_write) {
        FILE *f = fopen(filepath, "w");
        if (!f) {
            fprintf(stderr, RED "rc-fmt: cannot write '%s'\n" RST, filepath);
            free(src); free(formatted); return 1;
        }
        fputs(formatted, f);
        fclose(f);
        printf(GREEN "  ✓ " RST "Formatted " BOLD "%s" RST "\n", filepath);
    } else if (flag_diff) {
        /* Simple line-by-line diff */
        const char *a = src, *b = formatted;
        int lineno = 1; int diffs = 0;
        while (*a || *b) {
            char la[MAX_LINE]={0}, lb[MAX_LINE]={0};
            int i=0;
            while (*a && *a!='\n') la[i++]=*a++;
            if (*a=='\n') a++;
            i=0;
            while (*b && *b!='\n') lb[i++]=*b++;
            if (*b=='\n') b++;
            if (strcmp(la,lb)!=0) {
                if (diffs==0) printf(DIM "--- %s (original)\n+++ %s (formatted)\n" RST, filepath, filepath);
                printf(RED    "- %3d: %s\n" RST, lineno, la);
                printf(GREEN  "+ %3d: %s\n" RST, lineno, lb);
                diffs++;
            }
            lineno++;
        }
        if (diffs == 0)
            printf(GREEN "  ✓ " RST "%s is already formatted\n", filepath);
        else
            printf(DIM "\n  %d line%s differ\n" RST, diffs, diffs>1?"s":"");
    } else {
        /* Default: print to stdout */
        fputs(formatted, stdout);
    }

    free(src); free(formatted);
    return 0;
}
