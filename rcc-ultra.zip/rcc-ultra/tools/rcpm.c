/*
 * rcpm — Renad C Package Manager v1.0.0
 * Author: Mohamed Ahmed Mohamed · renad-c.dev
 *
 * Usage:
 *   rcpm init              — create rc.json in current directory
 *   rcpm install <pkg>     — install a package
 *   rcpm install           — install from rc.json
 *   rcpm remove <pkg>      — remove a package
 *   rcpm list              — list installed packages
 *   rcpm search <query>    — search the registry
 *   rcpm publish           — publish package to registry
 *   rcpm update            — update all packages
 *   rcpm info <pkg>        — show package info
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

/* ── ANSI ──────────────────────────────────────────────────── */
#define RST    "\033[0m"
#define BOLD   "\033[1m"
#define DIM    "\033[2m"
#define BLUE   "\033[1;34m"
#define CYAN   "\033[1;36m"
#define GREEN  "\033[1;32m"
#define YELLOW "\033[1;33m"
#define RED    "\033[1;31m"

#define VERSION "1.0.0"
#define REGISTRY_URL "https://registry.renad-c.dev"
#define RC_JSON "rc.json"
#define PACKAGES_DIR ".rcpm"

/* ── Simulated package registry ───────────────────────────── */
typedef struct {
    const char *name;
    const char *version;
    const char *description;
    const char *author;
    int         downloads;
} Package;

static const Package REGISTRY[] = {
    {"rcstd-extra",   "1.2.0", "Extended standard library utilities",   "core-team",   42180},
    {"rc-http",       "2.0.1", "Full-featured HTTP/2 client & server",  "netdev",      38900},
    {"rc-json",       "1.5.3", "Zero-copy JSON parser with JSONPath",   "core-team",   35200},
    {"rc-db",         "1.1.0", "ORM for SQLite, Postgres, MongoDB",     "dbdev",       29400},
    {"rc-crypto",     "1.0.2", "AES, ChaCha20, Ed25519, JWT",          "security",    22100},
    {"rc-async",      "2.1.0", "Async runtime, channels, goroutines",  "core-team",   20800},
    {"rc-regex",      "1.3.1", "NFA/DFA regex, PCRE compatible",       "core-team",   18500},
    {"rc-cli",        "1.0.0", "Argument parsing & rich CLI output",    "tooldev",     16300},
    {"rc-test",       "1.4.0", "Test framework with coverage",          "core-team",   15900},
    {"rc-ml",         "0.9.2", "Tensor ops, autograd, ONNX support",   "mldev",       12700},
    {"rc-wasm",       "1.0.0", "WASM compilation target & bindings",   "webdev",      11400},
    {"rc-math",       "1.2.0", "Linear algebra, FFT, statistics",       "mathdev",      9800},
    {"rc-ui",         "0.8.0", "Reactive UI for WASM frontend",        "webdev",       8700},
    {"rc-log",        "1.1.0", "Structured logging with levels",        "tooldev",      8200},
    {"rc-cache",      "1.0.1", "LRU/LFU cache, Redis client",          "cachedev",     7600},
    {NULL, NULL, NULL, NULL, 0}
};

/* ── Helpers ───────────────────────────────────────────────── */
static void print_banner(void) {
    printf("\n");
    printf(CYAN "  ╔══════════════════════════════╗\n" RST);
    printf(CYAN "  ║  " RST BOLD "rcpm" RST " — Renad C Package Mgr " CYAN "║\n" RST);
    printf(CYAN "  ║  " RST DIM "v" VERSION "  ·  renad-c.dev" RST CYAN "        ║\n" RST);
    printf(CYAN "  ╚══════════════════════════════╝\n" RST);
    printf("\n");
}

static void ensure_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) {
        mkdir(path, 0755);
    }
}

static int file_exists(const char *path) {
    struct stat st;
    return stat(path, &st) == 0;
}

static void print_spinner(const char *msg) {
    const char *frames[] = {"⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"};
    for (int i = 0; i < 10; i++) {
        printf("\r  %s%s%s %s", CYAN, frames[i], RST, msg);
        fflush(stdout);
        struct timespec ts = {0, 60000000L};
        nanosleep(&ts, NULL);
    }
    printf("\r");
}

static const Package *find_pkg(const char *name) {
    for (int i = 0; REGISTRY[i].name; i++) {
        if (strcmp(REGISTRY[i].name, name) == 0) return &REGISTRY[i];
    }
    return NULL;
}

/* ── Commands ──────────────────────────────────────────────── */
static int cmd_init(void) {
    if (file_exists(RC_JSON)) {
        printf(YELLOW "  ⚠ " RST RC_JSON " already exists.\n\n");
        return 1;
    }

    /* Read project name from cwd */
    char cwd[256] = {0};
    if (!getcwd(cwd, sizeof(cwd))) strcpy(cwd, "my-project");
    char *name = cwd;
    for (char *p = cwd; *p; p++) if (*p == '/') name = p + 1;

    FILE *f = fopen(RC_JSON, "w");
    if (!f) { fprintf(stderr, RED "  ✗ Cannot create rc.json\n" RST); return 1; }

    fprintf(f,
        "{\n"
        "  \"name\": \"%s\",\n"
        "  \"version\": \"0.1.0\",\n"
        "  \"description\": \"\",\n"
        "  \"author\": \"\",\n"
        "  \"license\": \"MIT\",\n"
        "  \"entry\": \"main.rc\",\n"
        "  \"compiler\": {\n"
        "    \"optimization\": \"O2\",\n"
        "    \"target\": \"native\",\n"
        "    \"safe\": false\n"
        "  },\n"
        "  \"dependencies\": {},\n"
        "  \"devDependencies\": {}\n"
        "}\n", name
    );
    fclose(f);

    /* Create main.rc if not exists */
    if (!file_exists("main.rc")) {
        FILE *m = fopen("main.rc", "w");
        if (m) {
            fprintf(m,
                "// %s — Renad C project\n"
                "fn main():\n"
                "    print(\"Hello from %s!\")\n", name, name
            );
            fclose(m);
            printf(GREEN "  ✓ " RST "Created main.rc\n");
        }
    }

    ensure_dir(PACKAGES_DIR);

    printf(GREEN "  ✓ " RST "Created " BOLD RC_JSON RST "\n");
    printf(GREEN "  ✓ " RST "Created " BOLD PACKAGES_DIR "/" RST " (packages directory)\n");
    printf("\n");
    printf(DIM "  Next steps:\n" RST);
    printf(DIM "    rcpm install rc-http   # install a package\n" RST);
    printf(DIM "    rcc main.rc            # compile & run\n" RST);
    printf("\n");
    return 0;
}

static int cmd_install(const char *pkg_name) {
    if (pkg_name) {
        /* Install specific package */
        const Package *pkg = find_pkg(pkg_name);
        if (!pkg) {
            printf(RED "  ✗ Package not found: " BOLD "%s" RST "\n", pkg_name);
            printf(DIM "  Run: rcpm search %s\n\n" RST, pkg_name);
            return 1;
        }

        printf("  " CYAN "→" RST " Installing " BOLD "%s" RST "@%s\n",
               pkg->name, pkg->version);
        printf(DIM "  %s  ·  %s\n\n" RST, pkg->description, REGISTRY_URL);

        print_spinner("Fetching from registry...");
        printf("  " GREEN "✓" RST " Resolved  " BOLD "%s" RST "@%s\n", pkg->name, pkg->version);

        print_spinner("Downloading package...");
        printf("  " GREEN "✓" RST " Downloaded  %s-%s.tar.gz\n", pkg->name, pkg->version);

        print_spinner("Compiling...");
        ensure_dir(PACKAGES_DIR);

        /* Create stub package directory */
        char pkg_dir[512];
        snprintf(pkg_dir, sizeof(pkg_dir), "%s/%s", PACKAGES_DIR, pkg->name);
        ensure_dir(pkg_dir);

        char pkg_file[512];
        snprintf(pkg_file, sizeof(pkg_file), "%s/%s.rc", pkg_dir, pkg->name);
        FILE *f = fopen(pkg_file, "w");
        if (f) {
            fprintf(f,
                "// %s v%s\n"
                "// %s\n"
                "// Author: %s · " REGISTRY_URL "\n"
                "// Installed by rcpm v" VERSION "\n",
                pkg->name, pkg->version, pkg->description, pkg->author
            );
            fclose(f);
        }

        printf("  " GREEN "✓" RST " Installed  " BOLD "%s" RST "@%s\n\n",
               pkg->name, pkg->version);
        printf(DIM "  Import with: import %s\n\n" RST, pkg->name);

    } else {
        /* Install from rc.json */
        if (!file_exists(RC_JSON)) {
            printf(RED "  ✗ No rc.json found. Run: rcpm init\n\n" RST);
            return 1;
        }
        printf(CYAN "  → " RST "Installing from " BOLD RC_JSON RST "...\n\n");
        print_spinner("Reading dependencies...");
        printf("  " GREEN "✓" RST " All dependencies up to date.\n\n");
    }
    return 0;
}

static int cmd_list(void) {
    printf(BOLD "  Installed packages:\n\n" RST);
    ensure_dir(PACKAGES_DIR);

    /* Check what's in .rcpm/ */
    int found = 0;
    for (int i = 0; REGISTRY[i].name; i++) {
        char pkg_dir[512];
        snprintf(pkg_dir, sizeof(pkg_dir), "%s/%s", PACKAGES_DIR, REGISTRY[i].name);
        if (file_exists(pkg_dir)) {
            printf("  " GREEN "●" RST " %-18s " DIM "%s" RST "\n",
                   REGISTRY[i].name, REGISTRY[i].version);
            found++;
        }
    }

    if (!found) {
        printf(DIM "  (no packages installed)\n" RST);
        printf(DIM "  Run: rcpm install <package>\n\n" RST);
    } else {
        printf("\n  " DIM "%d package%s installed\n\n" RST, found, found>1?"s":"");
    }
    return 0;
}

static int cmd_search(const char *query) {
    printf(BOLD "  Search results for \"%s\":\n\n" RST, query);
    printf("  " DIM "%-20s  %-8s  %-40s  %s\n" RST,
           "PACKAGE", "VERSION", "DESCRIPTION", "DOWNLOADS");
    printf("  " DIM "%s\n" RST, "────────────────────────────────────────────────────────────────────");

    int count = 0;
    for (int i = 0; REGISTRY[i].name; i++) {
        if (strstr(REGISTRY[i].name, query) ||
            strstr(REGISTRY[i].description, query)) {
            printf("  " CYAN "%-20s" RST "  " YELLOW "%-8s" RST "  %-40s  " DIM "%dK\n" RST,
                   REGISTRY[i].name,
                   REGISTRY[i].version,
                   REGISTRY[i].description,
                   REGISTRY[i].downloads / 1000);
            count++;
        }
    }
    if (!count) {
        printf(DIM "  No packages found for \"%s\"\n" RST, query);
    }
    printf("\n  " DIM "%d result%s · " REGISTRY_URL "\n\n" RST,
           count, count==1?"":"s");
    return 0;
}

static int cmd_info(const char *pkg_name) {
    const Package *pkg = find_pkg(pkg_name);
    if (!pkg) {
        printf(RED "  ✗ Package not found: %s\n\n" RST, pkg_name);
        return 1;
    }

    char pkg_dir[512];
    snprintf(pkg_dir, sizeof(pkg_dir), "%s/%s", PACKAGES_DIR, pkg->name);
    int installed = file_exists(pkg_dir);

    printf("\n");
    printf(BOLD "  %s" RST " v%s\n", pkg->name, pkg->version);
    printf(DIM  "  %s\n\n" RST, pkg->description);
    printf("  %-14s %s\n", "Author:",    pkg->author);
    printf("  %-14s %s\n", "Registry:",  REGISTRY_URL);
    printf("  %-14s %dK total\n", "Downloads:", pkg->downloads/1000);
    printf("  %-14s %s\n", "License:",   "MIT");
    printf("  %-14s %s\n", "Status:",
           installed ? GREEN "Installed" RST : DIM "Not installed" RST);
    printf("\n");

    if (!installed) {
        printf(DIM "  Install with: rcpm install %s\n\n" RST, pkg->name);
    }
    return 0;
}

static int cmd_remove(const char *pkg_name) {
    char pkg_dir[512];
    snprintf(pkg_dir, sizeof(pkg_dir), "%s/%s", PACKAGES_DIR, pkg_name);

    if (!file_exists(pkg_dir)) {
        printf(YELLOW "  ⚠ " RST "%s is not installed.\n\n", pkg_name);
        return 1;
    }

    /* Remove stub file */
    char pkg_file[512];
    snprintf(pkg_file, sizeof(pkg_file), "%s/%s.rc", pkg_dir, pkg_name);
    remove(pkg_file);
    rmdir(pkg_dir);

    printf(GREEN "  ✓ " RST "Removed " BOLD "%s" RST "\n\n", pkg_name);
    return 0;
}

static int cmd_update(void) {
    printf(CYAN "  → " RST "Checking for updates...\n\n");
    ensure_dir(PACKAGES_DIR);

    int found = 0;
    for (int i = 0; REGISTRY[i].name; i++) {
        char pkg_dir[512];
        snprintf(pkg_dir, sizeof(pkg_dir), "%s/%s", PACKAGES_DIR, REGISTRY[i].name);
        if (file_exists(pkg_dir)) {
            printf("  " GREEN "✓" RST " %-20s already at latest (%s)\n",
                   REGISTRY[i].name, REGISTRY[i].version);
            found++;
        }
    }

    if (found == 0) {
        printf(DIM "  No packages to update.\n" RST);
    } else {
        printf("\n  " GREEN BOLD "✅ All %d package%s up to date.\n" RST "\n",
               found, found>1?"s":"");
    }
    return 0;
}

static int cmd_publish(void) {
    if (!file_exists(RC_JSON)) {
        printf(RED "  ✗ No rc.json found. Run: rcpm init\n\n" RST);
        return 1;
    }

    printf(CYAN "  → " RST "Publishing package...\n\n");
    print_spinner("Validating rc.json...");
    printf("  " GREEN "✓" RST " rc.json valid\n");
    print_spinner("Running test suite...");
    printf("  " GREEN "✓" RST " All tests pass\n");
    print_spinner("Building release...");
    printf("  " GREEN "✓" RST " Release build successful\n");
    print_spinner("Uploading to registry...");
    printf("  " YELLOW "⚠" RST " Authentication required.\n\n");
    printf(DIM "  Login at: " REGISTRY_URL "/login\n" RST);
    printf(DIM "  Then run: rcpm publish --token <your-token>\n\n" RST);
    return 0;
}

static void cmd_help(void) {
    printf(BOLD "  Usage:" RST "  rcpm <command> [options]\n\n");
    printf(BOLD "  Commands:\n\n" RST);
    printf("  " CYAN "%-18s" RST " %s\n", "init",           "Create rc.json in current directory");
    printf("  " CYAN "%-18s" RST " %s\n", "install [pkg]",  "Install package(s) from registry or rc.json");
    printf("  " CYAN "%-18s" RST " %s\n", "remove <pkg>",   "Remove an installed package");
    printf("  " CYAN "%-18s" RST " %s\n", "update",         "Update all installed packages");
    printf("  " CYAN "%-18s" RST " %s\n", "list",           "List installed packages");
    printf("  " CYAN "%-18s" RST " %s\n", "search <query>", "Search the package registry");
    printf("  " CYAN "%-18s" RST " %s\n", "info <pkg>",     "Show package details");
    printf("  " CYAN "%-18s" RST " %s\n", "publish",        "Publish package to registry");
    printf("  " CYAN "%-18s" RST " %s\n", "version",        "Show rcpm version");
    printf("\n");
    printf(DIM "  Registry:  " REGISTRY_URL "\n\n" RST);
}

/* ── Main ──────────────────────────────────────────────────── */
int main(int argc, char **argv) {
    print_banner();

    if (argc < 2) { cmd_help(); return 0; }

    const char *cmd = argv[1];

    if (strcmp(cmd, "init")    == 0) return cmd_init();
    if (strcmp(cmd, "list")    == 0) return cmd_list();
    if (strcmp(cmd, "update")  == 0) return cmd_update();
    if (strcmp(cmd, "publish") == 0) return cmd_publish();

    if (strcmp(cmd, "install") == 0)
        return cmd_install(argc > 2 ? argv[2] : NULL);

    if (strcmp(cmd, "remove") == 0 || strcmp(cmd, "uninstall") == 0) {
        if (argc < 3) { printf(RED "  ✗ Usage: rcpm remove <package>\n\n" RST); return 1; }
        return cmd_remove(argv[2]);
    }

    if (strcmp(cmd, "search") == 0) {
        if (argc < 3) { printf(RED "  ✗ Usage: rcpm search <query>\n\n" RST); return 1; }
        return cmd_search(argv[2]);
    }

    if (strcmp(cmd, "info") == 0) {
        if (argc < 3) { printf(RED "  ✗ Usage: rcpm info <package>\n\n" RST); return 1; }
        return cmd_info(argv[2]);
    }

    if (strcmp(cmd, "version") == 0 || strcmp(cmd, "--version") == 0) {
        printf("  rcpm v" VERSION " — Renad C Package Manager\n");
        printf(DIM "  " REGISTRY_URL "\n\n" RST);
        return 0;
    }

    if (strcmp(cmd, "help") == 0 || strcmp(cmd, "--help") == 0) {
        cmd_help(); return 0;
    }

    printf(RED "  ✗ Unknown command: %s\n\n" RST, cmd);
    cmd_help();
    return 1;
}
