/* ============================================================
 * Renad C Compiler — Code Generator
 * Target: C source (compiled by gcc to native binary)
 * Creator: Mohamed Ahmed Mohamed
 * ============================================================ */
#include "codegen.h"
#include "ast.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

static int g_lambda_id = 0;

static void rc_toupper_buf(const char *s, char *b, int bsz){
    int i=0;
    for(;s[i]&&i<bsz-1;i++) b[i]=(char)((s[i]>='a'&&s[i]<='z')?s[i]-32:s[i]);
    b[i]=0;
}
/* Two permanent uppercase buffers so dual calls in one emitl don't collide */
static char _rcu_a[256];
static char _rcu_b[256];
static int  _rcu_flip = 0;
static char *rc_toupper(const char *s){
    char *b = (_rcu_flip ^= 1) ? _rcu_a : _rcu_b;
    rc_toupper_buf(s, b, 256);
    return b;
}


/* ── Forward declarations ──────────────────────────────────── */
/* ── Safe C identifier for RC names ──────────────────────── */
static const char *safe_c_name(const char *name) {
    /* C keywords that RC allows as function names */
    static const char *reserved[] = {
        "double", "float", "int", "char", "long", "short", "void",
        "struct", "enum", "union", "static", "extern", "auto",
        "register", "const", "volatile", "signed", "unsigned",
        "return", "if", "else", "for", "while", "do", "switch",
        "case", "break", "continue", "goto", "default", "sizeof",
        "typedef", "inline", "restrict", NULL
    };
    if (!name) return "anon";
    for (int i = 0; reserved[i]; i++) {
        if (strcmp(name, reserved[i]) == 0) {
            static char safe[128];
            snprintf(safe, sizeof(safe), "rc_%s", name);
            return safe;
        }
    }
    return name;
}


static void gen_stmt(CodeGen *cg, AstNode *node);
static void gen_expr(CodeGen *cg, AstNode *node);
static void gen_block(CodeGen *cg, AstNode *node);

/* ── Constructor ───────────────────────────────────────────── */
CodeGen *codegen_new(FILE *out) {
    CodeGen *cg = calloc(1, sizeof(CodeGen));
    cg->out = out;
    return cg;
}
void codegen_free(CodeGen *cg) { free(cg); }

/* ── Indent helpers ────────────────────────────────────────── */
static void indent(CodeGen *cg) {
    for (int i = 0; i < cg->indent; i++) fprintf(cg->out, "    ");
}

static void emit(CodeGen *cg, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(cg->out, fmt, ap);
    va_end(ap);
}

static void emitl(CodeGen *cg, const char *fmt, ...) {
    indent(cg);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(cg->out, fmt, ap);
    va_end(ap);
    fprintf(cg->out, "\n");
}

static void emit_raw(CodeGen *cg, const char *s) {
    fputs(s, cg->out);
}
static void emitl_raw(CodeGen *cg, const char *s) {
    for(int i=0;i<cg->indent;i++) fputs("    ", cg->out);
    fputs(s, cg->out);
    fputs("\n", cg->out);
}


/* ── Type mapping: RC type → C type ───────────────────────── */
static const char *rc_type_to_c(const char *t) {
    if (!t) return "void*";
    if (strcmp(t, "int")   == 0) return "long long";
    if (strcmp(t, "int32") == 0) return "int";
    if (strcmp(t, "int64") == 0) return "long long";
    if (strcmp(t, "float") == 0) return "double";
    if (strcmp(t, "float64")==0) return "double";
    if (strcmp(t, "float32")==0) return "float";
    if (strcmp(t, "bool")  == 0) return "int";
    if (strcmp(t, "str")   == 0) return "const char*";
    if (strcmp(t, "void")  == 0) return "void";
    if (strcmp(t, "byte")  == 0) return "unsigned char";
    if (strcmp(t, "RCRequest") == 0) return "RCRequest*";
    if (strcmp(t, "RCResponse") == 0) return "RCResponse*";
    if (strcmp(t, "RCApp") == 0) return "RCApp";
    return t; /* user-defined types pass through */
}

static const char *type_node_to_c(AstNode *t) {
    if (!t) return "long long";
    if (t->type == NODE_TYPE_NAME) return rc_type_to_c(t->sval);
    if (t->type == NODE_TYPE_GENERIC && t->sval) {
        if (strcmp(t->sval, "Option") == 0 ||
            strcmp(t->sval, "Result") == 0) return "void*";
        return "void*";
    }
    if (t->type == NODE_TYPE_ARRAY) return "void*";
    return "long long";
}

/* ── String interpolation processing ──────────────────────────────────
 * Converts: "Hello ${name} you are ${age} years old"
 *       to: printf("Hello %s you are %s years old\n", rc_tostr(name), rc_tostr(age))
 * Smart: detects integer/float expressions and uses %lld/%g when possible.
 * ────────────────────────────────────────────────────────────────────── */
static int has_interpolation(const char *s) {
    for (; *s; s++) if (*s == '$' && *(s+1) == '{') return 1;
    return 0;
}

/* Build printf format string, writing to fmt_buf. Returns number of exprs found. */
static int build_interp_fmt(const char *s, char *fmt_buf, int fmax,
                             char exprs[][256], int emax) {
    int fi = 0, ei = 0, i = 0, n = (int)strlen(s);
    while (i < n && fi < fmax - 4) {
        if (s[i] == '$' && i+1 < n && s[i+1] == '{') {
            /* Extract expression inside ${...} */
            i += 2;
            int xi = 0;
            while (i < n && s[i] != '}' && xi < 255) exprs[ei][xi++] = s[i++];
            exprs[ei][xi] = '\0';
            if (i < n) i++; /* skip } */
            /* Use %s for all — rc_tostr handles int/float/string */
            fmt_buf[fi++] = '%'; fmt_buf[fi++] = 's';
            if (ei < emax - 1) ei++;
        } else if (s[i] == '%') {
            /* Escape % for printf */
            fmt_buf[fi++] = '%'; fmt_buf[fi++] = '%'; i++;
        } else if (s[i] == '\\' && i+1 < n) {
            /* Pass through escape sequences */
            fmt_buf[fi++] = '\\'; fmt_buf[fi++] = s[i+1]; i += 2;
        } else if (s[i] == '"') {
            fmt_buf[fi++] = '\\'; fmt_buf[fi++] = '"'; i++;
        } else {
            fmt_buf[fi++] = s[i++];
        }
    }
    fmt_buf[fi] = '\0';
    return ei;
}

static void emit_interp_string(CodeGen *cg, const char *s) {
    if (!has_interpolation(s)) {
        emit(cg, "\"");
        for (const char *p = s; *p; p++) {
            if (*p == '"')       emit(cg, "\\\"");
            else if (*p == '\\') emit(cg, "\\\\");
            else if (*p == '%')  emit(cg, "%%%%");
            else                 emit(cg, "%c", *p);
        }
        emit(cg, "\"");
        return;
    }
    char fmt_buf[4096];
    char exprs[64][256];
    int nexprs = build_interp_fmt(s, fmt_buf, sizeof(fmt_buf), exprs, 64);
    /* Emit as rc_sprintf("fmt", rc_tostr(e1), rc_tostr(e2), ...) */
    emit(cg, "rc_sprintf(\"%s\"", fmt_buf);
    for (int i = 0; i < nexprs; i++) {
        emit(cg, ", rc_tostr(%s)", exprs[i]);
    }
    emit(cg, ")");
}

/* ── HTTP server emission ──────────────────────────────────── */
static void emit_http_server_impl(CodeGen *cg) {
    /* Embedded minimal HTTP server (POSIX sockets) */
    fprintf(cg->out, "/* ---- Embedded HTTP Server (rcstd.net) ---- */\n");
    fprintf(cg->out, "#include <sys/socket.h>\n");
    fprintf(cg->out, "#include <netinet/in.h>\n");
    fprintf(cg->out, "#include <arpa/inet.h>\n");
    fprintf(cg->out, "#include <sys/stat.h>\n");
    fprintf(cg->out, "#include <unistd.h>\n");
    fprintf(cg->out, "typedef struct { const char *key; const char *value; } RCPair;\n");
    fprintf(cg->out, "typedef struct {\n");
    fprintf(cg->out, "    const char *method;\n");
    fprintf(cg->out, "    const char *path;\n");
    fprintf(cg->out, "    const char *body;\n");
    fprintf(cg->out, "    char method_buf[8];\n");
    fprintf(cg->out, "    char path_buf[256];\n");
    fprintf(cg->out, "    char body_buf[2048];\n");
    fprintf(cg->out, "    int header_count;\n");
    fprintf(cg->out, "    RCPair headers[32];\n");
    fprintf(cg->out, "    int query_count;\n");
    fprintf(cg->out, "    RCPair query[32];\n");
    fprintf(cg->out, "    char query_keys[32][32];\n");
    fprintf(cg->out, "    char query_vals[32][64];\n");
    fprintf(cg->out, "    int param_count;\n");
    fprintf(cg->out, "    RCPair params[32];\n");
    fprintf(cg->out, "    char param_keys[32][32];\n");
    fprintf(cg->out, "    char param_vals[32][64];\n");
    fprintf(cg->out, "} RCRequest;\n");
    fprintf(cg->out, "typedef struct { int fd; int status; char headers[1024]; int headers_len; } RCResponse;\n");
    fprintf(cg->out, "typedef struct { int _dummy; } RCApp;\n");
    fprintf(cg->out, "static RCApp app_create(void) { RCApp a = {0}; return a; }\n");
    fprintf(cg->out, "typedef struct { const char *prefix; const char *dir; } StaticMount;\n");
    fprintf(cg->out, "static StaticMount _static_mounts[16]; static int _static_count = 0;\n");
    fprintf(cg->out, "typedef void (*RouteHandler)(RCRequest*, RCResponse*);\n");
    fprintf(cg->out, "typedef struct { const char *method; const char *path; RouteHandler handler; } Route;\n");
    fprintf(cg->out, "static Route _routes[128]; static int _route_count = 0;\n");
    fprintf(cg->out, "static RouteHandler _middlewares[64]; static int _mw_count = 0;\n");
    fprintf(cg->out, "static void app_use(RouteHandler h) { if (_mw_count < 64) _middlewares[_mw_count++] = h; }\n");
    fprintf(cg->out, "static void app_route(const char *method, const char *path, RouteHandler h) {\n");
    fprintf(cg->out, "    if (_route_count < 128) _routes[_route_count++] = (Route){method, path, h};\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void app_get(const char *path, RouteHandler h) { app_route(\"GET\", path, h); }\n");
    fprintf(cg->out, "static void app_post(const char *path, RouteHandler h) { app_route(\"POST\", path, h); }\n");
    fprintf(cg->out, "static void app_put(const char *path, RouteHandler h) { app_route(\"PUT\", path, h); }\n");
    fprintf(cg->out, "static void app_delete(const char *path, RouteHandler h) { app_route(\"DELETE\", path, h); }\n");
    fprintf(cg->out, "static void app_static(const char *prefix, const char *dir) {\n");
    fprintf(cg->out, "    if (_static_count < 16) _static_mounts[_static_count++] = (StaticMount){prefix, dir};\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_status(RCResponse *res, int status) { if (res) res->status = status; }\n");
    fprintf(cg->out, "static void rc_res_header(RCResponse *res, const char *k, const char *v) {\n");
    fprintf(cg->out, "    if (!res || !k || !v) return;\n");
    fprintf(cg->out, "    char line[256]; snprintf(line, sizeof(line), \"%%s: %%s\\r\\n\", k, v);\n");
    fprintf(cg->out, "    strncat(res->headers, line, sizeof(res->headers)-strlen(res->headers)-1);\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_send(RCResponse *res, const char *body, const char *ctype) {\n");
    fprintf(cg->out, "    if (!res) return; if (!body) body = \"\"; if (!ctype) ctype = \"text/plain; charset=utf-8\";\n");
    fprintf(cg->out, "    int len = (int)strlen(body);\n");
    fprintf(cg->out, "    char head[1400];\n");
    fprintf(cg->out, "    int hlen = snprintf(head, sizeof(head), \"HTTP/1.1 %%d OK\\r\\nContent-Type: %%s\\r\\nContent-Length: %%d\\r\\n%%s\\r\\n\", res->status, ctype, len, res->headers);\n");
    fprintf(cg->out, "    write(res->fd, head, hlen); if (len > 0) write(res->fd, body, len);\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_json(RCResponse *res, const char *json) {\n");
    fprintf(cg->out, "    rc_res_header(res, \"Access-Control-Allow-Origin\", \"*\");\n");
    fprintf(cg->out, "    rc_res_send(res, json ? json : \"\", \"application/json\");\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_text(RCResponse *res, const char *text) {\n");
    fprintf(cg->out, "    rc_res_send(res, text ? text : \"\", \"text/plain; charset=utf-8\");\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_html(RCResponse *res, const char *html) {\n");
    fprintf(cg->out, "    rc_res_send(res, html ? html : \"\", \"text/html; charset=utf-8\");\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_redirect(RCResponse *res, const char *url) {\n");
    fprintf(cg->out, "    if (!url) url = \"/\"; rc_res_status(res, 302); rc_res_header(res, \"Location\", url);\n");
    fprintf(cg->out, "    rc_res_send(res, \"\", \"text/plain; charset=utf-8\");\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static const char *rc_mime(const char *path) {\n");
    fprintf(cg->out, "    const char *ext = strrchr(path, '.');\n");
    fprintf(cg->out, "    if (!ext) return \"application/octet-stream\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".html\") || !strcmp(ext, \".htm\")) return \"text/html; charset=utf-8\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".css\"))  return \"text/css; charset=utf-8\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".js\"))   return \"application/javascript\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".json\")) return \"application/json\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".png\"))  return \"image/png\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".jpg\") || !strcmp(ext, \".jpeg\")) return \"image/jpeg\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".svg\"))  return \"image/svg+xml\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".ico\"))  return \"image/x-icon\";\n");
    fprintf(cg->out, "    if (!strcmp(ext, \".txt\"))  return \"text/plain; charset=utf-8\";\n");
    fprintf(cg->out, "    return \"application/octet-stream\";\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static int rc_send_file(RCResponse *res, const char *full) {\n");
    fprintf(cg->out, "    FILE *f = fopen(full, \"rb\"); if (!f) return 0;\n");
    fprintf(cg->out, "    fseek(f, 0, SEEK_END); long size = ftell(f); rewind(f);\n");
    fprintf(cg->out, "    if (size < 0) { fclose(f); return 0; }\n");
    fprintf(cg->out, "    char *buf = (char*)malloc((size_t)size);\n");
    fprintf(cg->out, "    if (!buf) { fclose(f); return 0; }\n");
    fprintf(cg->out, "    fread(buf, 1, (size_t)size, f); fclose(f);\n");
    fprintf(cg->out, "    const char *mime = rc_mime(full);\n");
    fprintf(cg->out, "    char header[512];\n");
    fprintf(cg->out, "    int hlen = snprintf(header, sizeof(header), \"HTTP/1.1 %%d OK\\r\\nContent-Type: %%s\\r\\nContent-Length: %%ld\\r\\n%%s\\r\\n\", res->status, mime, size, res->headers);\n");
    fprintf(cg->out, "    write(res->fd, header, hlen); write(res->fd, buf, (size_t)size); free(buf);\n");
    fprintf(cg->out, "    return 1;\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_res_file(RCResponse *res, const char *path) {\n");
    fprintf(cg->out, "    if (!path || strstr(path, \"..\")) { rc_res_status(res, 404); rc_res_send(res, \"Not Found\", \"text/plain; charset=utf-8\"); return; }\n");
    fprintf(cg->out, "    if (!rc_send_file(res, path)) { rc_res_status(res, 404); rc_res_send(res, \"Not Found\", \"text/plain; charset=utf-8\"); }\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static int serve_static(const char *req_path, RCResponse *res) {\n");
    fprintf(cg->out, "    if (!req_path || req_path[0] != '/') return 0;\n");
    fprintf(cg->out, "    if (strstr(req_path, \"..\")) return 0;\n");
    fprintf(cg->out, "    for (int i=0; i<_static_count; i++) {\n");
    fprintf(cg->out, "        const char *prefix = _static_mounts[i].prefix ? _static_mounts[i].prefix : \"/\";\n");
    fprintf(cg->out, "        const char *dir = _static_mounts[i].dir ? _static_mounts[i].dir : \".\";\n");
    fprintf(cg->out, "        const char *rel = req_path;\n");
    fprintf(cg->out, "        if (strcmp(prefix, \"/\") != 0) {\n");
    fprintf(cg->out, "            size_t plen = strlen(prefix);\n");
    fprintf(cg->out, "            if (strncmp(req_path, prefix, plen) != 0) continue;\n");
    fprintf(cg->out, "            rel = req_path + plen;\n");
    fprintf(cg->out, "            if (rel[0] == '\\0') rel = \"/\";\n");
    fprintf(cg->out, "        }\n");
    fprintf(cg->out, "        if (rel[0] == '/') rel++;\n");
    fprintf(cg->out, "        char full[512];\n");
    fprintf(cg->out, "        if (rel[0] == '\\0') snprintf(full, sizeof(full), \"%%s\", dir);\n");
    fprintf(cg->out, "        else snprintf(full, sizeof(full), \"%%s/%%s\", dir, rel);\n");
    fprintf(cg->out, "        struct stat st;\n");
    fprintf(cg->out, "        if (stat(full, &st) == 0 && S_ISDIR(st.st_mode)) {\n");
    fprintf(cg->out, "            size_t fl = strlen(full);\n");
    fprintf(cg->out, "            if (fl + 11 < sizeof(full)) { strcat(full, \"/index.html\"); }\n");
    fprintf(cg->out, "        } else {\n");
    fprintf(cg->out, "            size_t fl = strlen(full);\n");
    fprintf(cg->out, "            if (fl > 0 && full[fl-1] == '/' && fl + 10 < sizeof(full)) strcat(full, \"index.html\");\n");
    fprintf(cg->out, "        }\n");
    fprintf(cg->out, "        if (rc_send_file(res, full)) return 1;\n");
    fprintf(cg->out, "    }\n");
    fprintf(cg->out, "    return 0;\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_req_add_query(RCRequest *req, const char *k, const char *v) {\n");
    fprintf(cg->out, "    if (!req || !k || !v) return; int i = req->query_count; if (i >= 32) return;\n");
    fprintf(cg->out, "    strncpy(req->query_keys[i], k, 31); req->query_keys[i][31] = 0;\n");
    fprintf(cg->out, "    strncpy(req->query_vals[i], v, 63); req->query_vals[i][63] = 0;\n");
    fprintf(cg->out, "    req->query[i] = (RCPair){req->query_keys[i], req->query_vals[i]}; req->query_count++;\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_req_add_param(RCRequest *req, const char *k, const char *v) {\n");
    fprintf(cg->out, "    if (!req || !k || !v) return; int i = req->param_count; if (i >= 32) return;\n");
    fprintf(cg->out, "    strncpy(req->param_keys[i], k, 31); req->param_keys[i][31] = 0;\n");
    fprintf(cg->out, "    strncpy(req->param_vals[i], v, 63); req->param_vals[i][63] = 0;\n");
    fprintf(cg->out, "    req->params[i] = (RCPair){req->param_keys[i], req->param_vals[i]}; req->param_count++;\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void rc_parse_query(RCRequest *req, char *q) {\n");
    fprintf(cg->out, "    char *p = q; while (p && *p) {\n");
    fprintf(cg->out, "        char *amp = strchr(p, '&'); if (amp) *amp = '\\0';\n");
    fprintf(cg->out, "        char *eq = strchr(p, '='); if (eq) { *eq = '\\0'; rc_req_add_query(req, p, eq+1); }\n");
    fprintf(cg->out, "        else rc_req_add_query(req, p, \"\");\n");
    fprintf(cg->out, "        if (!amp) break; p = amp + 1; }\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static const char *rc_req_query(RCRequest *req, const char *key) {\n");
    fprintf(cg->out, "    if (!req || !key) return \"\";\n");
    fprintf(cg->out, "    for (int i=0;i<req->query_count;i++) if (strcmp(req->query[i].key,key)==0) return req->query[i].value;\n");
    fprintf(cg->out, "    return \"\";\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static const char *rc_req_param(RCRequest *req, const char *key) {\n");
    fprintf(cg->out, "    if (!req || !key) return \"\";\n");
    fprintf(cg->out, "    for (int i=0;i<req->param_count;i++) if (strcmp(req->params[i].key,key)==0) return req->params[i].value;\n");
    fprintf(cg->out, "    return \"\";\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static const char *rc_req_header(RCRequest *req, const char *key) {\n");
    fprintf(cg->out, "    if (!req || !key) return \"\";\n");
    fprintf(cg->out, "    for (int i=0;i<req->header_count;i++) if (strcmp(req->headers[i].key,key)==0) return req->headers[i].value;\n");
    fprintf(cg->out, "    return \"\";\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static char *rc_next_seg(char **s) {\n");
    fprintf(cg->out, "    if (!s || !*s) return NULL; char *start = *s; if (*start=='/') start++; if (*start=='\\0') { *s=NULL; return NULL; }\n");
    fprintf(cg->out, "    char *end = strchr(start, '/'); if (end) { *end='\\0'; *s=end+1; } else { *s=NULL; }\n");
    fprintf(cg->out, "    return start;\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static int rc_match_route(const char *route_path, const char *req_path, RCRequest *req) {\n");
    fprintf(cg->out, "    if (!route_path || !req_path) return 0; req->param_count = 0;\n");
    fprintf(cg->out, "    if (strcmp(route_path, \"/\") == 0 && strcmp(req_path, \"/\") == 0) return 1;\n");
    fprintf(cg->out, "    char rbuf[256]; char pbuf[256];\n");
    fprintf(cg->out, "    snprintf(rbuf, sizeof(rbuf), \"%%s\", route_path);\n");
    fprintf(cg->out, "    snprintf(pbuf, sizeof(pbuf), \"%%s\", req_path);\n");
    fprintf(cg->out, "    char *rs = rbuf; char *ps = pbuf;\n");
    fprintf(cg->out, "    while (1) {\n");
    fprintf(cg->out, "        char *rseg = rc_next_seg(&rs);\n");
    fprintf(cg->out, "        char *pseg = rc_next_seg(&ps);\n");
    fprintf(cg->out, "        if (!rseg || !pseg) return rseg == pseg;\n");
    fprintf(cg->out, "        if (rseg[0] == ':' && rseg[1]) rc_req_add_param(req, rseg+1, pseg);\n");
    fprintf(cg->out, "        else if (strcmp(rseg, pseg) != 0) return 0;\n");
    fprintf(cg->out, "    }\n");
    fprintf(cg->out, "}\n");
    fprintf(cg->out, "static void app_listen(int port) {\n");
    fprintf(cg->out, "    int srv = socket(AF_INET, SOCK_STREAM, 0);\n");
    fprintf(cg->out, "    int opt = 1; setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));\n");
    fprintf(cg->out, "    struct sockaddr_in addr = {0};\n");
    fprintf(cg->out, "    addr.sin_family = AF_INET; addr.sin_port = htons(port); addr.sin_addr.s_addr = INADDR_ANY;\n");
    fprintf(cg->out, "    if (bind(srv, (struct sockaddr*)&addr, sizeof(addr)) < 0) { perror(\"bind\"); return; }\n");
    fprintf(cg->out, "    listen(srv, 128);\n");
    fprintf(cg->out, "    printf(\"[Renad C] Listening on http://localhost:%%d\\n\", port);\n");
    fprintf(cg->out, "    char buf[4096];\n");
    fprintf(cg->out, "    while(1) {\n");
    fprintf(cg->out, "        int cfd = accept(srv, NULL, NULL); if (cfd < 0) continue;\n");
    fprintf(cg->out, "        int n = read(cfd, buf, sizeof(buf)-1); buf[n>0?n:0] = '\\0';\n");
    fprintf(cg->out, "        RCRequest req; memset(&req, 0, sizeof(req));\n");
    fprintf(cg->out, "        RCResponse res; memset(&res, 0, sizeof(res)); res.fd = cfd; res.status = 200; res.headers[0] = '\\0';\n");
    fprintf(cg->out, "        char method[8]={0}; char path_raw[256]={0}; sscanf(buf, \"%%7s %%255s\", method, path_raw);\n");
    fprintf(cg->out, "        strncpy(req.method_buf, method, sizeof(req.method_buf)-1); req.method = req.method_buf;\n");
    fprintf(cg->out, "        strncpy(req.path_buf, path_raw, sizeof(req.path_buf)-1);\n");
    fprintf(cg->out, "        char *q = strchr(req.path_buf, '?'); if (q) { *q++ = '\\0'; rc_parse_query(&req, q); }\n");
    fprintf(cg->out, "        req.path = req.path_buf;\n");
    fprintf(cg->out, "        char *body = strstr(buf, \"\\r\\n\\r\\n\");\n");
    fprintf(cg->out, "        if (body) { body += 4; strncpy(req.body_buf, body, sizeof(req.body_buf)-1); req.body = req.body_buf; } else { req.body = \"\"; }\n");
    fprintf(cg->out, "        char *hdr = strstr(buf, \"\\r\\n\");\n");
    fprintf(cg->out, "        if (hdr) {\n");
    fprintf(cg->out, "            char *line = hdr + 2;\n");
    fprintf(cg->out, "            while (line && *line) {\n");
    fprintf(cg->out, "                char *next = strstr(line, \"\\r\\n\"); if (!next) break;\n");
    fprintf(cg->out, "                if (next == line) { line = next + 2; break; }\n");
    fprintf(cg->out, "                *next = '\\0';\n");
    fprintf(cg->out, "                char *colon = strchr(line, ':');\n");
    fprintf(cg->out, "                if (colon) { *colon = '\\0'; char *val = colon + 1; while (*val == ' ') val++; if (req.header_count < 32) req.headers[req.header_count++] = (RCPair){line, val}; }\n");
    fprintf(cg->out, "                line = next + 2;\n");
    fprintf(cg->out, "            }\n");
    fprintf(cg->out, "        }\n");
    fprintf(cg->out, "        if (serve_static(req.path, &res)) { close(cfd); continue; }\n");
    fprintf(cg->out, "        for (int i=0; i<_mw_count; i++) { _middlewares[i](&req, &res); }\n");
    fprintf(cg->out, "        int handled = 0;\n");
    fprintf(cg->out, "        for (int i=0; i<_route_count; i++) {\n");
    fprintf(cg->out, "            if (strcmp(_routes[i].method, req.method) == 0 && rc_match_route(_routes[i].path, req.path, &req)) {\n");
    fprintf(cg->out, "                _routes[i].handler(&req, &res); handled = 1; break; }\n");
    fprintf(cg->out, "        }\n");
    fprintf(cg->out, "        if (!handled) { rc_res_status(&res, 404); rc_res_send(&res, \"Not Found\", \"text/plain; charset=utf-8\"); }\n");
    fprintf(cg->out, "        close(cfd);\n");
    fprintf(cg->out, "    }\n");
    fprintf(cg->out, "}\n\n");
}


/* ── Expression generator ──────────────────────────────────── */
static void gen_expr(CodeGen *cg, AstNode *node) {
    if (!node) { emit(cg, "0"); return; }
    switch (node->type) {
        case NODE_INT_LIT:
            emit(cg, "%lld", node->ival);
            break;
        case NODE_FLOAT_LIT:
            emit(cg, "%g", node->fval);
            break;
        case NODE_STRING_LIT: {
            /* Re-escape double quotes for C string output */
            if (strchr(node->sval, '$')) {
                emit_interp_string(cg, node->sval);
            } else {
                emit(cg, "\"");
                for (char *_c = node->sval; *_c; _c++) {
                    if (*_c == '"') emit(cg, "\\\"");
                    else if (*_c == '\\') emit(cg, "\\\\");
                    else emit(cg, "%c", *_c);
                }
                emit(cg, "\"");
            }
            break;
        }
        case NODE_BOOL_LIT:
            emit(cg, "%s", node->bval ? "1" : "0");
            break;
        case NODE_IDENT:
            emit(cg, "%s", node->sval);
            break;
        case NODE_BINARY_OP: {
            emit(cg, "(");
            gen_expr(cg, node->children[0]);
            emit(cg, " %s ", node->sval);
            gen_expr(cg, node->children[1]);
            emit(cg, ")");
            break;
        }
        case NODE_UNARY_OP:
            emit(cg, "(%s", safe_c_name(node->sval ? node->sval : ""));
            if (node->child_count > 0) gen_expr(cg, node->children[0]);
            emit(cg, ")");
            break;
        case NODE_ASSIGN_STMT: {
            gen_expr(cg, node->children[0]);
            const char *op = node->sval ? node->sval : "=";
            if (strcmp(op,"+=") == 0) emit(cg, " += ");
            else if (strcmp(op,"-=") == 0) emit(cg, " -= ");
            else if (strcmp(op,"*=") == 0) emit(cg, " *= ");
            else emit(cg, " = ");
            gen_expr(cg, node->children[1]);
            break;
        }
        case NODE_CALL: {
            /* children[0] = callee, children[1..] = args */
            if (node->child_count == 0) break;
            AstNode *callee = node->children[0];
            /* Special: print(...) / println(...) mapping */
            if (callee->type == NODE_IDENT &&
                (strcmp(callee->sval, "print")   == 0 ||
                 strcmp(callee->sval, "println") == 0 ||
                 strcmp(callee->sval, "print_ln")== 0)) {
                emit(cg, "printf(");
                if (node->child_count > 1) {
                    AstNode *arg = node->children[1];
                    if (arg->type == NODE_STRING_LIT) {
                        emit(cg, "\"");
                        /* escape % in the string */
                        for (char *c = arg->sval; *c; c++) {
                            if (*c == '%') emit(cg, "%%%%");
                            else emit(cg, "%c", *c);
                        }
                        emit(cg, "\\n\"");
                    } else {
                        emit(cg, "\"%%lld\\n\", (long long)");
                        gen_expr(cg, arg);
                    }
                } else {
                    emit(cg, "\"\\n\"");
                }
                emit(cg, ")");
            } else {
                if (callee->type == NODE_IDENT &&
                    strcmp(callee->sval, "app_get") == 0) {
                    emit(cg, "app_get(");
                    if (node->child_count > 1) {
                        gen_expr(cg, node->children[1]);
                    } else {
                        emit(cg, "\"/\"");
                    }
                    if (node->child_count > 2) {
                        emit(cg, ", (RouteHandler)");
                        gen_expr(cg, node->children[2]);
                    }
                    emit(cg, ")");
                    break;
                }
                if (callee->type == NODE_IDENT &&
                    strcmp(callee->sval, "app_post") == 0) {
                    emit(cg, "app_post(");
                    if (node->child_count > 1) {
                        gen_expr(cg, node->children[1]);
                    } else {
                        emit(cg, "\"/\"");
                    }
                    if (node->child_count > 2) {
                        emit(cg, ", (RouteHandler)");
                        gen_expr(cg, node->children[2]);
                    }
                    emit(cg, ")");
                    break;
                }
                if (callee->type == NODE_IDENT &&
                    strcmp(callee->sval, "app_put") == 0) {
                    emit(cg, "app_put(");
                    if (node->child_count > 1) {
                        gen_expr(cg, node->children[1]);
                    } else {
                        emit(cg, "\"/\"");
                    }
                    if (node->child_count > 2) {
                        emit(cg, ", (RouteHandler)");
                        gen_expr(cg, node->children[2]);
                    }
                    emit(cg, ")");
                    break;
                }
                if (callee->type == NODE_IDENT &&
                    strcmp(callee->sval, "app_delete") == 0) {
                    emit(cg, "app_delete(");
                    if (node->child_count > 1) {
                        gen_expr(cg, node->children[1]);
                    } else {
                        emit(cg, "\"/\"");
                    }
                    if (node->child_count > 2) {
                        emit(cg, ", (RouteHandler)");
                        gen_expr(cg, node->children[2]);
                    }
                    emit(cg, ")");
                    break;
                }
                if (callee->type == NODE_IDENT &&
                    strcmp(callee->sval, "app_use") == 0) {
                    emit(cg, "app_use(");
                    if (node->child_count > 1) {
                        emit(cg, "(RouteHandler)");
                        gen_expr(cg, node->children[1]);
                    } else {
                        emit(cg, "NULL");
                    }
                    emit(cg, ")");
                    break;
                }
                if (callee->type == NODE_IDENT &&
                    (strcmp(callee->sval, "rc_res_json") == 0 ||
                     strcmp(callee->sval, "rc_res_html") == 0 ||
                     strcmp(callee->sval, "rc_res_text") == 0 ||
                     strcmp(callee->sval, "rc_res_send") == 0 ||
                     strcmp(callee->sval, "rc_res_redirect") == 0 ||
                     strcmp(callee->sval, "rc_res_file") == 0)) {
                    emit(cg, "%s(", callee->sval);
                    if (node->child_count > 1) {
                        emit(cg, "(RCResponse*)");
                        gen_expr(cg, node->children[1]);
                    } else {
                        emit(cg, "NULL");
                    }
                    if (node->child_count > 2) {
                        emit(cg, ", ");
                        gen_expr(cg, node->children[2]);
                    }
                    emit(cg, ")");
                    break;
                }
                gen_expr(cg, callee);
                emit(cg, "(");
                for (int i = 1; i < node->child_count; i++) {
                    if (i > 1) emit(cg, ", ");
                    gen_expr(cg, node->children[i]);
                }
                emit(cg, ")");
            }
            break;
        }
        case NODE_METHOD_CALL: {
            /* children[0] = object, rest = args */
            if (node->sval && strcmp(node->sval, "App") == 0) {
                emit(cg, "app_create(");
                for (int i = 1; i < node->child_count; i++) {
                    if (i > 1) emit(cg, ", ");
                    gen_expr(cg, node->children[i]);
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "get") == 0) {
                emit(cg, "app_route(\"GET\", ");
                if (node->child_count > 1) {
                    gen_expr(cg, node->children[1]);
                } else {
                    emit(cg, "\"/\"");
                }
                if (node->child_count > 2) {
                    emit(cg, ", (RouteHandler)");
                    gen_expr(cg, node->children[2]);
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "post") == 0) {
                emit(cg, "app_route(\"POST\", ");
                if (node->child_count > 1) {
                    gen_expr(cg, node->children[1]);
                } else {
                    emit(cg, "\"/\"");
                }
                if (node->child_count > 2) {
                    emit(cg, ", (RouteHandler)");
                    gen_expr(cg, node->children[2]);
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "put") == 0) {
                emit(cg, "app_route(\"PUT\", ");
                if (node->child_count > 1) {
                    gen_expr(cg, node->children[1]);
                } else {
                    emit(cg, "\"/\"");
                }
                if (node->child_count > 2) {
                    emit(cg, ", (RouteHandler)");
                    gen_expr(cg, node->children[2]);
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "delete") == 0) {
                emit(cg, "app_route(\"DELETE\", ");
                if (node->child_count > 1) {
                    gen_expr(cg, node->children[1]);
                } else {
                    emit(cg, "\"/\"");
                }
                if (node->child_count > 2) {
                    emit(cg, ", (RouteHandler)");
                    gen_expr(cg, node->children[2]);
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "use") == 0) {
                emit(cg, "app_use(");
                if (node->child_count > 1) {
                    emit(cg, "(RouteHandler)");
                    gen_expr(cg, node->children[1]);
                } else {
                    emit(cg, "NULL");
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "static") == 0) {
                emit(cg, "app_static(");
                if (node->child_count == 2) {
                    emit(cg, "\"/\", ");
                    gen_expr(cg, node->children[1]);
                } else if (node->child_count >= 3) {
                    gen_expr(cg, node->children[1]);
                    emit(cg, ", ");
                    gen_expr(cg, node->children[2]);
                } else {
                    emit(cg, "\"/\", \".\"");
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "listen") == 0) {
                emit(cg, "app_listen(");
                for (int i = 1; i < node->child_count; i++) {
                    if (i > 1) emit(cg, ", ");
                    gen_expr(cg, node->children[i]);
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "query") == 0) {
                emit(cg, "rc_req_query((RCRequest*)");
                gen_expr(cg, node->children[0]);
                emit(cg, ", ");
                if (node->child_count > 1) gen_expr(cg, node->children[1]);
                else emit(cg, "\"\"");
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "param") == 0) {
                emit(cg, "rc_req_param((RCRequest*)");
                gen_expr(cg, node->children[0]);
                emit(cg, ", ");
                if (node->child_count > 1) gen_expr(cg, node->children[1]);
                else emit(cg, "\"\"");
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "header") == 0) {
                if (node->child_count >= 3) {
                    emit(cg, "rc_res_header((RCResponse*)");
                    gen_expr(cg, node->children[0]);
                    emit(cg, ", ");
                    gen_expr(cg, node->children[1]);
                    emit(cg, ", ");
                    gen_expr(cg, node->children[2]);
                    emit(cg, ")");
                } else {
                    emit(cg, "rc_req_header((RCRequest*)");
                    gen_expr(cg, node->children[0]);
                    emit(cg, ", ");
                    if (node->child_count > 1) gen_expr(cg, node->children[1]);
                    else emit(cg, "\"\"");
                    emit(cg, ")");
                }
                break;
            }
            if (node->sval && strcmp(node->sval, "status") == 0) {
                emit(cg, "rc_res_status((RCResponse*)");
                gen_expr(cg, node->children[0]);
                emit(cg, ", ");
                if (node->child_count > 1) gen_expr(cg, node->children[1]);
                else emit(cg, "200");
                emit(cg, ")");
                break;
            }
            if (node->sval &&
                (strcmp(node->sval, "json") == 0 ||
                 strcmp(node->sval, "html") == 0 ||
                 strcmp(node->sval, "text") == 0 ||
                 strcmp(node->sval, "send") == 0)) {
                const char *fn = "rc_res_json";
                if (strcmp(node->sval, "html") == 0) fn = "rc_res_html";
                if (strcmp(node->sval, "text") == 0) fn = "rc_res_text";
                if (strcmp(node->sval, "send") == 0) fn = "rc_res_text";
                emit(cg, "%s((RCResponse*)", fn);
                gen_expr(cg, node->children[0]);
                emit(cg, ", ");
                if (node->child_count > 1) {
                    gen_expr(cg, node->children[1]);
                } else {
                    emit(cg, "\"\"");
                }
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "redirect") == 0) {
                emit(cg, "rc_res_redirect((RCResponse*)");
                gen_expr(cg, node->children[0]);
                emit(cg, ", ");
                if (node->child_count > 1) gen_expr(cg, node->children[1]);
                else emit(cg, "\"/\"");
                emit(cg, ")");
                break;
            }
            if (node->sval && strcmp(node->sval, "file") == 0) {
                emit(cg, "rc_res_file((RCResponse*)");
                gen_expr(cg, node->children[0]);
                emit(cg, ", ");
                if (node->child_count > 1) gen_expr(cg, node->children[1]);
                else emit(cg, "\"\"");
                emit(cg, ")");
                break;
            }
            gen_expr(cg, node->children[0]);
            /* Map common methods */
            if (strcmp(node->sval, "len") == 0 ||
                strcmp(node->sval, "length") == 0) {
                emit(cg, " /* .length() */");
            } else {
                emit(cg, ".%s(", node->sval);
                for (int i = 1; i < node->child_count; i++) {
                    if (i > 1) emit(cg, ", ");
                    gen_expr(cg, node->children[i]);
                }
                emit(cg, ")");
            }
            break;
        }
        case NODE_MEMBER: {
            if (node->sval &&
                (strcmp(node->sval, "method") == 0 ||
                 strcmp(node->sval, "path") == 0 ||
                 strcmp(node->sval, "body") == 0)) {
                emit(cg, "((RCRequest*)");
                gen_expr(cg, node->children[0]);
                emit(cg, ")->%s", node->sval);
            } else {
                gen_expr(cg, node->children[0]);
                emit(cg, ".%s", node->sval);
            }
            break;
        }
        case NODE_INDEX: {
            gen_expr(cg, node->children[0]);
            emit(cg, "[");
            gen_expr(cg, node->children[1]);
            emit(cg, "]");
            break;
        }
        case NODE_ARRAY_LIT: {
            emit(cg, "{");
            for (int i = 0; i < node->child_count; i++) {
                if (i > 0) emit(cg, ", ");
                gen_expr(cg, node->children[i]);
            }
            emit(cg, "}");
            break;
        }
        case NODE_AWAIT_EXPR:
            /* In C target, await is a no-op wrapper */
            gen_expr(cg, node->children[0]);
            break;
        case NODE_RANGE: {
            /* Range used in for-loop — handled in for-stmt */
            gen_expr(cg, node->children[0]);
            emit(cg, " /* .. */ ");
            gen_expr(cg, node->children[1]);
            break;
        }
        default:
            if (node->sval) emit(cg, "%s", node->sval);
            else emit(cg, "0 /* unknown expr */");
    }
}

/* ── Statement generator ───────────────────────────────────── */
static void gen_block(CodeGen *cg, AstNode *node) {
    if (!node) return;
    if (node->type == NODE_BLOCK) {
        emit(cg, " {\n");
        cg->indent++;
        for (int i = 0; i < node->child_count; i++)
            gen_stmt(cg, node->children[i]);
        cg->indent--;
        indent(cg);
        emit(cg, "}");
    } else {
        emit(cg, " {\n");
        cg->indent++;
        gen_stmt(cg, node);
        cg->indent--;
        indent(cg);
        emit(cg, "}");
    }
}

/* ── Safe C identifier for RC names ──────────────────────── */


static void gen_stmt(CodeGen *cg, AstNode *node) {
    if (!node) return;
    switch (node->type) {

        case NODE_ANNOTATION:
            /* Skip annotations in C output */
            return;


        case NODE_ENUM_DECL: {
            if (!node->sval) break;
            const char *ename = node->sval;
            /* Tag enum */
            emitl(cg, "typedef enum {");
            cg->indent++;
            for (int i = 0; i < node->child_count; i++) {
                AstNode *v = node->children[i];
                if (v->type != NODE_ENUM_VARIANT) continue;
                { char _eu[256], _ev[256];
                  rc_toupper_buf(ename, _eu, sizeof(_eu));
                  rc_toupper_buf(v->sval ? v->sval : "V", _ev, sizeof(_ev));
                  emitl(cg, "%s_%s,", _eu, _ev); }
            }
            cg->indent--;
            emitl(cg, "} %sTag;", ename);
            /* Data struct */
            emitl(cg, "typedef struct {");
            cg->indent++;
            emitl(cg, "%sTag tag;", ename);
            /* Check if any variant has payload */
            int has_payload = 0;
            for (int i = 0; i < node->child_count; i++) {
                AstNode *v = node->children[i];
                if (v->type == NODE_ENUM_VARIANT && v->child_count > 0) { has_payload = 1; break; }
            }
            if (has_payload) {
                emitl(cg, "union {");
                cg->indent++;
                for (int i = 0; i < node->child_count; i++) {
                    AstNode *v = node->children[i];
                    if (v->type != NODE_ENUM_VARIANT || v->child_count == 0) continue;
                    emitl(cg, "struct {");
                    cg->indent++;
                    for (int j = 0; j < v->child_count; j++) {
                        AstNode *f = v->children[j];
                        const char *ft = f->type_node ? type_node_to_c(f->type_node) : "long long";
                        emitl(cg, "%s %s;", ft, f->sval ? f->sval : "v");
                    }
                    cg->indent--;
                    emitl(cg, "} %s;", v->sval ? v->sval : "V");
                }
                cg->indent--;
                emitl(cg, "} data;");
            }
            cg->indent--;
            emitl(cg, "} %s;", ename);
            /* Constructor functions */
            for (int i = 0; i < node->child_count; i++) {
                AstNode *v = node->children[i];
                if (v->type != NODE_ENUM_VARIANT) continue;
                const char *vname = v->sval ? v->sval : "V";
                /* pre-compute uppercase names to avoid static buffer collision */
                char _eu[256], _ev[256];
                rc_toupper_buf(ename, _eu, sizeof(_eu));
                rc_toupper_buf(vname, _ev, sizeof(_ev));
                if (v->child_count == 0) {
                    /* Unit variant */
                    emitl(cg, "static inline %s %s_%s(void) {", ename, ename, vname);
                    cg->indent++;
                    emitl(cg, "%s _r; _r.tag = %s_%s; return _r;", ename, _eu, _ev);
                    cg->indent--;
                    emitl(cg, "}");
                } else {
                    /* Payload variant */
                    indent(cg);
                    emit(cg, "static inline %s %s_%s(", ename, ename, vname);
                    for (int j = 0; j < v->child_count; j++) {
                        AstNode *f = v->children[j];
                        const char *ft = f->type_node ? type_node_to_c(f->type_node) : "long long";
                        if (j) emit(cg, ", ");
                        emit(cg, "%s _%s", ft, f->sval ? f->sval : "v");
                    }
                    emit(cg, ") {\n");
                    cg->indent++;
                    emitl(cg, "%s _r; _r.tag = %s_%s;", ename, _eu, _ev);
                    for (int j = 0; j < v->child_count; j++) {
                        AstNode *f = v->children[j];
                        const char *fn = f->sval ? f->sval : "v";
                        emitl(cg, "_r.data.%s.%s = _%s;", vname, fn, fn);
                    }
                    emitl(cg, "return _r;");
                    cg->indent--;
                    emitl(cg, "}");
                }
            }

            /* 5. is_Variant() predicate functions */
            for (int _pi = 0; _pi < node->child_count; _pi++) {
                AstNode *_pv = node->children[_pi];
                if (_pv->type != NODE_ENUM_VARIANT) continue;
                const char *_pvn = _pv->sval ? _pv->sval : "V";
                char _peu[256], _pev[256];
                rc_toupper_buf(ename, _peu, sizeof(_peu));
                rc_toupper_buf(_pvn, _pev, sizeof(_pev));
                emitl(cg, "static inline int %s_is_%s(%s v) { return v.tag == %s_%s; }",
                      ename, _pvn, ename, _peu, _pev);
            }
            break;
        }


        case NODE_CLOSURE: {
            /* Emit static function + return function pointer */
            int lid = g_lambda_id++;
            const char *rtype = node->type_node ?
                type_node_to_c(node->type_node) : "long long";
            indent(cg);
            /* Emit as static function before the current position — 
               for now emit inline as lambda identifier */
            /* We store the lambda body as a static fn in preamble */
            fprintf(cg->out, "/* lambda_%d */\n", lid);
            /* Emit static helper */
            fprintf(cg->out, "static %s _rc_lambda_%d(", rtype, lid);
            int param_count = 0;
            for (int i = 0; i < node->child_count - 1; i++) {
                AstNode *pm = node->children[i];
                if (pm->type != NODE_PARAM) continue;
                if (param_count++) fprintf(cg->out, ", ");
                const char *pt = pm->type_node ? type_node_to_c(pm->type_node) : "long long";
                fprintf(cg->out, "%s %s", pt, pm->sval ? pm->sval : "x");
            }
            if (param_count == 0) fprintf(cg->out, "void");
            fprintf(cg->out, ") {\n");
            cg->indent++;
            if (node->child_count > 0) {
                AstNode *body = node->children[node->child_count - 1];
                if (body->type == NODE_BLOCK) {
                    for (int i = 0; i < body->child_count; i++)
                        gen_stmt(cg, body->children[i]);
                }
            }
            cg->indent--;
            fprintf(cg->out, "}\n");
            /* The expression value is the function pointer */
            fprintf(cg->out, "_rc_lambda_%d", lid);
            break;
        }


        /* ── Macro definition ─────────────────────────────── */
        case NODE_MACRO_DEF: {
            /* Emit as a C #define or inline function */
            const char *mname = node->sval ? node->sval : "macro";
            emitl(cg, "/* macro %s */", mname);
            /* We don't emit actual macro expansion yet — record for later */
            /* Full hygenic macro expansion is a TODO for v2 */
            break;
        }


        /* ── Inline assembly ──────────────────────────────── */
        case NODE_ASM_BLOCK: {
            if (node->sval && node->sval[0]) {
                emitl(cg, "__asm__ volatile(\"%s\");", node->sval);
            }
            break;
        }


        /* ── Module declaration ───────────────────────────── */
        case NODE_MODULE_DECL: {
            emitl(cg, "/* module %s */", node->sval ? node->sval : "");
            break;
        }

        /* ── Use/import statement ─────────────────────────── */
        case NODE_USE_STMT: {
            emitl(cg, "/* use %s */", node->sval ? node->sval : "");
            /* Real module resolution happens at link-time via rcpm */
            break;
        }


        /* ── Select statement (channels) ─────────────────── */
        case NODE_SELECT_STMT: {
            /* Emit as sequential fallback — real select needs OS threads */
            emitl(cg, "/* select */");
            emitl(cg, "{");
            cg->indent++;
            for (int i = 0; i < node->child_count; i++) {
                AstNode *arm = node->children[i];
                if (arm->type != NODE_MATCH_ARM || arm->child_count < 2) continue;
                emitl(cg, "/* case %d */", i);
                AstNode *body = arm->children[1];
                for (int j = 0; j < body->child_count; j++)
                    gen_stmt(cg, body->children[j]);
                emitl(cg, "break;");
            }
            cg->indent--;
            emitl(cg, "}");
            break;
        }

        case NODE_IMPORT_STMT:
            /* Map rcstd.* → C includes + set feature flags */
            if (node->sval) {
                if (strstr(node->sval, "rcstd.nn") ||
                    strstr(node->sval, "rcstd.ai"))
                    { emitl(cg, "/* import %s */", node->sval); cg->has_nn = 1; }
                else if (strstr(node->sval, "rcstd.sys") ||
                         strstr(node->sval, "rcstd.kernel") ||
                         strstr(node->sval, "rcstd.mem") ||
                         strstr(node->sval, "rcstd.os"))
                    { emitl(cg, "/* import %s */", node->sval); cg->has_sys = 1; }
                else if (strstr(node->sval, "rcstd.telegram") ||
                         strstr(node->sval, "rcstd.tg"))
                    { emitl(cg, "/* import %s */", node->sval); cg->has_telegram = 1; }
                else if (strstr(node->sval, "rcstd.sec") ||
                         strstr(node->sval, "rcstd.security") ||
                         strstr(node->sval, "rcstd.net.sec"))
                    { emitl(cg, "/* import %s */", node->sval); cg->has_sec = 1; }
                else if (strstr(node->sval, "rcstd.mobile") ||
                         strstr(node->sval, "rcstd.ui.mobile"))
                    { emitl(cg, "/* import %s */", node->sval); cg->has_mobile = 1; }
                else if (strstr(node->sval, "rcstd.web") ||
                         strstr(node->sval, "rcstd.net"))
                    emitl(cg, "/* import %s (net) */", node->sval);
                else
                    emitl(cg, "/* import %s */", node->sval);
            }
            return;

        case NODE_FN_DECL: {
            /* Skip annotations children */
            const char *ret_type = "long long";
            if (node->type_node) ret_type = type_node_to_c(node->type_node);
            emit(cg, "\n");
            /* Check if main */
            int is_main = node->sval && strcmp(node->sval, "main") == 0;
            if (is_main) ret_type = "int";
            emitl(cg, "%s %s(", ret_type, node->sval ? node->sval : "anon");
            /* Parameters — skip NODE_ANNOTATION children */
            int param_count = 0;
            for (int i = 0; i < node->child_count; i++) {
                if (node->children[i]->type == NODE_PARAM) param_count++;
            }
            if (param_count == 0) {
                emit(cg, "void");
            } else {
                int first = 1;
                for (int i = 0; i < node->child_count; i++) {
                    AstNode *ch = node->children[i];
                    if (ch->type != NODE_PARAM) continue;
                    if (!first) emit(cg, ", ");
                    const char *pt = ch->type_node ?
                                     type_node_to_c(ch->type_node) : "long long";
                    emit(cg, "%s %s", pt, ch->sval ? ch->sval : "p");
                    first = 0;
                }
            }
            emit(cg, ")");
            /* Body block */
            AstNode *body = NULL;
            for (int i = 0; i < node->child_count; i++) {
                if (node->children[i]->type == NODE_BLOCK) {
                    body = node->children[i]; break;
                }
            }
            if (body) {
                emit(cg, " {\n");
                cg->indent++;
                for (int i = 0; i < body->child_count; i++)
                    gen_stmt(cg, body->children[i]);
                if (is_main) emitl(cg, "return 0;");
                cg->indent--;
                emitl(cg, "}");
            } else {
                emitl(cg, " {}");
            }
            break;
        }

        case NODE_LET_STMT: {
            const char *ctype = node->type_node ?
                                type_node_to_c(node->type_node) : "long long";
            /* Smart type inference from RHS */
            if (!node->type_node && node->child_count > 0) {
                AstNode *val = node->children[0];
                if (val->type == NODE_METHOD_CALL && val->sval &&
                    strcmp(val->sval, "App") == 0) {
                    ctype = "RCApp";
                } else if (val->type == NODE_CALL && val->child_count > 0) {
                    AstNode *fn = val->children[0];
                    if (fn->type == NODE_IDENT && fn->sval &&
                        strcmp(fn->sval, "app_create") == 0) {
                        ctype = "RCApp";
                    } else if (fn->type == NODE_MEMBER && fn->sval &&
                               strcmp(fn->sval, "App") == 0) {
                        ctype = "RCApp";
                    }
                }
                if (val->type == NODE_METHOD_CALL && val->sval &&
                    (strcmp(val->sval, "param") == 0 ||
                     strcmp(val->sval, "query") == 0 ||
                     strcmp(val->sval, "header") == 0)) {
                    ctype = "const char*";
                } else if (val->type == NODE_MEMBER && val->sval &&
                           (strcmp(val->sval, "body") == 0 ||
                            strcmp(val->sval, "path") == 0 ||
                            strcmp(val->sval, "method") == 0)) {
                    ctype = "const char*";
                } else if (val->type == NODE_STRING_LIT) {
                    ctype = "const char*";
                } else if (val->type == NODE_FLOAT_LIT) {
                    ctype = "double";
                } else if (val->type == NODE_BOOL_LIT) {
                    ctype = "int";
                } else if (val->type == NODE_CALL && val->child_count > 0) {
                    /* Check if this is an enum constructor: Name_Variant() */
                    AstNode *fn = val->children[0];
                    const char *fname = fn->sval ? fn->sval : "";
                    const char *underscore = strchr(fname, '_');
                    if (underscore && fname[0] >= 'A' && fname[0] <= 'Z') {
                        /* Looks like EnumType_Variant — use EnumType as type */
                        static char enum_type_buf[256];
                        int prefix_len = (int)(underscore - fname);
                        if (prefix_len > 0 && prefix_len < 255) {
                            strncpy(enum_type_buf, fname, prefix_len);
                            enum_type_buf[prefix_len] = '\0';
                            ctype = enum_type_buf;
                        }
                    }
                    /* else stays long long for numeric call results */
                }
            }
            indent(cg);
            emit(cg, "%s %s", ctype, node->sval ? node->sval : "v");
            if (node->child_count > 0) {
                emit(cg, " = ");
                gen_expr(cg, node->children[0]);
            } else {
                emit(cg, " = 0");
            }
            emit(cg, ";\n");
            break;
        }

        case NODE_CONST_STMT: {
            const char *ctype = node->type_node ?
                                type_node_to_c(node->type_node) : "long long";
            indent(cg);
            emit(cg, "const %s %s", ctype, node->sval ? node->sval : "C");
            if (node->child_count > 0) {
                emit(cg, " = ");
                gen_expr(cg, node->children[0]);
            }
            emit(cg, ";\n");
            break;
        }

        case NODE_RETURN_STMT:
            indent(cg);
            emit(cg, "return");
            if (node->child_count > 0) {
                emit(cg, " ");
                gen_expr(cg, node->children[0]);
            }
            emit(cg, ";\n");
            break;

        case NODE_PRINT_STMT:
            indent(cg);
            if (node->child_count > 0) {
                AstNode *arg = node->children[0];
                if (arg->type == NODE_STRING_LIT) {
                    if (has_interpolation(arg->sval)) {
                        /* Interpolated string: use printf with rc_sprintf result */
                        emit(cg, "printf(\"%%s\\n\", ");
                        emit_interp_string(cg, arg->sval);
                        emit(cg, ");\n");
                    } else {
                        /* Plain string: printf("text\n") */
                        emit(cg, "printf(\"");
                        for (const char *_p = arg->sval; *_p; _p++) {
                            if (*_p == '%')       emit(cg, "%%%%");
                            else if (*_p == '"')  emit(cg, "\\\"");
                            else if (*_p == '\\') emit(cg, "\\\\");
                            else                  emit(cg, "%c", *_p);
                        }
                        emit(cg, "\\n\");\n");
                    }
                } else if (arg->type == NODE_INT_LIT) {
                    emit(cg, "printf(\"%%lld\\n\", %lldLL);\n", arg->ival);
                } else if (arg->type == NODE_FLOAT_LIT) {
                    emit(cg, "printf(\"%%g\\n\", %g);\n", arg->fval);
                } else {
                    /* Expression: convert via rc_tostr */
                    emit(cg, "printf(\"%%s\\n\", rc_tostr((long long)(");
                    gen_expr(cg, arg);
                    emit(cg, ")));\n");
                }
            } else {
                emit(cg, "printf(\"\\n\");\n");
            }
            break;

        case NODE_IF_STMT:
            indent(cg);
            emit(cg, "if (");
            gen_expr(cg, node->children[0]);
            emit(cg, ")");
            gen_block(cg, node->children[1]);
            if (node->child_count > 2) {
                emit(cg, " else");
                if (node->children[2]->type == NODE_IF_STMT) {
                    emit(cg, " ");
                    cg->indent = 0; /* suppress indent for else-if */
                    gen_stmt(cg, node->children[2]);
                    return;
                }
                gen_block(cg, node->children[2]);
            }
            emit(cg, "\n");
            break;

        case NODE_WHILE_STMT:
            indent(cg);
            emit(cg, "while (");
            gen_expr(cg, node->children[0]);
            emit(cg, ")");
            gen_block(cg, node->children[1]);
            emit(cg, "\n");
            break;

        case NODE_FOR_STMT: {
            /* children[0]=var, children[1]=iterable/range, children[2]=body */
            if (node->child_count < 3) break;
            AstNode *var  = node->children[0];
            AstNode *iter = node->children[1];
            AstNode *body = node->children[2];
            indent(cg);
            /* Range: a..b */
            if (iter->type == NODE_BINARY_OP &&
                iter->sval && strcmp(iter->sval, "..") == 0) {
                emit(cg, "for (long long %s = ", var->sval);
                gen_expr(cg, iter->children[0]);
                emit(cg, "; %s < ", var->sval);
                gen_expr(cg, iter->children[1]);
                emit(cg, "; %s++)", var->sval);
                gen_block(cg, body);
            } else {
                /* Generic iterator — emit C array iteration */
                emit(cg, "/* for %s in */\n", var->sval ? var->sval : "x");
                indent(cg);
                emit(cg, "{{ /* iterator */ }}");
            }
            emit(cg, "\n");
            break;
        }

        case NODE_MATCH_STMT: {
            /* Smart match — detects enum variant patterns like Ok(v) */
            AstNode *subj = node->children[0];
            /* Check if any arm is an enum variant call pattern */
            int is_enum_match = 0;
            for (int i = 1; i < node->child_count; i++) {
                AstNode *arm = node->children[i];
                if (arm->type != NODE_MATCH_ARM || arm->child_count < 2) continue;
                AstNode *pat = arm->children[0];
                if (pat->type == NODE_CALL) { is_enum_match = 1; break; }
            }
            indent(cg);
            if (is_enum_match) {
                /* Enum match: switch on .tag, bind payload fields */
                char subj_buf[256] = {0};
                /* Store subject in temp var to avoid re-evaluation */
                emit(cg, "{ __typeof__(");
                gen_expr(cg, subj);
                emit(cg, ") _match_val = ");
                gen_expr(cg, subj);
                emit(cg, "; switch(_match_val.tag) {\n");
            } else {
                emit(cg, "switch ((long long)(");
                gen_expr(cg, subj);
                emit(cg, ")) {\n");
            }
            cg->indent++;
            for (int i = 1; i < node->child_count; i++) {
                AstNode *arm = node->children[i];
                if (arm->type != NODE_MATCH_ARM) continue;
                if (arm->child_count < 2) continue;
                AstNode *pat = arm->children[0];
                /* Wildcard _ */
                if (pat->type == NODE_IDENT && strcmp(pat->sval, "_") == 0) {
                    emitl(cg, "default: {");
                } else if (is_enum_match && pat->type == NODE_CALL) {
                    /* Enum variant pattern: VariantName(bindings...) */
                    AstNode *vname = pat->children[0];
                    /* Get enum type name from subject — heuristic: uppercase first arm */
                    /* Emit case TAG_VARIANTNAME: */
                    indent(cg);
                    /* We need enum name prefix — derive from variant name */
                    const char *vn = vname->sval ? vname->sval : "V";
                    emit(cg, "case ");
                    /* Emit as: _match_val.tag value — 
                       We use the enum type prefix. 
                       For now emit symbolic: EnumTag_VariantName */
                    /* The tag constant name: ENUM_VARIANT (all caps) */
                    for (const char *cp = vn; *cp; cp++)
                        fputc((*cp>='a'&&*cp<='z') ? *cp-32 : *cp, cg->out);
                    emit(cg, "__TAG: {\n");
                    cg->indent++;
                    /* Bind payload fields */
                    for (int j = 1; j < pat->child_count; j++) {
                        AstNode *bind = pat->children[j];
                        if (!bind->sval) continue;
                        /* long long bindname = _match_val.data.VName.fieldN; */
                        emitl(cg, "long long %s = _match_val.data.%s.%s;",
                              bind->sval, vn,
                              bind->sval);
                    }
                } else if (is_enum_match && pat->type == NODE_IDENT) {
                    /* Unit variant */
                    const char *vn = pat->sval ? pat->sval : "V";
                    indent(cg);
                    emit(cg, "case ");
                    for (const char *cp = vn; *cp; cp++)
                        fputc((*cp>='a'&&*cp<='z') ? *cp-32 : *cp, cg->out);
                    emit(cg, "__TAG: {\n");
                    cg->indent++;
                } else {
                    /* Integer / string literal match */
                    indent(cg);
                    emit(cg, "case ");
                    gen_expr(cg, pat);
                    emit(cg, ": {\n");
                    cg->indent++;
                }
                /* Arm body */
                for (int j = 0; j < arm->children[1]->child_count; j++)
                    gen_stmt(cg, arm->children[1]->children[j]);
                emitl(cg, "break; }");
                cg->indent--;
            }
            cg->indent--;
            if (is_enum_match) emitl(cg, "} }");
            else emitl(cg, "}");
            break;
        }

        case NODE_STRUCT_DECL: {
            emitl(cg, "typedef struct %s {", node->sval ? node->sval : "S");
            cg->indent++;
            for (int i = 0; i < node->child_count; i++) {
                AstNode *f = node->children[i];
                if (f->type != NODE_FIELD) continue;
                const char *ft = f->type_node ?
                                 type_node_to_c(f->type_node) : "long long";
                emitl(cg, "%s %s;", ft, f->sval ? f->sval : "f");
            }
            cg->indent--;
            emitl(cg, "} %s;", node->sval ? node->sval : "S");
            break;
        }

        case NODE_ASSIGN_STMT:
            indent(cg);
            gen_expr(cg, node);
            emit(cg, ";\n");
            break;

        case NODE_EXPR_STMT:
            if (node->child_count > 0) {
                indent(cg);
                gen_expr(cg, node->children[0]);
                emit(cg, ";\n");
            }
            break;

        case NODE_DEFER_STMT:
            emitl(cg, "/* defer: ");
            gen_expr(cg, node->children[0]);
            emit(cg, " */\n");
            break;

        case NODE_BLOCK:
            for (int i = 0; i < node->child_count; i++)
                gen_stmt(cg, node->children[i]);
            break;

        default:
            break;
    }
}

/* ── Scan AST for http/web imports ────────────────────────── */
static int needs_http(AstNode *prog) {
    for (int i = 0; i < prog->child_count; i++) {
        AstNode *n = prog->children[i];
        if (n->type == NODE_IMPORT_STMT && n->sval &&
            (strstr(n->sval, "web") || strstr(n->sval, "net")))
            return 1;
    }
    return 0;
}

/* ── Scan for app.listen calls ─────────────────────────────── */
static int has_listen(AstNode *node) {
    if (!node) return 0;
    if (node->type == NODE_METHOD_CALL && node->sval &&
        strcmp(node->sval, "listen") == 0) return 1;
    if (node->type == NODE_CALL && node->child_count > 0) {
        AstNode *fn = node->children[0];
        if (fn->type == NODE_MEMBER && fn->sval &&
            strcmp(fn->sval, "listen") == 0) return 1;
    }
    for (int i = 0; i < node->child_count; i++)
        if (has_listen(node->children[i])) return 1;
    return 0;
}

/* ── Main entry ────────────────────────────────────────────── */

/* ── Pre-scan AST for stdlib imports ──────────────────────── */
static void prescan_imports(CodeGen *cg, AstNode *node) {
    if (!node) return;
    if (node->type == NODE_IMPORT_STMT && node->sval) {
        const char *s = node->sval;
        if (strstr(s,"rcstd.nn") || strstr(s,"rcstd.ai") || strstr(s,"rcstd.ml"))
            cg->has_nn = 1;
        if (strstr(s,"rcstd.sys") || strstr(s,"rcstd.kernel") ||
            strstr(s,"rcstd.mem") || strstr(s,"rcstd.os"))
            cg->has_sys = 1;
        if (strstr(s,"rcstd.telegram") || strstr(s,"rcstd.tg"))
            cg->has_telegram = 1;
        if (strstr(s,"rcstd.sec") || strstr(s,"rcstd.security"))
            cg->has_sec = 1;
        if (strstr(s,"rcstd.mobile") || strstr(s,"rcstd.ui.mobile"))
            cg->has_mobile = 1;
    }
    for (int i = 0; i < node->child_count; i++)
        prescan_imports(cg, node->children[i]);
}

void codegen_run(CodeGen *cg, AstNode *program) {
    int http_mode = needs_http(program);
    /* Pre-scan imports to set feature flags BEFORE preamble */
    prescan_imports(cg, program);


    /* ── File header ── */
    emitl(cg, "/* Generated by Renad C Compiler v1.0.0 */");
    emitl(cg, "/* Creator: Mohamed Ahmed Mohamed         */");
    emitl(cg, "#include <stdio.h>");
    emitl(cg, "#include <stdlib.h>");
    emitl(cg, "#include <string.h>");
    emitl(cg, "#include <stdarg.h>");
    emitl(cg, "");

    /* ── Ultra stdlib: emit feature defines + header ── */
    if (cg->has_nn || cg->has_sys || cg->has_telegram ||
        cg->has_sec || cg->has_mobile) {
        emitl(cg, "/* ── Renad C Ultra Stdlib ── */");
        if (cg->has_nn)       emitl(cg, "#define RC_HAS_NN");
        if (cg->has_sys)      emitl(cg, "#define RC_HAS_SYS");
        if (cg->has_telegram) emitl(cg, "#define RC_HAS_TELEGRAM");
        if (cg->has_sec)      emitl(cg, "#define RC_HAS_SEC");
        if (cg->has_mobile)   emitl(cg, "#define RC_HAS_MOBILE");
        emitl(cg, "#include \"/tmp/rcstd_ultra.h\"");
        emitl(cg, "");
    }

    /* ── Runtime helpers ── */
    emitl(cg, "/* Runtime helpers */");
    emitl(cg, "/* rotating string buffers - declared below */");
    /* _rc_bufs and _rc_buf_idx declared in preamble string */
    emitl(cg, 
"/* ── Channels (lightweight via pthreads) ── */\n"
"#ifdef __linux__\n"
"#include <pthread.h>\n"
"typedef struct {\n"
"    void **buf; int cap, len, head, tail;\n"
"    pthread_mutex_t mu;\n"
"    pthread_cond_t not_full, not_empty;\n"
"} RcChan;\n"
"static inline RcChan *rc_chan_new(int cap) {\n"
"    RcChan *c = (RcChan*)calloc(1, sizeof(RcChan));\n"
"    c->cap = cap ? cap : 1;\n"
"    c->buf = (void**)malloc(sizeof(void*)*c->cap);\n"
"    pthread_mutex_init(&c->mu, NULL);\n"
"    pthread_cond_init(&c->not_full, NULL);\n"
"    pthread_cond_init(&c->not_empty, NULL);\n"
"    return c;\n"
"}\n"
"static inline void rc_chan_send(RcChan *c, void *v) {\n"
"    pthread_mutex_lock(&c->mu);\n"
"    while (c->len == c->cap) pthread_cond_wait(&c->not_full, &c->mu);\n"
"    c->buf[c->tail] = v; c->tail=(c->tail+1)%%c->cap; c->len++;\n"
"    pthread_cond_signal(&c->not_empty);\n"
"    pthread_mutex_unlock(&c->mu);\n"
"}\n"
"static inline void *rc_chan_recv(RcChan *c) {\n"
"    pthread_mutex_lock(&c->mu);\n"
"    while (c->len == 0) pthread_cond_wait(&c->not_empty, &c->mu);\n"
"    void *v = c->buf[c->head]; c->head=(c->head+1)%%c->cap; c->len--;\n"
"    pthread_cond_signal(&c->not_full);\n"
"    pthread_mutex_unlock(&c->mu);\n"
"    return v;\n"
"}\n"
"#endif\n"
"/* ── Vec<T> dynamic array ── */\n"
"typedef struct { void **data; int len; int cap; } RcVec;\n"
"static inline RcVec *rc_vec_new(void) { RcVec *v=(RcVec*)calloc(1,sizeof(RcVec)); v->cap=8; v->data=(void**)malloc(8*sizeof(void*)); return v; }\n"
"static inline void rc_vec_push(RcVec *v, void *x) { if(v->len>=v->cap){v->cap*=2;v->data=(void**)realloc(v->data,v->cap*sizeof(void*));} v->data[v->len++]=x; }\n"
"static inline void *rc_vec_get(RcVec *v, int i) { return v->data[i]; }\n"
"static inline int rc_vec_len(RcVec *v) { return v->len; }\n"

"/* ── String conversion (rotating 8-slot buffer pool) ── */\n"
"static char _rc_bufs[8][512];\n"
"static int  _rc_buf_idx = 0;\n"
"/* Polymorphic print helpers */\n"
"#define rc_tostr(x) _Generic((x),\\ \n"
"    long long: _rc_tostr_ll,\\ \n"
"    int:       _rc_tostr_ll,\\ \n"
"    double:    _rc_tostr_d,\\ \n"
"    float:     _rc_tostr_d,\\ \n"
"    const char*: _rc_tostr_s,\\ \n"
"    char*:     _rc_tostr_s,\\ \n"
"    default:   _rc_tostr_ll)(x)\n"
"static const char* _rc_tostr_ll(long long v) {\n"
"    char *b = _rc_bufs[_rc_buf_idx & 7]; _rc_buf_idx++;\n"
"    snprintf(b, 512, \"%%lld\", v); return b;\n"
"}\n"
"static const char* _rc_tostr_d(double v) {\n"
"    char *b = _rc_bufs[_rc_buf_idx & 7]; _rc_buf_idx++;\n"
"    snprintf(b, 512, \"%%g\", v); return b;\n"
"}\n"
"static const char* _rc_tostr_s(const char* v) {\n"
"    return v ? v : \"null\";\n"
"}\n"
"static const char* rc_ftostr(double v) {\n"
"    char *b = _rc_bufs[_rc_buf_idx & 7]; _rc_buf_idx++;\n"
"    snprintf(b, 512, \"%%g\", v); return b;\n"
"}\n"
"static const char* rc_sprintf(const char *fmt, ...) {\n"
"    static char buf[4096];\n"
"    va_list ap; va_start(ap, fmt);\n"
"    vsnprintf(buf, sizeof(buf), fmt, ap);\n"
"    va_end(ap); return buf;\n"
"}\n");
    emitl(cg, "");

    /* ── HTTP server if needed ── */
    if (http_mode) {
        emit_http_server_impl(cg);
        emitl(cg, "");
    }

    /* ── Emit all declarations ── */
    for (int i = 0; i < program->child_count; i++)
        gen_stmt(cg, program->children[i]);
}
