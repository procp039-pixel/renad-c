/* ============================================================
 * Renad C Compiler — Recursive Descent Parser
 * Based on EBNF grammar from Renad C Language Specification v1.0
 * Creator: Mohamed Ahmed Mohamed
 * ============================================================ */
#include "parser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ── Forward declarations ──────────────────────────────────── */
static AstNode *parse_stmt(Parser *p);
static AstNode *parse_expr(Parser *p);
static AstNode *parse_block(Parser *p);
static AstNode *parse_fn_decl(Parser *p, int is_async);
static AstNode *parse_type(Parser *p);
static AstNode *parse_primary(Parser *p);
static AstNode *parse_call_args(Parser *p, AstNode *callee);
static AstNode *parse_if_stmt(Parser *p);
static AstNode *parse_match_stmt(Parser *p);
static AstNode *parse_enum_decl(Parser *p);
static AstNode *parse_closure_expr(Parser *p);

/* ── Constructor ───────────────────────────────────────────── */
Parser *parser_new(Lexer *lexer) {
    Parser *p = calloc(1, sizeof(Parser));
    p->lexer  = lexer;
    p->current   = lexer_next(lexer);
    p->lookahead = lexer_next(lexer);
    p->error_line = 0;
    p->error_col  = 0;
    return p;
}

void parser_free(Parser *p) { free(p); }

/* ── Token helpers ─────────────────────────────────────────── */
static Token advance_tok(Parser *p) {
    Token prev   = p->current;
    p->current   = p->lookahead;
    p->lookahead = lexer_next(p->lexer);
    /* skip spurious newlines in expression contexts */
    return prev;
}

static int check(Parser *p, TokenType t) {
    return p->current.type == t;
}

static int check2(Parser *p, TokenType t) {
    return p->lookahead.type == t;
}

static int match(Parser *p, TokenType t) {
    if (check(p, t)) { advance_tok(p); return 1; }
    return 0;
}

static Token expect(Parser *p, TokenType t) {
    if (!check(p, t)) {
        if (!p->had_error) {
            p->error_line = p->current.line;
            p->error_col  = p->current.col;
        }
        snprintf(p->error_msg, sizeof(p->error_msg),
                 "Line %d: Expected '%s' but got '%s' ('%s')",
                 p->current.line,
                 token_type_name(t),
                 token_type_name(p->current.type),
                 p->current.value ? p->current.value : "");
        fprintf(stderr, "Parse Error: %s\n", p->error_msg);
        p->had_error = 1;
    }
    return advance_tok(p);
}

static void skip_newlines(Parser *p) {
    while (check(p, TOK_NEWLINE) || check(p, TOK_SEMICOLON))
        advance_tok(p);
}

/* ── Operator precedence (Pratt) ───────────────────────────── */
typedef enum {
    PREC_NONE = 0,
    PREC_ASSIGN,
    PREC_OR,
    PREC_AND,
    PREC_EQ,
    PREC_CMP,
    PREC_ADD,
    PREC_MUL,
    PREC_UNARY,
    PREC_CALL,
    PREC_PRIMARY
} Precedence;

static Precedence get_prec(TokenType t) {
    switch (t) {
        case TOK_ASSIGN:
        case TOK_PLUS_ASSIGN:
        case TOK_MINUS_ASSIGN:
        case TOK_STAR_ASSIGN:    return PREC_ASSIGN;
        case TOK_OR_OR:          return PREC_OR;
        case TOK_AND_AND:        return PREC_AND;
        case TOK_EQ:
        case TOK_NEQ:            return PREC_EQ;
        case TOK_LT:
        case TOK_GT:
        case TOK_LEQ:
        case TOK_GEQ:            return PREC_CMP;
        case TOK_DOTDOT:         return PREC_ADD;
        case TOK_PLUS:
        case TOK_MINUS:          return PREC_ADD;
        case TOK_STAR:
        case TOK_SLASH:
        case TOK_PERCENT:        return PREC_MUL;
        case TOK_LPAREN:
        case TOK_DOT:
        case TOK_QUESTION_DOT:
        case TOK_LBRACKET:       return PREC_CALL;
        default:                 return PREC_NONE;
    }
}

/* ── Type parser ───────────────────────────────────────────── */
static AstNode *parse_type(Parser *p) {
    int line = p->current.line, col = p->current.col;
    AstNode *t = NULL;

    if (check(p, TOK_INT_TYPE) || check(p, TOK_FLOAT_TYPE) ||
        check(p, TOK_STR_TYPE) || check(p, TOK_BOOL_TYPE)  ||
        check(p, TOK_VOID_TYPE)|| check(p, TOK_IDENT)) {
        t = ast_node(NODE_TYPE_NAME, line, col);
        t->sval = strdup(p->current.value);
        advance_tok(p);
    } else if (check(p, TOK_LBRACKET)) {
        advance_tok(p);
        t = ast_node(NODE_TYPE_ARRAY, line, col);
        ast_add_child(t, parse_type(p));
        expect(p, TOK_RBRACKET);
    } else {
        t = ast_node(NODE_TYPE_NAME, line, col);
        t->sval = strdup("any");
    }

    /* Generic suffix: Type<T> */
    if (check(p, TOK_LT)) {
        AstNode *g = ast_node(NODE_TYPE_GENERIC, line, col);
        g->sval = strdup(t->sval ? t->sval : "?");
        advance_tok(p); /* < */
        ast_add_child(g, parse_type(p));
        while (match(p, TOK_COMMA))
            ast_add_child(g, parse_type(p));
        expect(p, TOK_GT);
        ast_free(t);
        return g;
    }
    return t;
}

/* ── Primary expressions ───────────────────────────────────── */
static AstNode *parse_primary(Parser *p) {
    int line = p->current.line, col = p->current.col;

    /* Integer literal */
    if (check(p, TOK_INT_LIT)) {
        AstNode *n = ast_node(NODE_INT_LIT, line, col);
        n->ival    = atoll(p->current.value);
        n->sval    = strdup(p->current.value);
        advance_tok(p);
        return n;
    }
    /* Float literal */
    if (check(p, TOK_FLOAT_LIT)) {
        AstNode *n = ast_node(NODE_FLOAT_LIT, line, col);
        n->fval    = atof(p->current.value);
        n->sval    = strdup(p->current.value);
        advance_tok(p);
        return n;
    }
    /* String literal */
    if (check(p, TOK_STRING_LIT)) {
        AstNode *n = ast_node(NODE_STRING_LIT, line, col);
        n->sval    = strdup(p->current.value);
        advance_tok(p);
        return n;
    }
    /* Boolean */
    if (check(p, TOK_TRUE) || check(p, TOK_FALSE)) {
        AstNode *n = ast_node(NODE_BOOL_LIT, line, col);
        n->bval    = check(p, TOK_TRUE) ? 1 : 0;
        n->sval    = strdup(p->current.value);
        advance_tok(p);
        return n;
    }
    /* Parenthesised expression */
    if (check(p, TOK_LPAREN)) {
        advance_tok(p);
        AstNode *e = parse_expr(p);
        expect(p, TOK_RPAREN);
        return e;
    }
    /* Closure: |params| => expr */
    if (check(p, TOK_PIPE)) {
        return parse_closure_expr(p);
    }
    /* Array literal */
    if (check(p, TOK_LBRACKET)) {
        AstNode *arr = ast_node(NODE_ARRAY_LIT, line, col);
        advance_tok(p);
        skip_newlines(p);
        while (!check(p, TOK_RBRACKET) && !check(p, TOK_EOF)) {
            ast_add_child(arr, parse_expr(p));
            if (!match(p, TOK_COMMA)) break;
            skip_newlines(p);
        }
        expect(p, TOK_RBRACKET);
        return arr;
    }
    /* Await expression */
    if (check(p, TOK_AWAIT)) {
        advance_tok(p);
        AstNode *n = ast_node(NODE_AWAIT_EXPR, line, col);
        ast_add_child(n, parse_expr(p));
        return n;
    }
    /* Identifier (possibly function call) */
    if (check(p, TOK_IDENT)) {
        AstNode *n = ast_node(NODE_IDENT, line, col);
        n->sval    = strdup(p->current.value);
        advance_tok(p);
        return n;
    }
    /* Unary minus / bang */
    if (check(p, TOK_MINUS) || check(p, TOK_BANG)) {
        char op = check(p, TOK_MINUS) ? '-' : '!';
        advance_tok(p);
        AstNode *n = ast_node(NODE_UNARY_OP, line, col);
        char buf[3] = {op, '\0', '\0'};
        n->sval = strdup(buf);
        /* Parse operand with postfix (calls, member access) included */
        AstNode *operand = parse_primary(p);
        /* Apply postfix operations to operand */
        while (check(p, TOK_LPAREN) || check(p, TOK_DOT) ||
               check(p, TOK_LBRACKET) || check(p, TOK_COLONCOLON) ||
               check(p, TOK_QUESTION_DOT)) {
            int pline = p->current.line, pcol = p->current.col;
            if (check(p, TOK_LPAREN)) {
                AstNode *call = ast_node(NODE_CALL, pline, pcol);
                ast_add_child(call, operand);
                advance_tok(p);
                while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) {
                    ast_add_child(call, parse_expr(p));
                    if (!match(p, TOK_COMMA)) break;
                }
                expect(p, TOK_RPAREN);
                operand = call;
            } else if (check(p, TOK_DOT) || check(p, TOK_QUESTION_DOT)) {
                int is_opt = check(p, TOK_QUESTION_DOT);
                advance_tok(p);
                AstNode *mem = ast_node(NODE_MEMBER, pline, pcol);
                mem->sval = strdup(p->current.value ? p->current.value : "?");
                mem->ival = is_opt;
                advance_tok(p);
                ast_add_child(mem, operand);
                operand = mem;
            } else if (check(p, TOK_LBRACKET)) {
                advance_tok(p);
                AstNode *idx = ast_node(NODE_INDEX, pline, pcol);
                ast_add_child(idx, operand);
                ast_add_child(idx, parse_expr(p));
                expect(p, TOK_RBRACKET);
                operand = idx;
            } else { break; }
        }
        ast_add_child(n, operand);
        return n;
    }

    /* fallback */
    AstNode *err = ast_node(NODE_IDENT, line, col);
    err->sval = strdup(p->current.value ? p->current.value : "?");
    fprintf(stderr, "Parse warning: unexpected token '%s' at line %d\n",
            err->sval, line);
    if (!p->had_error) {
        p->had_error = 1;
        p->error_line = line;
        p->error_col = col;
        snprintf(p->error_msg, sizeof(p->error_msg),
                 "Line %d: unexpected token '%s'", line, err->sval);
    }
    advance_tok(p);
    return err;
}

/* ── Pratt expression parser ───────────────────────────────── */
static AstNode *parse_expr_prec(Parser *p, Precedence min_prec) {
    AstNode *left = parse_primary(p);

    while (1) {
        TokenType op = p->current.type;
        Precedence prec = get_prec(op);
        if (prec <= min_prec) break;

        int line = p->current.line, col = p->current.col;

        /* Member access: . or ?. */
        if (op == TOK_DOT || op == TOK_QUESTION_DOT) {
            advance_tok(p);
            char *member = strdup(p->current.value ? p->current.value : "?");
            advance_tok(p);
            /* Method call? */
            if (check(p, TOK_LPAREN)) {
                AstNode *mc = ast_node(NODE_METHOD_CALL, line, col);
                mc->sval = member;
                ast_add_child(mc, left);
                advance_tok(p); /* ( */
                skip_newlines(p);
                while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) {
                    ast_add_child(mc, parse_expr(p));
                    if (!match(p, TOK_COMMA)) break;
                    skip_newlines(p);
                }
                expect(p, TOK_RPAREN);
                left = mc;
            } else {
                AstNode *mem = ast_node(NODE_MEMBER, line, col);
                mem->sval = member;
                ast_add_child(mem, left);
                left = mem;
            }
            continue;
        }
        /* Function call */
        if (op == TOK_LPAREN) {
            left = parse_call_args(p, left);
            continue;
        }
        /* Index access */
        if (op == TOK_LBRACKET) {
            advance_tok(p);
            AstNode *idx = ast_node(NODE_INDEX, line, col);
            ast_add_child(idx, left);
            ast_add_child(idx, parse_expr(p));
            expect(p, TOK_RBRACKET);
            left = idx;
            continue;
        }
        /* Assignment operators */
        if (op == TOK_ASSIGN || op == TOK_PLUS_ASSIGN ||
            op == TOK_MINUS_ASSIGN || op == TOK_STAR_ASSIGN) {
            const char *opstr = p->current.value;
            advance_tok(p);
            AstNode *asgn = ast_node(NODE_ASSIGN_STMT, line, col);
            asgn->sval = strdup(opstr);
            ast_add_child(asgn, left);
            ast_add_child(asgn, parse_expr_prec(p, PREC_ASSIGN - 1));
            return asgn;
        }
        /* Binary operators */
        advance_tok(p);
        AstNode *bin = ast_node(NODE_BINARY_OP, line, col);
        switch (op) {
            case TOK_PLUS:    bin->sval = strdup("+");  break;
            case TOK_MINUS:   bin->sval = strdup("-");  break;
            case TOK_STAR:    bin->sval = strdup("*");  break;
            case TOK_SLASH:   bin->sval = strdup("/");  break;
            case TOK_PERCENT: bin->sval = strdup("%");  break;
            case TOK_EQ:      bin->sval = strdup("=="); break;
            case TOK_NEQ:     bin->sval = strdup("!="); break;
            case TOK_LT:      bin->sval = strdup("<");  break;
            case TOK_GT:      bin->sval = strdup(">");  break;
            case TOK_LEQ:     bin->sval = strdup("<="); break;
            case TOK_GEQ:     bin->sval = strdup(">="); break;
            case TOK_AND_AND: bin->sval = strdup("&&"); break;
            case TOK_OR_OR:   bin->sval = strdup("||"); break;
            case TOK_DOTDOT:  bin->sval = strdup(".."); break;
            default:          bin->sval = strdup("?");  break;
        }
        ast_add_child(bin, left);
        ast_add_child(bin, parse_expr_prec(p, prec));
        left = bin;
    }
    return left;
}

static AstNode *parse_expr(Parser *p) {
    return parse_expr_prec(p, PREC_NONE);
}

/* ── Call argument list ────────────────────────────────────── */
static AstNode *parse_call_args(Parser *p, AstNode *callee) {
    int line = p->current.line, col = p->current.col;
    AstNode *call = ast_node(NODE_CALL, line, col);
    ast_add_child(call, callee);
    expect(p, TOK_LPAREN);
    skip_newlines(p);
    while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) {
        ast_add_child(call, parse_expr(p));
        if (!match(p, TOK_COMMA)) break;
        skip_newlines(p);
    }
    expect(p, TOK_RPAREN);
    return call;
}

/* ── Block (brace or indent style) ────────────────────────── */
static AstNode *parse_block(Parser *p) {
    int line = p->current.line, col = p->current.col;
    AstNode *block = ast_node(NODE_BLOCK, line, col);

    if (check(p, TOK_LBRACE)) {
        advance_tok(p);
        skip_newlines(p);
        while (!check(p, TOK_RBRACE) && !check(p, TOK_EOF)) {
            AstNode *s = parse_stmt(p);
            if (s) ast_add_child(block, s);
            skip_newlines(p);
        }
        expect(p, TOK_RBRACE);
    } else if (check(p, TOK_COLON)) {
        /* indent-style block: colon + NEWLINE + INDENT  -OR-  colon + inline stmt */
        advance_tok(p);
        /* Check if this is a multi-line block (NEWLINE then INDENT) */
        int had_newline = 0;
        while (check(p, TOK_NEWLINE)) { advance_tok(p); had_newline = 1; }
        if (had_newline && check(p, TOK_INDENT)) {
            /* Multi-line block: consume INDENT, parse until DEDENT */
            advance_tok(p);
            while (!check(p, TOK_DEDENT) && !check(p, TOK_EOF)) {
                skip_newlines(p);
                if (check(p, TOK_DEDENT)) break;
                AstNode *s = parse_stmt(p);
                if (s) ast_add_child(block, s);
            }
            if (check(p, TOK_DEDENT)) advance_tok(p);
        } else if (had_newline) {
            /* Newline but no INDENT — single statement on next line */
            skip_newlines(p);
            AstNode *s = parse_stmt(p);
            if (s) ast_add_child(block, s);
        } else {
            /* Inline single statement: if cond: stmt */
            if (!check(p, TOK_NEWLINE) && !check(p, TOK_EOF) &&
                !check(p, TOK_DEDENT) && !check(p, TOK_RBRACE)) {
                AstNode *s = parse_stmt(p);
                if (s) ast_add_child(block, s);
            }
        }
    } else {
        /* Single-statement inline block */
        AstNode *s = parse_stmt(p);
        if (s) ast_add_child(block, s);
    }
    return block;
}

/* ── Parameter list ────────────────────────────────────────── */
static void parse_params(Parser *p, AstNode *fn_node) {
    expect(p, TOK_LPAREN);
    while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) {
        int pline = p->current.line, pcol = p->current.col;
        AstNode *param = ast_node(NODE_PARAM, pline, pcol);
        /* Skip &self / &mut self */
        if (check(p, TOK_AMPERSAND)) {
            advance_tok(p);
            if (check(p, TOK_MUT)) advance_tok(p);
        }
        param->sval = strdup(p->current.value ? p->current.value : "?");
        advance_tok(p); /* param name */
        if (match(p, TOK_COLON)) {
            param->type_node = parse_type(p);
        }
        /* Default value */
        if (match(p, TOK_ASSIGN)) {
            ast_add_child(param, parse_expr(p));
        }
        ast_add_child(fn_node, param);
        if (!match(p, TOK_COMMA)) break;
    }
    expect(p, TOK_RPAREN);
}

/* ── Function declaration ──────────────────────────────────── */
static AstNode *parse_fn_decl(Parser *p, int is_async) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_FN);
    AstNode *fn = ast_node(NODE_FN_DECL, line, col);
    fn->is_async = is_async;
    fn->sval = strdup(p->current.value ? p->current.value : "anon");
    advance_tok(p); /* function name */

    /* Parameters */
    if (check(p, TOK_LPAREN)) {
        parse_params(p, fn);
    }

    /* Return type */
    if (match(p, TOK_ARROW)) {
        fn->type_node = parse_type(p);
    }

    skip_newlines(p);

    /* Body */
    ast_add_child(fn, parse_block(p));
    return fn;
}

/* ── If statement ──────────────────────────────────────────── */
static AstNode *parse_if_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_IF);
    AstNode *ifn = ast_node(NODE_IF_STMT, line, col);
    ast_add_child(ifn, parse_expr(p));   /* condition */
    ast_add_child(ifn, parse_block(p));  /* then-block */
    skip_newlines(p);
    if (check(p, TOK_ELSE)) {
        advance_tok(p);
        if (check(p, TOK_IF)) {
            ast_add_child(ifn, parse_if_stmt(p));
        } else {
            ast_add_child(ifn, parse_block(p));
        }
    }
    return ifn;
}

/* ── For statement ─────────────────────────────────────────── */
static AstNode *parse_for_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_FOR);
    AstNode *forn = ast_node(NODE_FOR_STMT, line, col);
    /* loop variable */
    AstNode *var = ast_node(NODE_IDENT, p->current.line, p->current.col);
    var->sval = strdup(p->current.value ? p->current.value : "i");
    advance_tok(p);
    ast_add_child(forn, var);
    expect(p, TOK_IN);
    ast_add_child(forn, parse_expr(p)); /* iterable / range */
    ast_add_child(forn, parse_block(p));
    return forn;
}

/* ── While statement ───────────────────────────────────────── */
static AstNode *parse_while_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_WHILE);
    AstNode *wn = ast_node(NODE_WHILE_STMT, line, col);
    ast_add_child(wn, parse_expr(p));
    ast_add_child(wn, parse_block(p));
    return wn;
}

/* ── Match statement ───────────────────────────────────────── */
static AstNode *parse_match_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_MATCH);
    AstNode *mn = ast_node(NODE_MATCH_STMT, line, col);
    ast_add_child(mn, parse_expr(p));
    /* skip newlines, indents, dedents before { */
    while (check(p, TOK_NEWLINE) || check(p, TOK_INDENT) || check(p, TOK_DEDENT))
        advance_tok(p);
    expect(p, TOK_LBRACE);
    /* skip newlines and indents inside { */
    while (check(p, TOK_NEWLINE) || check(p, TOK_INDENT)) advance_tok(p);
    while (!check(p, TOK_RBRACE) && !check(p, TOK_EOF) && !check(p, TOK_DEDENT)) {
        /* skip blank lines between arms */
        while (check(p, TOK_NEWLINE) || check(p, TOK_INDENT)) advance_tok(p);
        if (check(p, TOK_RBRACE) || check(p, TOK_EOF) || check(p, TOK_DEDENT)) break;
        AstNode *arm = ast_node(NODE_MATCH_ARM, p->current.line, p->current.col);
        /* pattern */
        ast_add_child(arm, parse_expr(p));
        /* skip whitespace before => */
        while (check(p, TOK_NEWLINE) || check(p, TOK_INDENT)) advance_tok(p);
        expect(p, TOK_FAT_ARROW);
        /* arm body */
        if (check(p, TOK_LBRACE)) {
            ast_add_child(arm, parse_block(p));
        } else {
            AstNode *body = ast_node(NODE_BLOCK, p->current.line, p->current.col);
            ast_add_child(body, parse_stmt(p));
            ast_add_child(arm, body);
        }
        match(p, TOK_COMMA);
        /* skip newlines after arm */
        while (check(p, TOK_NEWLINE)) advance_tok(p);
        ast_add_child(mn, arm);
    }
    /* consume dedents and closing brace */
    while (check(p, TOK_DEDENT)) advance_tok(p);
    expect(p, TOK_RBRACE);
    return mn;
}


/* ── Enum declaration ──────────────────────────────────────── */
static AstNode *parse_enum_decl(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_ENUM);
    AstNode *en = ast_node(NODE_ENUM_DECL, line, col);
    en->sval = strdup(p->current.value ? p->current.value : "Enum");
    advance_tok(p); /* name */
    skip_newlines(p);
    /* Optional generic params <T, E> */
    if (check(p, TOK_LT)) {
        advance_tok(p);
        while (!check(p, TOK_GT) && !check(p, TOK_EOF)) {
            AstNode *tp = ast_node(NODE_TYPE_PARAM, p->current.line, p->current.col);
            tp->sval = strdup(p->current.value ? p->current.value : "T");
            advance_tok(p);
            ast_add_child(en, tp);
            match(p, TOK_COMMA);
        }
        expect(p, TOK_GT);
    }
    if (match(p, TOK_COLON)) {
        skip_newlines(p);
        /* indented or brace body */
        int use_brace = check(p, TOK_LBRACE);
        if (use_brace) { advance_tok(p); skip_newlines(p); }
        else if (check(p, TOK_INDENT)) { advance_tok(p); }
        while (!check(p, TOK_EOF) &&
               !check(p, TOK_DEDENT) &&
               !(use_brace && check(p, TOK_RBRACE))) {
            skip_newlines(p);
            if (check(p, TOK_DEDENT) || check(p, TOK_EOF)) break;
            if (use_brace && check(p, TOK_RBRACE)) break;
            /* Stop at top-level declaration keyword */
            if (!use_brace && p->current.col == 1 &&
                (check(p, TOK_FN) || check(p, TOK_ENUM) || check(p, TOK_STRUCT) ||
                 check(p, TOK_IMPL) || check(p, TOK_MACRO) || check(p, TOK_TRAIT))) break;
            AstNode *var = ast_node(NODE_ENUM_VARIANT, p->current.line, p->current.col);
            var->sval = strdup(p->current.value ? p->current.value : "Variant");
            advance_tok(p);
            /* Optional payload (field: type, ...) */
            if (check(p, TOK_LPAREN)) {
                advance_tok(p);
                while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) {
                    AstNode *f = ast_node(NODE_PARAM, p->current.line, p->current.col);
                    f->sval = strdup(p->current.value ? p->current.value : "v");
                    advance_tok(p);
                    if (match(p, TOK_COLON)) f->type_node = parse_type(p);
                    ast_add_child(var, f);
                    match(p, TOK_COMMA);
                }
                expect(p, TOK_RPAREN);
            }
            skip_newlines(p);
            match(p, TOK_COMMA);
            skip_newlines(p);
            ast_add_child(en, var);
        }
        if (use_brace) { match(p, TOK_RBRACE); }
        else { match(p, TOK_DEDENT); }
    }
    return en;
}

/* ── Closure / Lambda expression ───────────────────────────── */
static AstNode *parse_closure_expr(Parser *p) {
    int line = p->current.line, col = p->current.col;
    AstNode *cl = ast_node(NODE_CLOSURE, line, col);
    expect(p, TOK_PIPE);
    /* parameters */
    while (!check(p, TOK_PIPE) && !check(p, TOK_EOF)) {
        AstNode *pm = ast_node(NODE_PARAM, p->current.line, p->current.col);
        pm->sval = strdup(p->current.value ? p->current.value : "x");
        advance_tok(p);
        if (match(p, TOK_COLON)) pm->type_node = parse_type(p);
        ast_add_child(cl, pm);
        match(p, TOK_COMMA);
    }
    expect(p, TOK_PIPE);
    /* optional return type */
    if (check(p, TOK_ARROW)) {
        advance_tok(p);
        cl->type_node = parse_type(p);
    }
    /* body: => expr  OR  { block } */
    if (check(p, TOK_FAT_ARROW)) {
        advance_tok(p);
        AstNode *body = ast_node(NODE_BLOCK, line, col);
        AstNode *ret  = ast_node(NODE_RETURN_STMT, line, col);
        ast_add_child(ret, parse_expr(p));
        ast_add_child(body, ret);
        cl->children = realloc(cl->children,
            sizeof(AstNode*) * (cl->child_count + 1));
        cl->children[cl->child_count++] = body;
    } else if (check(p, TOK_LBRACE)) {
        cl->children = realloc(cl->children,
            sizeof(AstNode*) * (cl->child_count + 1));
        cl->children[cl->child_count++] = parse_block(p);
    }
    return cl;
}


/* ═══════════════════════════════════════════════════════════
 * MACRO DEFINITION
 * Syntax:
 *   macro assert!(cond):
 *       if !(cond): panic("assertion failed: cond")
 *
 *   macro vec![items...]:
 *       let v = Vec::new(); for item in items: v.push(item); v
 * ═══════════════════════════════════════════════════════════ */
static AstNode *parse_macro_def(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_MACRO);
    AstNode *md = ast_node(NODE_MACRO_DEF, line, col);
    /* name (may include trailing ! or []) */
    md->sval = strdup(p->current.value ? p->current.value : "macro");
    advance_tok(p);
    /* optional suffix: ! */
    if (check(p, TOK_BANG)) { 
        char buf[256];
        snprintf(buf, sizeof(buf), "%s!", md->sval);
        free(md->sval); md->sval = strdup(buf);
        advance_tok(p);
    }
    /* params */
    if (check(p, TOK_LPAREN)) {
        advance_tok(p);
        while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) {
            AstNode *pm = ast_node(NODE_PARAM, p->current.line, p->current.col);
            pm->sval = strdup(p->current.value ? p->current.value : "x");
            advance_tok(p);
            match(p, TOK_COMMA);
            ast_add_child(md, pm);
        }
        expect(p, TOK_RPAREN);
    }
    skip_newlines(p);
    if (match(p, TOK_COLON)) {
        skip_newlines(p);
        if (check(p, TOK_INDENT)) advance_tok(p);
        AstNode *body = ast_node(NODE_BLOCK, line, col);
        /* Stop at DEDENT, EOF, or any top-level keyword that can't be in a macro */
        while (!check(p, TOK_DEDENT) && !check(p, TOK_EOF)) {
            skip_newlines(p);
            if (check(p, TOK_DEDENT) || check(p, TOK_EOF)) break;
            /* Stop if we hit a top-level declaration keyword at col 0 */
            if (p->current.col == 1 &&
                (check(p, TOK_FN)    || check(p, TOK_ENUM)  ||
                 check(p, TOK_STRUCT)|| check(p, TOK_IMPL)  ||
                 check(p, TOK_MACRO) || check(p, TOK_TRAIT) ||
                 check(p, TOK_ASM)   || check(p, TOK_MODULE)||
                 check(p, TOK_USE)   || check(p, TOK_IMPORT)||
                 check(p, TOK_CONST) || check(p, TOK_ASYNC) ||
                 check(p, TOK_PUB))) break;
            ast_add_child(body, parse_stmt(p));
        }
        match(p, TOK_DEDENT);
        ast_add_child(md, body);
    }
    return md;
}

/* ═══════════════════════════════════════════════════════════
 * INLINE ASSEMBLY
 * Syntax:
 *   asm! {
 *       "mov rax, 60"
 *       "xor rdi, rdi"
 *       "syscall"
 *   }
 *   asm!("nop" : "=r"(out) : "r"(in) : "rax")
 * ═══════════════════════════════════════════════════════════ */
static AstNode *parse_asm_block(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_ASM);
    if (check(p, TOK_BANG)) advance_tok(p); /* consume ! */
    AstNode *an = ast_node(NODE_ASM_BLOCK, line, col);
    /* Two forms: asm! { "..." } or asm!("...") */
    if (check(p, TOK_LBRACE)) {
        advance_tok(p); skip_newlines(p);
        /* collect all string literals as one asm blob */
        char buf[4096] = {0};
        while (!check(p, TOK_RBRACE) && !check(p, TOK_EOF)) {
            skip_newlines(p);
            if (check(p, TOK_RBRACE)) break;
            if (check(p, TOK_STRING_LIT)) {
                strncat(buf, p->current.value, sizeof(buf)-strlen(buf)-4);
                strncat(buf, "\\n\\t", sizeof(buf)-strlen(buf)-1);
                advance_tok(p);
            } else { advance_tok(p); }
        }
        expect(p, TOK_RBRACE);
        an->sval = strdup(buf);
    } else if (check(p, TOK_LPAREN)) {
        advance_tok(p);
        if (check(p, TOK_STRING_LIT)) { an->sval = strdup(p->current.value); advance_tok(p); }
        /* skip constraints */
        while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF)) advance_tok(p);
        expect(p, TOK_RPAREN);
    }
    return an;
}

/* ═══════════════════════════════════════════════════════════
 * MODULE SYSTEM
 * Syntax:
 *   module math             — declares current file is module 'math'
 *   use math::gcd           — import specific symbol
 *   use math::{gcd, lcm}   — import multiple
 *   use math::*             — glob import
 *   pub fn foo() ...        — public export
 * ═══════════════════════════════════════════════════════════ */
static AstNode *parse_module_decl(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_MODULE);
    AstNode *mn = ast_node(NODE_MODULE_DECL, line, col);
    char path[512] = {0};
    if (p->current.type == TOK_IDENT) {
        strncpy(path, p->current.value, sizeof(path)-1);
        advance_tok(p);
        while (check(p, TOK_COLONCOLON) || check(p, TOK_DOT)) {
            advance_tok(p);
            if (p->current.type == TOK_IDENT) {
                strncat(path, "::", sizeof(path)-strlen(path)-1);
                strncat(path, p->current.value, sizeof(path)-strlen(path)-1);
                advance_tok(p);
            }
        }
    }
    mn->sval = strdup(path);
    return mn;
}

static AstNode *parse_use_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_USE);
    AstNode *us = ast_node(NODE_USE_STMT, line, col);
    char path[512] = {0};
    while (p->current.type == TOK_IDENT || p->current.type == TOK_STAR) {
        if (p->current.type == TOK_STAR) { strncat(path, "*", sizeof(path)-strlen(path)-1); advance_tok(p); break; }
        strncat(path, p->current.value, sizeof(path)-strlen(path)-1);
        advance_tok(p);
        if (check(p, TOK_COLONCOLON)) {
            strncat(path, "::", sizeof(path)-strlen(path)-1);
            advance_tok(p);
            if (check(p, TOK_LBRACE)) {
                /* use mod::{a,b,c} */
                advance_tok(p);
                while (!check(p, TOK_RBRACE) && !check(p, TOK_EOF)) {
                    if (p->current.type == TOK_IDENT) {
                        AstNode *sym = ast_node(NODE_IDENT, p->current.line, p->current.col);
                        sym->sval = strdup(p->current.value);
                        ast_add_child(us, sym);
                        advance_tok(p);
                    }
                    match(p, TOK_COMMA);
                }
                expect(p, TOK_RBRACE);
                break;
            }
        } else break;
    }
    us->sval = strdup(path);
    return us;
}

/* ═══════════════════════════════════════════════════════════
 * CHANNELS + GOROUTINES
 * Syntax:
 *   let ch = chan<int>(10)      — buffered channel
 *   let ch = chan<int>()        — unbuffered
 *   ch <- 42                    — send
 *   let val = <-ch              — receive
 *   go fn(): ...                — goroutine (already supported)
 *   select {                    — select statement
 *       ch1 <- v => ...
 *       <-ch2    => ...
 *   }
 * ═══════════════════════════════════════════════════════════ */
static AstNode *parse_select_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_SELECT);
    AstNode *sel = ast_node(NODE_SELECT_STMT, line, col);
    skip_newlines(p);
    expect(p, TOK_LBRACE);
    skip_newlines(p);
    while (!check(p, TOK_RBRACE) && !check(p, TOK_EOF)) {
        skip_newlines(p);
        if (check(p, TOK_RBRACE)) break;
        AstNode *arm = ast_node(NODE_MATCH_ARM, p->current.line, p->current.col);
        /* Pattern: ch <- val  OR  <-ch */
        AstNode *comm = ast_node(NODE_EXPR_STMT, p->current.line, p->current.col);
        ast_add_child(comm, parse_expr(p));
        ast_add_child(arm, comm);
        expect(p, TOK_FAT_ARROW);
        if (check(p, TOK_LBRACE)) ast_add_child(arm, parse_block(p));
        else {
            AstNode *b = ast_node(NODE_BLOCK, line, col);
            ast_add_child(b, parse_stmt(p));
            ast_add_child(arm, b);
        }
        match(p, TOK_COMMA);
        skip_newlines(p);
        ast_add_child(sel, arm);
    }
    expect(p, TOK_RBRACE);
    return sel;
}
/* ── Let statement ─────────────────────────────────────────── */
static AstNode *parse_let_stmt(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_LET);
    AstNode *let = ast_node(NODE_LET_STMT, line, col);
    if (check(p, TOK_MUT)) { advance_tok(p); let->is_mut = 1; }
    let->sval = strdup(p->current.value ? p->current.value : "?");
    advance_tok(p); /* name */
    if (match(p, TOK_COLON)) {
        let->type_node = parse_type(p);
    }
    if (match(p, TOK_ASSIGN)) {
        ast_add_child(let, parse_expr(p));
    }
    return let;
}

/* ── Import statement ──────────────────────────────────────── */
static AstNode *parse_import(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_IMPORT);
    AstNode *imp = ast_node(NODE_IMPORT_STMT, line, col);
    /* collect module path: a.b.c */
    char path[256] = {0};
    int first = 1;
    while (check(p, TOK_IDENT) || check(p, TOK_INT_TYPE) ||
           check(p, TOK_STR_TYPE)) {
        if (!first) strcat(path, ".");
        strcat(path, p->current.value ? p->current.value : "");
        advance_tok(p);
        first = 0;
        if (!match(p, TOK_DOT)) break;
    }
    imp->sval = strdup(path);
    if (match(p, TOK_AS)) {
        AstNode *alias = ast_node(NODE_IDENT, line, col);
        alias->sval = strdup(p->current.value ? p->current.value : "");
        advance_tok(p);
        ast_add_child(imp, alias);
    }
    return imp;
}

/* ── Struct declaration ────────────────────────────────────── */
static AstNode *parse_struct(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_STRUCT);
    AstNode *sn = ast_node(NODE_STRUCT_DECL, line, col);
    sn->sval = strdup(p->current.value ? p->current.value : "?");
    advance_tok(p);
    skip_newlines(p);
    if (check(p, TOK_LBRACE)) {
        advance_tok(p);
        skip_newlines(p);
        while (!check(p, TOK_RBRACE) && !check(p, TOK_EOF)) {
            AstNode *field = ast_node(NODE_FIELD, p->current.line, p->current.col);
            field->sval = strdup(p->current.value ? p->current.value : "?");
            advance_tok(p);
            if (match(p, TOK_COLON)) field->type_node = parse_type(p);
            ast_add_child(sn, field);
            skip_newlines(p);
            match(p, TOK_COMMA);
            skip_newlines(p);
        }
        expect(p, TOK_RBRACE);
    } else if (check(p, TOK_COLON)) {
        advance_tok(p);
        skip_newlines(p);
        if (check(p, TOK_INDENT)) advance_tok(p);
        while (!check(p, TOK_DEDENT) && !check(p, TOK_EOF)) {
            skip_newlines(p);
            if (check(p, TOK_DEDENT)) break;
            AstNode *field = ast_node(NODE_FIELD, p->current.line, p->current.col);
            field->sval = strdup(p->current.value ? p->current.value : "?");
            advance_tok(p);
            if (match(p, TOK_COLON)) field->type_node = parse_type(p);
            ast_add_child(sn, field);
            skip_newlines(p);
        }
        if (check(p, TOK_DEDENT)) advance_tok(p);
    }
    return sn;
}

/* ── Annotation (@...) ─────────────────────────────────────── */
static AstNode *parse_annotation(Parser *p) {
    int line = p->current.line, col = p->current.col;
    expect(p, TOK_AT);
    AstNode *an = ast_node(NODE_ANNOTATION, line, col);
    an->sval = strdup(p->current.value ? p->current.value : "");
    advance_tok(p);
    if (check(p, TOK_LPAREN)) {
        advance_tok(p);
        while (!check(p, TOK_RPAREN) && !check(p, TOK_EOF))
            advance_tok(p);
        expect(p, TOK_RPAREN);
    }
    return an;
}

/* ── Statement dispatcher ──────────────────────────────────── */
static AstNode *parse_stmt(Parser *p) {
    skip_newlines(p);
    int line = p->current.line, col = p->current.col;

    /* Annotation */
    if (check(p, TOK_AT)) {
        AstNode *ann = parse_annotation(p);
        skip_newlines(p);
        AstNode *next = parse_stmt(p);
        if (next) ast_add_child(next, ann);
        return next;
    }
    /* Import */
    if (check(p, TOK_IMPORT)) return parse_import(p);
    /* Async fn */
    if (check(p, TOK_ASYNC)) {
        advance_tok(p);
        if (check(p, TOK_FN)) return parse_fn_decl(p, 1);
        /* async block — skip */
    }
    /* fn */
    if (check(p, TOK_FN)) return parse_fn_decl(p, 0);
    /* let */
    if (check(p, TOK_LET)) return parse_let_stmt(p);
    /* const */
    if (check(p, TOK_CONST)) {
        advance_tok(p);
        AstNode *cn = ast_node(NODE_CONST_STMT, line, col);
        cn->sval = strdup(p->current.value ? p->current.value : "?");
        advance_tok(p);
        if (match(p, TOK_COLON)) cn->type_node = parse_type(p);
        if (match(p, TOK_ASSIGN)) ast_add_child(cn, parse_expr(p));
        return cn;
    }
    /* struct */
    if (check(p, TOK_STRUCT)) return parse_struct(p);
    /* enum */
    if (check(p, TOK_ENUM))   return parse_enum_decl(p);
    /* macro */
    if (check(p, TOK_MACRO))  return parse_macro_def(p);
    /* asm */
    if (check(p, TOK_ASM))    return parse_asm_block(p);
    /* module */
    if (check(p, TOK_MODULE)) return parse_module_decl(p);
    /* use */
    if (check(p, TOK_USE))    return parse_use_stmt(p);
    /* select */
    if (check(p, TOK_SELECT)) return parse_select_stmt(p);
    /* pub — skip modifier, parse what follows */
    if (check(p, TOK_PUB))    { advance_tok(p); return parse_stmt(p); }
    /* return */
    if (check(p, TOK_RETURN)) {
        advance_tok(p);
        AstNode *rn = ast_node(NODE_RETURN_STMT, line, col);
        if (!check(p, TOK_NEWLINE) && !check(p, TOK_SEMICOLON) &&
            !check(p, TOK_RBRACE)  && !check(p, TOK_DEDENT)    &&
            !check(p, TOK_EOF))
            ast_add_child(rn, parse_expr(p));
        return rn;
    }
    /* if */
    if (check(p, TOK_IF)) return parse_if_stmt(p);
    /* while */
    if (check(p, TOK_WHILE)) return parse_while_stmt(p);
    /* for */
    if (check(p, TOK_FOR)) return parse_for_stmt(p);
    /* match */
    if (check(p, TOK_MATCH)) return parse_match_stmt(p);
    /* print (built-in keyword) */
    if (check(p, TOK_PRINT)) {
        advance_tok(p);
        AstNode *pr = ast_node(NODE_PRINT_STMT, line, col);
        if (check(p, TOK_LPAREN)) {
            advance_tok(p);
            if (!check(p, TOK_RPAREN))
                ast_add_child(pr, parse_expr(p));
            expect(p, TOK_RPAREN);
        }
        return pr;
    }
    /* defer */
    if (check(p, TOK_DEFER)) {
        advance_tok(p);
        AstNode *dn = ast_node(NODE_DEFER_STMT, line, col);
        ast_add_child(dn, parse_expr(p));
        return dn;
    }
    /* Expression statement (covers assignments, calls, etc.) */
    if (!check(p, TOK_EOF) && !check(p, TOK_RBRACE) &&
        !check(p, TOK_DEDENT)) {
        AstNode *es = ast_node(NODE_EXPR_STMT, line, col);
        ast_add_child(es, parse_expr(p));
        match(p, TOK_SEMICOLON);
        return es;
    }
    return NULL;
}

/* ── Top-level program parser ──────────────────────────────── */
AstNode *parser_parse(Parser *p) {
    AstNode *prog = ast_node(NODE_PROGRAM, 1, 1);
    skip_newlines(p);
    while (!check(p, TOK_EOF)) {
        AstNode *s = parse_stmt(p);
        if (s) ast_add_child(prog, s);
        skip_newlines(p);
    }
    return prog;
}
