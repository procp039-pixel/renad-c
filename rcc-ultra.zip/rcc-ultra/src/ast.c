/* ============================================================
 * Renad C Compiler — AST Implementation
 * ============================================================ */
#include "ast.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

AstNode *ast_node(NodeType type, int line, int col) {
    AstNode *n  = calloc(1, sizeof(AstNode));
    n->type     = type;
    n->line     = line;
    n->col      = col;
    n->child_cap = 4;
    n->children  = malloc(n->child_cap * sizeof(AstNode *));
    return n;
}

void ast_add_child(AstNode *parent, AstNode *child) {
    if (!child) return;
    if (parent->child_count >= parent->child_cap) {
        parent->child_cap *= 2;
        parent->children = realloc(parent->children,
                                   parent->child_cap * sizeof(AstNode *));
    }
    parent->children[parent->child_count++] = child;
}

void ast_free(AstNode *node) {
    if (!node) return;
    for (int i = 0; i < node->child_count; i++)
        ast_free(node->children[i]);
    free(node->children);
    free(node->sval);
    ast_free(node->type_node);
    free(node);
}

/* ── Pretty printer ────────────────────────────────────────── */
static const char *node_name(NodeType t) {
    switch (t) {
        case NODE_PROGRAM:      return "Program";
        case NODE_FN_DECL:      return "FnDecl";
        case NODE_LET_STMT:     return "LetStmt";
        case NODE_CONST_STMT:   return "ConstStmt";
        case NODE_RETURN_STMT:  return "ReturnStmt";
        case NODE_IF_STMT:      return "IfStmt";
        case NODE_WHILE_STMT:   return "WhileStmt";
        case NODE_FOR_STMT:     return "ForStmt";
        case NODE_BLOCK:        return "Block";
        case NODE_EXPR_STMT:    return "ExprStmt";
        case NODE_PRINT_STMT:   return "PrintStmt";
        case NODE_IMPORT_STMT:  return "ImportStmt";
        case NODE_CLASS_DECL:   return "ClassDecl";
        case NODE_STRUCT_DECL:  return "StructDecl";
        case NODE_IMPL_BLOCK:   return "ImplBlock";
        case NODE_ASSIGN_STMT:  return "AssignStmt";
        case NODE_MATCH_STMT:   return "MatchStmt";
        case NODE_DEFER_STMT:   return "DeferStmt";
        case NODE_INT_LIT:      return "IntLit";
        case NODE_FLOAT_LIT:    return "FloatLit";
        case NODE_STRING_LIT:   return "StringLit";
        case NODE_BOOL_LIT:     return "BoolLit";
        case NODE_IDENT:        return "Ident";
        case NODE_BINARY_OP:    return "BinaryOp";
        case NODE_UNARY_OP:     return "UnaryOp";
        case NODE_CALL:         return "Call";
        case NODE_INDEX:        return "Index";
        case NODE_MEMBER:       return "Member";
        case NODE_ARRAY_LIT:    return "ArrayLit";
        case NODE_STRUCT_LIT:   return "StructLit";
        case NODE_LAMBDA:       return "Lambda";
        case NODE_IF_EXPR:      return "IfExpr";
        case NODE_AWAIT_EXPR:   return "AwaitExpr";
        case NODE_INTERP_STRING:return "InterpString";
        case NODE_RANGE:        return "Range";
        case NODE_METHOD_CALL:  return "MethodCall";
        case NODE_TYPE_NAME:    return "TypeName";
        case NODE_TYPE_GENERIC: return "TypeGeneric";
        case NODE_TYPE_ARRAY:   return "TypeArray";
        case NODE_TYPE_OPTION:  return "TypeOption";
        case NODE_PARAM:        return "Param";
        case NODE_FIELD:        return "Field";
        case NODE_MATCH_ARM:    return "MatchArm";
        case NODE_ANNOTATION:   return "Annotation";
        default:                return "?";
    }
}

void ast_print(AstNode *node, int depth) {
    if (!node) return;
    for (int i = 0; i < depth; i++) printf("  ");
    printf("[%s]", node_name(node->type));
    if (node->sval) printf(" \"%s\"", node->sval);
    if (node->type == NODE_INT_LIT)   printf(" %lld", node->ival);
    if (node->type == NODE_FLOAT_LIT) printf(" %g",   node->fval);
    if (node->type == NODE_BOOL_LIT)  printf(" %s",   node->bval ? "true" : "false");
    if (node->is_mut)   printf(" [mut]");
    if (node->is_async) printf(" [async]");
    printf("  (line %d)\n", node->line);
    for (int i = 0; i < node->child_count; i++)
        ast_print(node->children[i], depth + 1);
}
