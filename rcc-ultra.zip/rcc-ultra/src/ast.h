#ifndef AST_H
#define AST_H

/* ============================================================
 * Renad C Compiler — AST Node Definitions
 * ============================================================ */

typedef enum {
    /* Statements */
    NODE_PROGRAM,
    NODE_FN_DECL,
    NODE_LET_STMT,
    NODE_CONST_STMT,
    NODE_RETURN_STMT,
    NODE_IF_STMT,
    NODE_WHILE_STMT,
    NODE_FOR_STMT,
    NODE_BLOCK,
    NODE_EXPR_STMT,
    NODE_PRINT_STMT,
    NODE_IMPORT_STMT,
    NODE_CLASS_DECL,
    NODE_STRUCT_DECL,
    NODE_IMPL_BLOCK,
    NODE_ASSIGN_STMT,
    NODE_MATCH_STMT,
    NODE_DEFER_STMT,
    /* Expressions */
    NODE_INT_LIT,
    NODE_FLOAT_LIT,
    NODE_STRING_LIT,
    NODE_BOOL_LIT,
    NODE_IDENT,
    NODE_BINARY_OP,
    NODE_UNARY_OP,
    NODE_CALL,
    NODE_INDEX,
    NODE_MEMBER,
    NODE_ARRAY_LIT,
    NODE_STRUCT_LIT,
    NODE_LAMBDA,
    NODE_IF_EXPR,
    NODE_AWAIT_EXPR,
    NODE_INTERP_STRING,
    NODE_RANGE,
    NODE_CAST,
    NODE_METHOD_CALL,
    /* Type nodes */
    NODE_TYPE_NAME,
    NODE_TYPE_GENERIC,
    NODE_TYPE_ARRAY,
    NODE_TYPE_PTR,
    NODE_TYPE_OPTION,
    NODE_TYPE_RESULT,
    NODE_TYPE_FN,
    /* Params & fields */
    NODE_PARAM,
    NODE_FIELD,
    NODE_MATCH_ARM,
    /* Annotation */
    NODE_ANNOTATION,
    /* Enums */
    NODE_ENUM_DECL,
    NODE_ENUM_VARIANT,
    NODE_MACRO_DEF,
    NODE_MACRO_CALL,
    NODE_ASM_BLOCK,
    NODE_MODULE_DECL,
    NODE_USE_STMT,
    NODE_CHAN_DECL,
    NODE_SEND_STMT,
    NODE_RECV_EXPR,
    NODE_SELECT_STMT,
    NODE_QUESTION_OP,

    /* Closures */
    NODE_CLOSURE,
    /* Generics */
    NODE_TYPE_PARAM,
    NODE_GENERIC_INST,
    /* Collections */
    NODE_VEC_LIT,
    NODE_MAP_LIT,
    NODE_KV_PAIR,
    /* Control */
    NODE_QUESTION,       /* ? operator */
    NODE_PIPE,           /* |> operator */
    NODE_SPREAD,         /* ... spread */
    /* Import */
    NODE_IMPORT,         /* import with module path */
    NODE_CONST_DECL = NODE_CONST_STMT,  /* alias */
} NodeType;

typedef struct AstNode AstNode;

struct AstNode {
    NodeType    type;
    int         line;
    int         col;
    /* Common string value (name, op, literal text) */
    char       *sval;
    long long   ival;
    double      fval;
    int         bval;
    /* Children */
    AstNode   **children;
    int         child_count;
    int         child_cap;
    /* Extra flags */
    int         is_mut;
    int         is_async;
    int         is_pub;
    /* Type annotation (may be NULL) */
    AstNode    *type_node;
};

AstNode *ast_node(NodeType type, int line, int col);
void     ast_add_child(AstNode *parent, AstNode *child);
void     ast_free(AstNode *node);
void     ast_print(AstNode *node, int depth);

#endif
/* NOTE: these are appended — integrated in NodeType enum below via patch */
