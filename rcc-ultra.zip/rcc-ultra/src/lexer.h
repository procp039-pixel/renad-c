#ifndef LEXER_H
#define LEXER_H

#include <stddef.h>

typedef enum {
    /* Literals */
    TOK_INT_LIT, TOK_FLOAT_LIT, TOK_STRING_LIT, TOK_BOOL_LIT, TOK_NULL,
    /* Identifiers & Keywords */
    TOK_IDENT,
    TOK_FN, TOK_LET, TOK_MUT, TOK_CONST, TOK_RETURN, TOK_IF, TOK_ELSE,
    TOK_WHILE, TOK_FOR, TOK_IN, TOK_LOOP, TOK_BREAK, TOK_CONTINUE,
    TOK_MATCH, TOK_CLASS, TOK_STRUCT, TOK_IMPL, TOK_TRAIT, TOK_IMPORT,
    TOK_AS, TOK_FROM, TOK_ASYNC, TOK_AWAIT, TOK_TRUE, TOK_FALSE,
    TOK_AND, TOK_OR, TOK_NOT, TOK_ENUM, TOK_PUB, TOK_WHERE, TOK_GO,
    TOK_DEFER, TOK_TRY, TOK_CATCH, TOK_FINALLY, TOK_EXTENDS, TOK_PRINT,
    TOK_MACRO, TOK_ASM, TOK_CHAN, TOK_SELECT, TOK_MODULE, TOK_USE, TOK_EXTERN,
    /* Types */
    TOK_INT_TYPE, TOK_FLOAT_TYPE, TOK_STR_TYPE, TOK_BOOL_TYPE, TOK_VOID_TYPE,
    /* Operators */
    TOK_PLUS, TOK_MINUS, TOK_STAR, TOK_SLASH, TOK_PERCENT,
    TOK_EQ, TOK_NEQ, TOK_LT, TOK_GT, TOK_LEQ, TOK_GEQ,
    TOK_ASSIGN, TOK_PLUS_ASSIGN, TOK_MINUS_ASSIGN, TOK_STAR_ASSIGN,
    TOK_ARROW, TOK_FAT_ARROW, TOK_DOT, TOK_DOTDOT, TOK_QUESTION,
    TOK_AMPERSAND, TOK_PIPE, TOK_CARET, TOK_BANG, TOK_TILDE,
    TOK_AND_AND, TOK_OR_OR, TOK_COLONCOLON, TOK_QUESTION_DOT,
    /* Delimiters */
    TOK_LPAREN, TOK_RPAREN, TOK_LBRACE, TOK_RBRACE,
    TOK_LBRACKET, TOK_RBRACKET, TOK_COMMA, TOK_COLON, TOK_SEMICOLON,
    TOK_NEWLINE, TOK_INDENT, TOK_DEDENT, TOK_AT,
    /* Special */
    TOK_EOF, TOK_ERROR
} TokenType;

typedef struct {
    TokenType   type;
    char       *value;
    int         line;
    int         col;
} Token;

typedef struct {
    const char *src;
    size_t      pos;
    size_t      len;
    int         line;
    int         col;
    int         indent_stack[256];
    int         indent_top;
    Token       pending[16];
    int         pending_count;
} Lexer;

Lexer *lexer_new(const char *source);
Token  lexer_next(Lexer *l);
Token  lexer_peek(Lexer *l);
void   lexer_free(Lexer *l);
const char *token_type_name(TokenType t);

#endif
