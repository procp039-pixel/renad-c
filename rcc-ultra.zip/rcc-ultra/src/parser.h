#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"
#include "ast.h"

typedef struct {
    Lexer  *lexer;
    Token   current;
    Token   lookahead;
    int     had_error;
    int     error_line;
    int     error_col;
    char    error_msg[512];
} Parser;

Parser  *parser_new(Lexer *lexer);
AstNode *parser_parse(Parser *p);
void     parser_free(Parser *p);

#endif
