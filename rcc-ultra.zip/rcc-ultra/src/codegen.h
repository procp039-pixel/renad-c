#ifndef CODEGEN_H
#define CODEGEN_H

#include "ast.h"
#include <stdio.h>

typedef struct {
    FILE  *out;          /* output C file */
    int    indent;
    int    had_error;
    char   error_msg[512];
    /* Symbol table (flat, simple) */
    char   vars[256][64];
    char   var_types[256][64];
    int    var_count;
    /* Function table */
    char   funcs[128][64];
    int    func_count;
    /* Current function context */
    char   current_fn[64];
    int    in_async;
    int    tmp_counter;
    /* Ultra stdlib feature flags */
    int    has_nn, has_sys, has_telegram, has_sec, has_mobile;
} CodeGen;

CodeGen *codegen_new(FILE *out);
void     codegen_run(CodeGen *cg, AstNode *program);
void     codegen_free(CodeGen *cg);

#endif
