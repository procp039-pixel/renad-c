/* ============================================================
 * Renad C Compiler — Lexer (Tokenizer)
 * Creator: Mohamed Ahmed Mohamed
 * Version: 1.0.0
 * ============================================================ */
#include "lexer.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* ── Keyword table ─────────────────────────────────────────── */
typedef struct { const char *word; TokenType type; } Keyword;

static Keyword KEYWORDS[] = {
    {"fn",       TOK_FN},      {"let",      TOK_LET},
    {"mut",      TOK_MUT},     {"const",    TOK_CONST},
    {"return",   TOK_RETURN},  {"if",       TOK_IF},
    {"else",     TOK_ELSE},    {"while",    TOK_WHILE},
    {"for",      TOK_FOR},     {"in",       TOK_IN},
    {"loop",     TOK_LOOP},    {"break",    TOK_BREAK},
    {"continue", TOK_CONTINUE},{"match",    TOK_MATCH},
    {"class",    TOK_CLASS},   {"struct",   TOK_STRUCT},
    {"impl",     TOK_IMPL},    {"trait",    TOK_TRAIT},
    {"import",   TOK_IMPORT},  {"as",       TOK_AS},
    {"from",     TOK_FROM},    {"async",    TOK_ASYNC},
    {"await",    TOK_AWAIT},   {"true",     TOK_TRUE},
    {"false",    TOK_FALSE},   {"and",      TOK_AND},
    {"or",       TOK_OR},      {"not",      TOK_NOT},
    {"enum",     TOK_ENUM},    {"pub",      TOK_PUB},
    {"where",    TOK_WHERE},   {"go",       TOK_GO},
    {"defer",    TOK_DEFER},   {"try",      TOK_TRY},
    {"macro",    TOK_MACRO},   {"asm",      TOK_ASM},
    {"chan",     TOK_CHAN},     {"select",   TOK_SELECT},
    {"module",   TOK_MODULE},  {"use",      TOK_USE},
    {"extern",   TOK_EXTERN},
    {"catch",    TOK_CATCH},   {"finally",  TOK_FINALLY},
    {"extends",  TOK_EXTENDS}, {"print",    TOK_PRINT},
    {"int",      TOK_INT_TYPE},{"float",    TOK_FLOAT_TYPE},
    {"str",      TOK_STR_TYPE},{"bool",     TOK_BOOL_TYPE},
    {"void",     TOK_VOID_TYPE},{NULL,       TOK_EOF}
};

/* ── Constructor ───────────────────────────────────────────── */
Lexer *lexer_new(const char *source) {
    Lexer *l = calloc(1, sizeof(Lexer));
    l->src  = source;
    l->len  = strlen(source);
    l->line = 1;
    l->col  = 1;
    l->indent_stack[0] = 0;
    l->indent_top = 0;
    return l;
}

void lexer_free(Lexer *l) { free(l); }

/* ── Helpers ───────────────────────────────────────────────── */
static char peek_char(Lexer *l) {
    return (l->pos < l->len) ? l->src[l->pos] : '\0';
}

static char peek2(Lexer *l) {
    return (l->pos + 1 < l->len) ? l->src[l->pos + 1] : '\0';
}

static char advance(Lexer *l) {
    char c = l->src[l->pos++];
    if (c == '\n') { l->line++; l->col = 1; }
    else { l->col++; }
    return c;
}

static Token make_tok(Lexer *l, TokenType t, const char *val, int line, int col) {
    Token tok;
    tok.type  = t;
    tok.value = val ? strdup(val) : NULL;
    tok.line  = line;
    tok.col   = col;
    return tok;
}

static Token make_char_tok(Lexer *l, TokenType t, char c, int line, int col) {
    char buf[2] = {c, '\0'};
    return make_tok(l, t, buf, line, col);
}

/* ── String intern buffer ──────────────────────────────────── */
static char sbuf[4096];

/* ── Skip whitespace (not newlines) ───────────────────────── */
static void skip_spaces(Lexer *l) {
    while (l->pos < l->len) {
        char c = peek_char(l);
        if (c == ' ' || c == '\t' || c == '\r') advance(l);
        else if (c == '/' && peek2(l) == '/') {   /* line comment */
            while (l->pos < l->len && peek_char(l) != '\n') advance(l);
        } else break;
    }
}

/* ── Lex a string literal ──────────────────────────────────── */
static Token lex_string(Lexer *l) {
    int line = l->line, col = l->col;
    advance(l); /* skip opening " */
    int  i = 0;
    char out[4096];
    while (l->pos < l->len && peek_char(l) != '"') {
        char c = advance(l);
        if (c == '\\') {
            char e = advance(l);
            switch (e) {
                case 'n':  out[i++] = '\n'; break;
                case 't':  out[i++] = '\t'; break;
                case '\\': out[i++] = '\\'; break;
                case '"':  out[i++] = '"';  break;
                default:   out[i++] = '\\'; out[i++] = e; break;
            }
        } else {
            out[i++] = c;
        }
        if (i >= 4090) break;
    }
    if (peek_char(l) == '"') advance(l); /* skip closing " */
    out[i] = '\0';
    return make_tok(l, TOK_STRING_LIT, out, line, col);
}

/* ── Lex a number ──────────────────────────────────────────── */
static Token lex_number(Lexer *l) {
    int line = l->line, col = l->col;
    int i = 0;
    int is_float = 0;
    while (l->pos < l->len && (isdigit(peek_char(l)) || peek_char(l) == '.')) {
        char c = peek_char(l);
        if (c == '.') {
            if (is_float) break;
            if (!isdigit(peek2(l))) break;
            is_float = 1;
        }
        sbuf[i++] = advance(l);
    }
    sbuf[i] = '\0';
    return make_tok(l, is_float ? TOK_FLOAT_LIT : TOK_INT_LIT, sbuf, line, col);
}

/* ── Lex an identifier or keyword ─────────────────────────── */
static Token lex_ident(Lexer *l) {
    int line = l->line, col = l->col;
    int i = 0;
    while (l->pos < l->len && (isalnum(peek_char(l)) || peek_char(l) == '_'))
        sbuf[i++] = advance(l);
    sbuf[i] = '\0';
    /* Check keywords */
    for (int k = 0; KEYWORDS[k].word; k++) {
        if (strcmp(sbuf, KEYWORDS[k].word) == 0)
            return make_tok(l, KEYWORDS[k].type, sbuf, line, col);
    }
    return make_tok(l, TOK_IDENT, sbuf, line, col);
}

/* ── Indent/Dedent tracking ────────────────────────────────── */
static void push_pending(Lexer *l, Token t) {
    if (l->pending_count < 16)
        l->pending[l->pending_count++] = t;
}

static Token handle_newline(Lexer *l, int line, int col) {
    advance(l); /* consume \n */
    /* Count leading spaces on next line */
    int spaces = 0;
    while (l->pos < l->len && (peek_char(l) == ' ' || peek_char(l) == '\t')) {
        if (peek_char(l) == '\t') spaces += 4; else spaces++;
        advance(l);
    }
    /* Skip blank lines and comment-only lines */
    if (peek_char(l) == '\n' || peek_char(l) == '\0' ||
        (peek_char(l) == '/' && peek2(l) == '/')) {
        /* skip, return another newline scan */
        return make_tok(l, TOK_NEWLINE, "\n", line, col);
    }
    int cur_indent = l->indent_stack[l->indent_top];
    Token nl = make_tok(l, TOK_NEWLINE, "\n", line, col);
    if (spaces > cur_indent) {
        l->indent_stack[++l->indent_top] = spaces;
        push_pending(l, make_tok(l, TOK_INDENT, "INDENT", line, col));
    } else if (spaces < cur_indent) {
        while (l->indent_top > 0 && l->indent_stack[l->indent_top] > spaces) {
            l->indent_top--;
            push_pending(l, make_tok(l, TOK_DEDENT, "DEDENT", line, col));
        }
    }
    return nl;
}

/* ── Main tokenizer ────────────────────────────────────────── */
Token lexer_next(Lexer *l) {
    /* Return any pending indent/dedent tokens */
    if (l->pending_count > 0) {
        Token t = l->pending[0];
        memmove(l->pending, l->pending + 1,
                (l->pending_count - 1) * sizeof(Token));
        l->pending_count--;
        return t;
    }

    skip_spaces(l);

    if (l->pos >= l->len)
        return make_tok(l, TOK_EOF, "", l->line, l->col);

    int line = l->line, col = l->col;
    char c = peek_char(l);

    /* Newline → handle indent tracking */
    if (c == '\n') return handle_newline(l, line, col);

    /* String literal */
    if (c == '"') return lex_string(l);

    /* Number */
    if (isdigit(c)) return lex_number(l);

    /* Identifier / keyword */
    if (isalpha(c) || c == '_') return lex_ident(l);

    /* Annotation @ */
    if (c == '@') { advance(l); return make_tok(l, TOK_AT, "@", line, col); }

    /* Two-char operators */
    advance(l);
    char n = peek_char(l);

    if (c == '=' && n == '=') { advance(l); return make_tok(l, TOK_EQ,         "==", line, col); }
    if (c == '!' && n == '=') { advance(l); return make_tok(l, TOK_NEQ,        "!=", line, col); }
    if (c == '<' && n == '=') { advance(l); return make_tok(l, TOK_LEQ,        "<=", line, col); }
    if (c == '>' && n == '=') { advance(l); return make_tok(l, TOK_GEQ,        ">=", line, col); }
    if (c == '-' && n == '>') { advance(l); return make_tok(l, TOK_ARROW,      "->", line, col); }
    if (c == '=' && n == '>') { advance(l); return make_tok(l, TOK_FAT_ARROW,  "=>", line, col); }
    if (c == '+' && n == '=') { advance(l); return make_tok(l, TOK_PLUS_ASSIGN,"+=", line, col); }
    if (c == '-' && n == '=') { advance(l); return make_tok(l, TOK_MINUS_ASSIGN,"-=",line, col); }
    if (c == '*' && n == '=') { advance(l); return make_tok(l, TOK_STAR_ASSIGN, "*=",line, col); }
    if (c == '&' && n == '&') { advance(l); return make_tok(l, TOK_AND_AND,   "&&", line, col); }
    if (c == '|' && n == '|') { advance(l); return make_tok(l, TOK_OR_OR,     "||", line, col); }
    if (c == ':' && n == ':') { advance(l); return make_tok(l, TOK_COLONCOLON,"::", line, col); }
    if (c == '.' && n == '.') { advance(l); return make_tok(l, TOK_DOTDOT,    "..", line, col); }
    if (c == '?' && n == '.') { advance(l); return make_tok(l, TOK_QUESTION_DOT,"?.",line,col); }

    /* Single-char operators */
    switch (c) {
        case '+': return make_char_tok(l, TOK_PLUS,     '+', line, col);
        case '-': return make_char_tok(l, TOK_MINUS,    '-', line, col);
        case '*': return make_char_tok(l, TOK_STAR,     '*', line, col);
        case '/': return make_char_tok(l, TOK_SLASH,    '/', line, col);
        case '%': return make_char_tok(l, TOK_PERCENT,  '%', line, col);
        case '<': return make_char_tok(l, TOK_LT,       '<', line, col);
        case '>': return make_char_tok(l, TOK_GT,       '>', line, col);
        case '=': return make_char_tok(l, TOK_ASSIGN,   '=', line, col);
        case '!': return make_char_tok(l, TOK_BANG,     '!', line, col);
        case '&': return make_char_tok(l, TOK_AMPERSAND,'&', line, col);
        case '|': return make_char_tok(l, TOK_PIPE,     '|', line, col);
        case '^': return make_char_tok(l, TOK_CARET,    '^', line, col);
        case '~': return make_char_tok(l, TOK_TILDE,    '~', line, col);
        case '.': return make_char_tok(l, TOK_DOT,      '.', line, col);
        case '?': return make_char_tok(l, TOK_QUESTION, '?', line, col);
        case '(': return make_char_tok(l, TOK_LPAREN,   '(', line, col);
        case ')': return make_char_tok(l, TOK_RPAREN,   ')', line, col);
        case '{': return make_char_tok(l, TOK_LBRACE,   '{', line, col);
        case '}': return make_char_tok(l, TOK_RBRACE,   '}', line, col);
        case '[': return make_char_tok(l, TOK_LBRACKET, '[', line, col);
        case ']': return make_char_tok(l, TOK_RBRACKET, ']', line, col);
        case ',': return make_char_tok(l, TOK_COMMA,    ',', line, col);
        case ':': return make_char_tok(l, TOK_COLON,    ':', line, col);
        case ';': return make_char_tok(l, TOK_SEMICOLON,';', line, col);
        default: {
            char buf[2] = {c, '\0'};
            return make_tok(l, TOK_ERROR, buf, line, col);
        }
    }
}

Token lexer_peek(Lexer *l) {
    size_t  saved_pos          = l->pos;
    int     saved_line         = l->line;
    int     saved_col          = l->col;
    int     saved_indent_top   = l->indent_top;
    int     saved_pending      = l->pending_count;
    int     stack_backup[256];
    Token   pend_backup[16];
    memcpy(stack_backup, l->indent_stack, sizeof(l->indent_stack));
    memcpy(pend_backup,  l->pending,      sizeof(l->pending));

    Token t = lexer_next(l);

    l->pos          = saved_pos;
    l->line         = saved_line;
    l->col          = saved_col;
    l->indent_top   = saved_indent_top;
    l->pending_count= saved_pending;
    memcpy(l->indent_stack, stack_backup, sizeof(l->indent_stack));
    memcpy(l->pending,      pend_backup,  sizeof(l->pending));

    return t;
}

/* ── Debug helper ──────────────────────────────────────────── */
const char *token_type_name(TokenType t) {
    switch(t) {
        case TOK_INT_LIT:     return "INT_LIT";
        case TOK_FLOAT_LIT:   return "FLOAT_LIT";
        case TOK_STRING_LIT:  return "STRING_LIT";
        case TOK_BOOL_LIT:    return "BOOL_LIT";
        case TOK_IDENT:       return "IDENT";
        case TOK_FN:          return "fn";
        case TOK_LET:         return "let";
        case TOK_MUT:         return "mut";
        case TOK_CONST:       return "const";
        case TOK_RETURN:      return "return";
        case TOK_IF:          return "if";
        case TOK_ELSE:        return "else";
        case TOK_WHILE:       return "while";
        case TOK_FOR:         return "for";
        case TOK_IN:          return "in";
        case TOK_MATCH:       return "match";
        case TOK_CLASS:       return "class";
        case TOK_STRUCT:      return "struct";
        case TOK_IMPL:        return "impl";
        case TOK_TRAIT:       return "trait";
        case TOK_IMPORT:      return "import";
        case TOK_PRINT:       return "print";
        case TOK_ASYNC:       return "async";
        case TOK_AWAIT:       return "await";
        case TOK_TRUE:        return "true";
        case TOK_FALSE:       return "false";
        case TOK_PLUS:        return "+";
        case TOK_MINUS:       return "-";
        case TOK_STAR:        return "*";
        case TOK_SLASH:       return "/";
        case TOK_EQ:          return "==";
        case TOK_NEQ:         return "!=";
        case TOK_LT:          return "<";
        case TOK_GT:          return ">";
        case TOK_ASSIGN:      return "=";
        case TOK_ARROW:       return "->";
        case TOK_FAT_ARROW:   return "=>";
        case TOK_DOT:         return ".";
        case TOK_COMMA:       return ",";
        case TOK_COLON:       return ":";
        case TOK_LPAREN:      return "(";
        case TOK_RPAREN:      return ")";
        case TOK_LBRACE:      return "{";
        case TOK_RBRACE:      return "}";
        case TOK_LBRACKET:    return "[";
        case TOK_RBRACKET:    return "]";
        case TOK_NEWLINE:     return "NEWLINE";
        case TOK_INDENT:      return "INDENT";
        case TOK_DEDENT:      return "DEDENT";
        case TOK_EOF:         return "EOF";
        default:              return "UNKNOWN";
    }
}
