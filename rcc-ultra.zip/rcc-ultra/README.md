# Renad C — v3 Ultra Pro Max

<div align="center">

```
  ╔═══╗╔═══╗
  ║ R ║║ C ╚═╗
  ║   ║║     ║
  ╚═╗ ╗╚═╗   ║
    ╚═╝  ╚═══╝
```

**The Power of C. The Soul of Python. The Brain of AI.**

[![Version](https://img.shields.io/badge/version-3.0--ultra-blue)]()
[![License](https://img.shields.io/badge/license-MIT-green)]()
[![Author](https://img.shields.io/badge/by-Mohamed_Ahmed_Mohamed-orange)]()
[![Telegram](https://img.shields.io/badge/Telegram-@XFH00-blue)]()

</div>

---

## What's New in v3 Ultra

| Stdlib | Description | Key APIs |
|--------|-------------|----------|
| `rcstd.nn` | Neural Networks | `nn_model`, `nn_dense`, `nn_forward`, `nn_adam` |
| `rcstd.sys` | Systems / OS | `sys_mmap`, `sys_spawn`, `sys_hexdump`, `sys_arena_new` |
| `rcstd.kernel` | OS Development | bare-metal bootstrap, syscalls, memory maps |
| `rcstd.mobile` | iOS + Android + RN | `mobile_app`, `mobile_export_ios`, `mobile_export_android` |
| `rcstd.telegram` | Telegram Bots | `tg_new`, `tg_cmd`, `tg_reply`, `tg_run` |
| `rcstd.sec` | Security Toolkit | `sec_scan`, `sec_banner`, `sec_fuzz`, `sec_b64` |

---

## Quick Start

```bash
# Build
gcc src/*.c -o rcc -lm && echo "✅ Built!"

# Run Neural Network demo
./rcc examples/nn_demo.rc

# Telegram bot
./rcc examples/telegram_bot.rc

# Security toolkit  
./rcc examples/security_toolkit.rc

# Mobile + OS demo
./rcc examples/mobile_os_demo.rc
```

---

## Neural Network Example

```rc
import rcstd.nn as nn

fn main():
    let model = nn_model(0.001)
    nn_add(model, nn_dense(784, 512, "relu"))
    nn_add(model, nn_dense(512, 256, "relu"))
    nn_add(model, nn_dense(256, 10,  "softmax"))
    nn_print(model)
    // → 567,434 trainable parameters
```

## Telegram Bot Example

```rc
import rcstd.telegram as tg

fn on_start():
    print("Hello from Renad C!")

fn main():
    let bot = tg_new("YOUR_TOKEN")
    tg_cmd(bot, "start", on_start)
    tg_run(bot)   // long polling
```

## Security Toolkit Example

```rc
import rcstd.sec as sec

fn main():
    // Port scan (authorized only)
    let results = sec_scan("192.168.1.1", 1, 1024, ...)
    
    // Hash
    let h = sec_hash("password")
    
    // Base64
    sec_b64("Hello RC", 8, buf)
```

## Mobile App Example

```rc
import rcstd.mobile as mobile

fn main():
    let app = mobile_app("MyApp", "com.example.app")
    mobile_export_ios(app, "./ios")
    mobile_export_android(app, "./android")
    mobile_export_rn(app, "./rn")
```

## OS/Kernel Example

```rc
import rcstd.sys as sys
import rcstd.kernel as kernel

fn kernel_main():
    let mem = sys_mmap(65536, PROT_READ|PROT_WRITE)
    sys_hexdump(mem->base, 64)
    
    asm! {
        "cli"
        "hlt"
    }
```

## AI Error Assistant

```bash
export RC_AI_KEY="sk-or-v1-..."
export RC_AI_MODEL="deepseek/deepseek-chat"
./rcc broken.rc --ai-fix
./rcc --ask "How do I use rcstd.nn?"
```

---

## Full Compiler Flags

```
./rcc file.rc             compile & run
./rcc file.rc -o app      compile to binary
./rcc file.rc --watch     auto-recompile on change
./rcc file.rc --profile   show phase timing
./rcc file.rc --ai-fix    AI error diagnosis
./rcc file.rc --tokens    dump token stream
./rcc file.rc --ast       dump AST
./rcc file.rc --emit-c    show generated C
./rcc --ask "question"    ask AI about Renad C
```

---

## Project Structure

```
renad-c/
├── src/
│   ├── lexer.c/h       Tokenizer
│   ├── parser.c/h      Recursive-descent + Pratt
│   ├── ast.c/h         40+ node types
│   ├── codegen.c/h     C code generator + Ultra stdlib
│   ├── main.c          Compiler driver + AI assistant
│   └── rcstd_ultra.h   All stdlib implementations
├── examples/
│   ├── nn_demo.rc           Neural networks
│   ├── telegram_bot.rc      Telegram bot
│   ├── security_toolkit.rc  Ethical hacking
│   ├── mobile_os_demo.rc    Mobile + OS
│   ├── web_app.rc           HTTP server
│   └── api_server.rc        REST API
├── tools/
│   ├── rcpm.c          Package manager
│   └── rc-fmt.c        Code formatter
├── site/
│   └── index.html      Website + Playground (with AI)
├── vscode-extension/   Syntax highlighting
└── Makefile
```

---

## License

MIT License · **Mohamed Ahmed Mohamed** · Telegram: @XFH00

> *"The Power of C. The Soul of Python. The Brain of AI."*
